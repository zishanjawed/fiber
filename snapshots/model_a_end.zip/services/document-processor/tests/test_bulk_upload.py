"""
Unit and integration tests for Bulk Upload feature.
Tests batch creation, concurrency limiting, failure isolation, and status tracking.
"""
import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch, mock_open
from datetime import datetime
from uuid import uuid4
import io

from fastapi.testclient import TestClient
from fastapi import UploadFile

# Import the app and schemas
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from models.schemas import (
    BatchJob,
    BatchFileStatus,
    BatchUploadResponse,
    BatchStatusResponse
)


# ============================================================================
# Unit Tests for Batch Models
# ============================================================================

class TestBatchJobModel:
    """Test BatchJob Pydantic model."""

    def test_batch_job_creation_defaults(self):
        """Test 1: BatchJob creates with proper defaults."""
        job = BatchJob(
            user_id="user123",
            total_files=5
        )

        assert job.batch_id is not None
        assert len(job.batch_id) == 36  # UUID format
        assert job.user_id == "user123"
        assert job.total_files == 5
        assert job.completed_files == 0
        assert job.failed_files == 0
        assert job.status == "pending"
        assert job.files == []
        assert isinstance(job.created_at, datetime)
        assert isinstance(job.updated_at, datetime)

    def test_batch_job_with_files(self):
        """Test 2: BatchJob with file statuses."""
        files = [
            BatchFileStatus(
                filename="doc1.pdf",
                file_index=0,
                status="pending"
            ),
            BatchFileStatus(
                filename="doc2.pdf",
                file_index=1,
                status="pending"
            )
        ]

        job = BatchJob(
            user_id="user123",
            total_files=2,
            files=files,
            subject="Chemistry",
            tags=["organic", "bonds"]
        )

        assert len(job.files) == 2
        assert job.files[0].filename == "doc1.pdf"
        assert job.files[1].filename == "doc2.pdf"
        assert job.subject == "Chemistry"
        assert job.tags == ["organic", "bonds"]

    def test_batch_file_status_defaults(self):
        """Test 3: BatchFileStatus has correct defaults."""
        status = BatchFileStatus(
            filename="test.pdf",
            file_index=0
        )

        assert status.filename == "test.pdf"
        assert status.file_index == 0
        assert status.status == "pending"
        assert status.content_id is None
        assert status.error_message is None
        assert status.is_duplicate is False
        assert status.total_chunks == 0
        assert status.progress == 0

    def test_batch_file_status_with_error(self):
        """Test 4: BatchFileStatus tracks errors."""
        status = BatchFileStatus(
            filename="bad_file.pdf",
            file_index=2,
            status="failed",
            error_message="File corrupted",
            completed_at=datetime.utcnow()
        )

        assert status.status == "failed"
        assert status.error_message == "File corrupted"
        assert status.completed_at is not None

    def test_batch_file_status_duplicate(self):
        """Test 5: BatchFileStatus tracks duplicates."""
        original_id = str(uuid4())
        status = BatchFileStatus(
            filename="duplicate.pdf",
            file_index=1,
            status="completed",
            content_id=original_id,
            is_duplicate=True,
            duplicate_of=original_id
        )

        assert status.is_duplicate is True
        assert status.duplicate_of == original_id


class TestBatchUploadResponse:
    """Test BatchUploadResponse model."""

    def test_response_structure(self):
        """Test 6: Response has correct structure."""
        response = BatchUploadResponse(
            batch_id="batch-123",
            total_files=3,
            status="processing",
            message="Batch started",
            files=[
                {"filename": "a.pdf", "size_mb": 1.5, "status": "pending"},
                {"filename": "b.pdf", "size_mb": 2.3, "status": "pending"},
                {"filename": "c.pdf", "size_mb": 0.8, "status": "pending"}
            ]
        )

        assert response.batch_id == "batch-123"
        assert response.total_files == 3
        assert response.status == "processing"
        assert len(response.files) == 3
        assert response.files[0]["filename"] == "a.pdf"


class TestBatchStatusResponse:
    """Test BatchStatusResponse model."""

    def test_status_response_with_progress(self):
        """Test 7: Status response calculates progress."""
        files = [
            BatchFileStatus(filename="a.pdf", file_index=0, status="completed"),
            BatchFileStatus(filename="b.pdf", file_index=1, status="completed"),
            BatchFileStatus(filename="c.pdf", file_index=2, status="failed"),
            BatchFileStatus(filename="d.pdf", file_index=3, status="processing"),
        ]

        response = BatchStatusResponse(
            batch_id="batch-456",
            user_id="user123",
            total_files=4,
            completed_files=2,
            failed_files=1,
            status="processing",
            files=files,
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
            progress_percentage=75.0
        )

        assert response.total_files == 4
        assert response.completed_files == 2
        assert response.failed_files == 1
        assert response.progress_percentage == 75.0


# ============================================================================
# Integration Tests for Bulk Upload Logic
# ============================================================================

class TestBatchFileValidation:
    """Test file validation logic."""

    def test_valid_file_extensions(self):
        """Test 8: All valid extensions are accepted."""
        valid_extensions = ['pdf', 'md', 'txt', 'docx', 'doc']

        for ext in valid_extensions:
            filename = f"test.{ext}"
            file_extension = filename.split('.')[-1].lower()
            assert file_extension in valid_extensions

    def test_invalid_file_extension_rejected(self):
        """Test 9: Invalid extensions are rejected."""
        valid_extensions = ['pdf', 'md', 'txt', 'docx', 'doc']
        invalid_files = ['test.exe', 'script.py', 'image.jpg', 'data.csv']

        for filename in invalid_files:
            ext = filename.split('.')[-1].lower()
            assert ext not in valid_extensions

    def test_file_size_validation(self):
        """Test 10: File size limits are enforced."""
        MAX_FILE_SIZE_MB = 50

        # Valid size
        valid_size_mb = 45.0
        assert valid_size_mb <= MAX_FILE_SIZE_MB

        # Invalid size
        invalid_size_mb = 55.0
        assert invalid_size_mb > MAX_FILE_SIZE_MB

    def test_batch_size_validation(self):
        """Test 11: Total batch size limits are enforced."""
        MAX_BATCH_SIZE_MB = 500

        # Valid batch
        files_sizes = [10.0, 20.0, 30.0, 40.0, 50.0]  # 150MB total
        total = sum(files_sizes)
        assert total <= MAX_BATCH_SIZE_MB

        # Invalid batch
        large_files = [100.0] * 6  # 600MB total
        total_large = sum(large_files)
        assert total_large > MAX_BATCH_SIZE_MB

    def test_max_files_validation(self):
        """Test 12: Maximum file count is enforced."""
        MAX_BATCH_FILES = 50

        # Valid count
        assert 20 <= MAX_BATCH_FILES
        assert 50 <= MAX_BATCH_FILES

        # Invalid count
        assert 51 > MAX_BATCH_FILES
        assert 100 > MAX_BATCH_FILES


class TestConcurrencyControl:
    """Test concurrent processing with semaphore."""

    @pytest.mark.asyncio
    async def test_concurrent_batch_limit_enforced(self):
        """Test 52: User cannot start more than 2 concurrent batches."""
        from unittest.mock import AsyncMock, MagicMock
        from shared.exceptions.custom_exceptions import FileValidationError

        # User already has 2 batches processing
        mock_db = MagicMock()

        async def mock_count_documents(query):
            if query.get("status") == "processing":
                return 2  # Already at limit
            return 0  # No rate limit issues

        async def mock_aggregate(pipeline):
            class MockCursor:
                async def to_list(self, limit):
                    return []
            return MockCursor()

        mock_db.batch_jobs.count_documents = mock_count_documents
        mock_db.batch_jobs.aggregate = mock_aggregate

        # Try to start a third batch - should be rejected
        from main import MAX_CONCURRENT_BATCHES_PER_USER

        concurrent_batches = await mock_db.batch_jobs.count_documents({
            "user_id": "user123",
            "status": "processing"
        })

        assert concurrent_batches >= MAX_CONCURRENT_BATCHES_PER_USER
        assert concurrent_batches == 2

        # This check happens in bulk_upload endpoint
        should_reject = concurrent_batches >= MAX_CONCURRENT_BATCHES_PER_USER
        assert should_reject, "Should prevent more than 2 concurrent batches"

    @pytest.mark.asyncio
    async def test_concurrent_batch_limit_allows_when_below(self):
        """Test 53: User can start batch when below concurrent limit."""
        mock_db = MagicMock()

        async def mock_count_documents(query):
            if query.get("status") == "processing":
                return 1  # Only 1 processing, can start another
            return 0

        mock_db.batch_jobs.count_documents = mock_count_documents

        concurrent_batches = await mock_db.batch_jobs.count_documents({
            "user_id": "user123",
            "status": "processing"
        })

        from main import MAX_CONCURRENT_BATCHES_PER_USER
        assert concurrent_batches < MAX_CONCURRENT_BATCHES_PER_USER

        should_allow = concurrent_batches < MAX_CONCURRENT_BATCHES_PER_USER
        assert should_allow, "Should allow batch when below limit"

    @pytest.mark.asyncio
    async def test_semaphore_limits_concurrency(self):
        """Test 13: Semaphore limits concurrent tasks."""
        MAX_CONCURRENT = 5
        semaphore = asyncio.Semaphore(MAX_CONCURRENT)

        active_count = 0
        max_active = 0
        results = []

        async def task(task_id):
            nonlocal active_count, max_active
            async with semaphore:
                active_count += 1
                max_active = max(max_active, active_count)
                await asyncio.sleep(0.1)  # Simulate work
                active_count -= 1
                results.append(task_id)

        # Create 10 tasks (more than semaphore allows)
        tasks = [task(i) for i in range(10)]
        await asyncio.gather(*tasks)

        # All tasks should complete
        assert len(results) == 10

        # Never exceeded max concurrent
        assert max_active <= MAX_CONCURRENT

    @pytest.mark.asyncio
    async def test_failure_isolation(self):
        """Test 14: One task failure doesn't affect others."""
        results = []
        errors = []

        async def task(task_id, should_fail=False):
            if should_fail:
                errors.append(task_id)
                raise Exception(f"Task {task_id} failed")
            results.append(task_id)

        # Mix of successful and failing tasks
        tasks = [
            task(0),
            task(1, should_fail=True),  # Will fail
            task(2),
            task(3, should_fail=True),  # Will fail
            task(4)
        ]

        # Use gather with return_exceptions to isolate failures
        outcomes = await asyncio.gather(*tasks, return_exceptions=True)

        # 3 successful, 2 failed
        assert len(results) == 3
        assert len(errors) == 2

        # All tasks completed (either success or exception)
        assert len(outcomes) == 5

    @pytest.mark.asyncio
    async def test_timeout_handling(self):
        """Test 15: File processing timeout is enforced."""
        FILE_PROCESSING_TIMEOUT = 1  # 1 second for test

        async def slow_task():
            await asyncio.sleep(5)  # Takes too long
            return "completed"

        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(slow_task(), timeout=FILE_PROCESSING_TIMEOUT)

    @pytest.mark.asyncio
    async def test_batch_completion_tracking(self):
        """Test 16: Batch completion is tracked correctly."""
        total_files = 10
        completed = 0
        failed = 0

        async def process_file(should_succeed):
            nonlocal completed, failed
            if should_succeed:
                completed += 1
            else:
                failed += 1

        # Process mixed results
        tasks = [
            process_file(True),   # Success
            process_file(True),   # Success
            process_file(False),  # Fail
            process_file(True),   # Success
            process_file(True),   # Success
            process_file(False),  # Fail
            process_file(True),   # Success
            process_file(True),   # Success
            process_file(True),   # Success
            process_file(True),   # Success
        ]

        await asyncio.gather(*tasks)

        assert completed == 8
        assert failed == 2
        assert completed + failed == total_files

        # Determine final status
        final_status = "completed" if failed == 0 else "completed_with_errors"
        assert final_status == "completed_with_errors"


class TestProgressCalculation:
    """Test progress percentage calculations."""

    def test_progress_zero_when_starting(self):
        """Test 17: Progress is 0 at start."""
        total = 10
        completed = 0
        failed = 0
        progress = ((completed + failed) / total * 100) if total > 0 else 0
        assert progress == 0.0

    def test_progress_partial(self):
        """Test 18: Progress calculates correctly mid-batch."""
        total = 10
        completed = 3
        failed = 1
        progress = ((completed + failed) / total * 100)
        assert progress == 40.0

    def test_progress_complete(self):
        """Test 19: Progress is 100 when done."""
        total = 10
        completed = 8
        failed = 2
        progress = ((completed + failed) / total * 100)
        assert progress == 100.0

    def test_progress_with_zero_files(self):
        """Test 20: Handle edge case of zero files."""
        total = 0
        completed = 0
        failed = 0
        progress = ((completed + failed) / total * 100) if total > 0 else 0
        assert progress == 0


class TestBatchStatusUpdates:
    """Test batch status update logic."""

    def test_batch_file_status_update_fields(self):
        """Test 21: File status updates have correct fields."""
        update_fields = {
            "files.0.status": "processing",
            "updated_at": datetime.utcnow()
        }

        # Add optional fields
        content_id = str(uuid4())
        update_fields["files.0.content_id"] = content_id
        update_fields["files.0.is_duplicate"] = False
        update_fields["files.0.total_chunks"] = 25

        assert "files.0.status" in update_fields
        assert "files.0.content_id" in update_fields
        assert update_fields["files.0.total_chunks"] == 25

    def test_batch_counters_increment(self):
        """Test 22: Batch counters increment correctly."""
        batch = {
            "completed_files": 5,
            "failed_files": 1
        }

        # Simulate successful completion
        batch["completed_files"] += 1
        assert batch["completed_files"] == 6

        # Simulate failure
        batch["failed_files"] += 1
        assert batch["failed_files"] == 2

    def test_final_status_determination(self):
        """Test 23: Final batch status is set correctly."""
        # All successful
        failed = 0
        status = "completed" if failed == 0 else "completed_with_errors"
        assert status == "completed"

        # Some failures
        failed = 3
        status = "completed" if failed == 0 else "completed_with_errors"
        assert status == "completed_with_errors"


class TestWebSocketEvents:
    """Test WebSocket event structure."""

    def test_batch_started_event(self):
        """Test 24: Batch started event has correct structure."""
        event = {
            "type": "batch_started",
            "batch_id": "batch-123",
            "total_files": 10,
            "status": "processing",
            "message": "Starting batch upload of 10 files..."
        }

        assert event["type"] == "batch_started"
        assert event["total_files"] == 10
        assert "batch_id" in event

    def test_file_progress_event(self):
        """Test 25: File progress event has correct structure."""
        event = {
            "type": "file_progress",
            "batch_id": "batch-123",
            "file_index": 3,
            "filename": "document.pdf",
            "file_status": "completed",
            "completed_files": 4,
            "failed_files": 1,
            "total_files": 10,
            "progress": 50,
            "message": "Processing 5/10 files..."
        }

        assert event["type"] == "file_progress"
        assert event["file_index"] == 3
        assert event["file_status"] == "completed"
        assert event["progress"] == 50

    def test_batch_completed_event(self):
        """Test 26: Batch completed event has correct structure."""
        event = {
            "type": "batch_completed",
            "batch_id": "batch-123",
            "status": "completed_with_errors",
            "total_files": 10,
            "completed_files": 8,
            "failed_files": 2,
            "message": "Batch processing complete. 8 succeeded, 2 failed."
        }

        assert event["type"] == "batch_completed"
        assert event["status"] == "completed_with_errors"
        assert event["completed_files"] == 8
        assert event["failed_files"] == 2

    def test_heartbeat_event(self):
        """Test 27: Heartbeat event is simple."""
        event = {"type": "heartbeat"}
        assert event["type"] == "heartbeat"

    def test_pong_event(self):
        """Test 28: Pong response is simple."""
        event = {"type": "pong"}
        assert event["type"] == "pong"


class TestTagsParsing:
    """Test tags parsing logic."""

    def test_parse_comma_separated_tags(self):
        """Test 29: Tags are parsed correctly from comma-separated string."""
        tags_str = "chemistry, organic, bonds"
        tags_list = [tag.strip() for tag in tags_str.split(',') if tag.strip()]

        assert tags_list == ["chemistry", "organic", "bonds"]

    def test_parse_tags_with_extra_spaces(self):
        """Test 30: Tags parsing handles extra spaces."""
        tags_str = "  physics ,  quantum  ,  mechanics  "
        tags_list = [tag.strip() for tag in tags_str.split(',') if tag.strip()]

        assert tags_list == ["physics", "quantum", "mechanics"]

    def test_parse_empty_tags(self):
        """Test 31: Empty tags string returns empty list."""
        tags_str = ""
        tags_list = [tag.strip() for tag in tags_str.split(',') if tag.strip()]

        assert tags_list == []

    def test_parse_single_tag(self):
        """Test 32: Single tag is parsed correctly."""
        tags_str = "biology"
        tags_list = [tag.strip() for tag in tags_str.split(',') if tag.strip()]

        assert tags_list == ["biology"]


class TestTitleGeneration:
    """Test title generation for batch files."""

    def test_title_from_filename_with_extension(self):
        """Test 33: Title extracted from filename."""
        filename = "chemistry_chapter_3.pdf"
        title = filename.rsplit('.', 1)[0] if '.' in filename else filename
        assert title == "chemistry_chapter_3"

    def test_title_from_filename_no_extension(self):
        """Test 34: Handle filename without extension."""
        filename = "readme"
        title = filename.rsplit('.', 1)[0] if '.' in filename else filename
        assert title == "readme"

    def test_title_with_prefix(self):
        """Test 35: Title prefix is prepended."""
        filename = "chapter_3.pdf"
        title_prefix = "Chemistry Unit 2"
        title = filename.rsplit('.', 1)[0]

        if title_prefix:
            title = f"{title_prefix} - {title}"

        assert title == "Chemistry Unit 2 - chapter_3"

    def test_title_without_prefix(self):
        """Test 36: Title without prefix uses filename."""
        filename = "organic_bonds.pdf"
        title_prefix = None
        title = filename.rsplit('.', 1)[0]

        if title_prefix:
            title = f"{title_prefix} - {title}"

        assert title == "organic_bonds"


# ============================================================================
# Edge Cases and Error Handling
# ============================================================================

class TestEdgeCases:
    """Test edge cases and error scenarios."""

    def test_empty_batch_rejected(self):
        """Test 37: Empty batch is rejected."""
        files = []
        assert len(files) == 0
        # Should raise FileValidationError in actual implementation

    def test_single_file_batch_allowed(self):
        """Test 38: Single file batch is allowed."""
        files = ["single.pdf"]
        MAX_BATCH_FILES = 50
        assert len(files) <= MAX_BATCH_FILES
        assert len(files) > 0

    def test_exact_max_files_allowed(self):
        """Test 39: Exactly 50 files is allowed."""
        files = [f"file_{i}.pdf" for i in range(50)]
        MAX_BATCH_FILES = 50
        assert len(files) == MAX_BATCH_FILES
        assert len(files) <= MAX_BATCH_FILES

    def test_over_max_files_rejected(self):
        """Test 40: Over 50 files is rejected."""
        files = [f"file_{i}.pdf" for i in range(51)]
        MAX_BATCH_FILES = 50
        assert len(files) > MAX_BATCH_FILES

    def test_filename_with_multiple_dots(self):
        """Test 41: Handle filenames with multiple dots."""
        filename = "document.final.version.2.pdf"
        extension = filename.split('.')[-1].lower()
        assert extension == "pdf"

        title = filename.rsplit('.', 1)[0]
        assert title == "document.final.version.2"

    def test_unicode_filename(self):
        """Test 42: Handle unicode in filenames."""
        filename = "化学文档.pdf"
        extension = filename.split('.')[-1].lower()
        assert extension == "pdf"

        title = filename.rsplit('.', 1)[0]
        assert title == "化学文档"

    def test_very_long_filename(self):
        """Test 43: Handle very long filenames."""
        long_name = "a" * 200 + ".pdf"
        extension = long_name.split('.')[-1].lower()
        assert extension == "pdf"
        assert len(long_name) > 200


class TestDuplicateHandling:
    """Test duplicate document detection in batches."""

    def test_duplicate_marked_in_file_status(self):
        """Test 44: Duplicate files are marked correctly."""
        original_id = str(uuid4())
        status = BatchFileStatus(
            filename="duplicate.pdf",
            file_index=2,
            status="completed",
            content_id=original_id,
            is_duplicate=True,
            duplicate_of=original_id
        )

        assert status.is_duplicate is True
        assert status.duplicate_of == original_id
        assert status.status == "completed"  # Still counts as success

    def test_duplicate_counts_as_success(self):
        """Test 45: Duplicate files count toward completed_files."""
        # Duplicate detection skips processing but counts as success
        completed_files = 5
        is_duplicate = True

        if is_duplicate:
            # Still increment completed
            completed_files += 1

        assert completed_files == 6


# ============================================================================
# Performance Considerations
# ============================================================================

class TestRabbitMQFailureCleanup:
    """Test cleanup when RabbitMQ fails."""

    @pytest.mark.asyncio
    async def test_rabbitmq_failure_cleanup(self):
        """Test 48: Orphaned MongoDB record is cleaned up on RabbitMQ failure."""
        from unittest.mock import AsyncMock, patch, MagicMock

        # Mock database
        mock_db = MagicMock()
        mock_db.content.find_one = AsyncMock(return_value=None)  # No duplicate
        mock_db.content.insert_one = AsyncMock()
        mock_db.content.delete_one = AsyncMock()
        mock_db.content.update_one = AsyncMock()
        mock_db.users.find_one = AsyncMock(return_value={"full_name": "Test User"})

        # Track what was called
        insert_called = False
        delete_called = False

        async def track_insert(*args):
            nonlocal insert_called
            insert_called = True

        async def track_delete(*args):
            nonlocal delete_called
            delete_called = True

        mock_db.content.insert_one = track_insert
        mock_db.content.delete_one = track_delete

        # Mock parser and chunker
        mock_parser = MagicMock()
        mock_parser.parse_document.return_value = {
            'content': 'Test content',
            'metadata': {'page_count': 1, 'tables': [], 'figures': []},
            'structure': []
        }

        mock_chunker = MagicMock()
        mock_chunker.chunk_document.return_value = [
            {'text': 'chunk1', 'token_count': 10, 'chunk_index': 0, 'metadata': {}}
        ]

        # Mock RabbitMQ publisher to FAIL
        mock_publisher = MagicMock()
        mock_publisher.publish_chunks = AsyncMock(
            side_effect=Exception("Connection refused to RabbitMQ")
        )

        # Test that cleanup happens
        with patch('main.docling_parser', mock_parser), \
             patch('main.chunker', mock_chunker), \
             patch('main.rabbitmq_publisher', mock_publisher), \
             patch('main.save_uploaded_file', return_value='/tmp/test.pdf'), \
             patch('main.content_hasher.generate_content_hash', return_value='abc123'), \
             patch('os.remove'):

            # Import after patching
            import sys
            sys.path.insert(0, '..')

            # Simulate process_single_document behavior
            mongodb_inserted = False
            content_id = "test-123"

            try:
                # Simulate: Insert to MongoDB
                await track_insert({})
                mongodb_inserted = True

                # Simulate: Try to publish (fails)
                await mock_publisher.publish_chunks([], content_id)

            except Exception as e:
                # Simulate: Clean up on failure
                if mongodb_inserted:
                    await track_delete({"content_id": content_id})
                    mongodb_inserted = False

                error_msg = str(e)
                assert "RabbitMQ" in error_msg

        # Verify cleanup happened
        assert insert_called, "MongoDB insert should have been called"
        assert delete_called, "MongoDB delete should have been called for cleanup"
        assert not mongodb_inserted, "mongodb_inserted flag should be False after cleanup"

    @pytest.mark.asyncio
    async def test_partial_failure_marks_document_failed(self):
        """Test 49: If cleanup delete fails, document is marked as failed."""
        mongodb_inserted = True
        cleanup_succeeded = False

        # Simulate failed cleanup (e.g., MongoDB also down)
        try:
            # Try to delete but fail
            raise Exception("MongoDB delete failed")
        except:
            # Fallback: mark as failed instead
            cleanup_succeeded = False

        # In production code, this triggers the fallback update
        if not cleanup_succeeded and mongodb_inserted:
            # Would call: await db.content.update_one({"content_id": id}, {"$set": {"status": "failed"}})
            status_updated = True

        assert status_updated, "Should mark document as failed when delete fails"


class TestIntegrationFlow:
    """Integration tests for full batch upload flow."""

    @pytest.mark.asyncio
    async def test_full_batch_upload_flow(self):
        """Test 50: Complete integration test - upload 3 files, verify all complete."""
        from unittest.mock import AsyncMock, MagicMock, patch, PropertyMock
        from io import BytesIO
        from fastapi import UploadFile
        from datetime import datetime

        # Setup: Create 3 test files
        test_files_data = [
            ("lecture1.pdf", b"PDF content for lecture 1" * 100),
            ("notes.txt", b"Text notes content" * 50),
            ("summary.md", b"# Summary\nMarkdown content" * 75),
        ]

        upload_files = []
        for filename, content in test_files_data:
            file_obj = BytesIO(content)
            upload_file = UploadFile(filename=filename, file=file_obj)
            upload_files.append(upload_file)

        # Mock MongoDB with tracking
        mock_db = MagicMock()
        batch_jobs_collection = {}
        content_collection = {}

        async def mock_count_documents(query):
            # Rate limit checks - return 0 for tests
            return 0

        async def mock_aggregate(pipeline):
            class MockCursor:
                async def to_list(self, limit):
                    return []
            return MockCursor()

        async def mock_insert_batch(doc):
            batch_jobs_collection[doc["batch_id"]] = doc

        async def mock_find_one_batch(query):
            batch_id = query.get("batch_id")
            return batch_jobs_collection.get(batch_id)

        async def mock_update_one_batch(query, update):
            batch_id = query.get("batch_id")
            if batch_id in batch_jobs_collection:
                if "$inc" in update:
                    for key, val in update["$inc"].items():
                        batch_jobs_collection[batch_id][key] = batch_jobs_collection[batch_id].get(key, 0) + val
                if "$set" in update:
                    for key, val in update["$set"].items():
                        if key.startswith("files."):
                            # Handle nested updates like files.0.status
                            parts = key.split(".")
                            idx = int(parts[1])
                            field = parts[2]
                            batch_jobs_collection[batch_id]["files"][idx][field] = val
                        else:
                            batch_jobs_collection[batch_id][key] = val

        async def mock_insert_content(doc):
            content_collection[doc["content_id"]] = doc

        async def mock_find_one_content(query):
            # No duplicates
            return None

        async def mock_find_one_user(query):
            return {"full_name": "Test Teacher"}

        mock_db.batch_jobs.count_documents = mock_count_documents
        mock_db.batch_jobs.aggregate = mock_aggregate
        mock_db.batch_jobs.insert_one = mock_insert_batch
        mock_db.batch_jobs.find_one = mock_find_one_batch
        mock_db.batch_jobs.update_one = mock_update_one_batch
        mock_db.content.insert_one = mock_insert_content
        mock_db.content.find_one = mock_find_one_content
        mock_db.users.find_one = mock_find_one_user

        # Mock parser
        mock_parser = MagicMock()
        mock_parser.parse_document.return_value = {
            'content': 'Parsed document content',
            'metadata': {'page_count': 3, 'tables': [], 'figures': []},
            'structure': []
        }

        # Mock chunker
        mock_chunker = MagicMock()
        mock_chunker.chunk_document.return_value = [
            {'text': 'chunk1', 'token_count': 50, 'chunk_index': 0, 'metadata': {}},
            {'text': 'chunk2', 'token_count': 60, 'chunk_index': 1, 'metadata': {}},
            {'text': 'chunk3', 'token_count': 40, 'chunk_index': 2, 'metadata': {}},
        ]

        # Mock RabbitMQ publisher (successful)
        mock_publisher = MagicMock()
        mock_publisher.publish_chunks = AsyncMock(return_value=None)

        # Mock WebSocket manager
        mock_ws_manager = MagicMock()
        mock_ws_manager.publish_status = AsyncMock()

        # Mock other dependencies
        with patch('main.get_mongodb', return_value=mock_db), \
             patch('main.docling_parser', mock_parser), \
             patch('main.chunker', mock_chunker), \
             patch('main.rabbitmq_publisher', mock_publisher), \
             patch('main.save_uploaded_file', side_effect=lambda f, c: f'/tmp/{f}'), \
             patch('main.content_hasher.generate_content_hash', side_effect=lambda c: f'hash_{len(c)}'), \
             patch('main.mongodb_client.get_database', return_value=mock_db), \
             patch('websocket_handler.manager', mock_ws_manager), \
             patch('os.remove'):

            # Import the function to test
            from main import bulk_upload, process_batch_files_streaming

            # Step 1: Call bulk_upload endpoint
            response = await bulk_upload(
                files=upload_files,
                user_id="teacher123",
                title_prefix="Physics",
                subject="Physics",
                tags="quantum,mechanics",
                db=mock_db
            )

            # Verify immediate response
            assert response.batch_id is not None
            assert response.total_files == 3
            assert response.status == "processing"
            assert len(response.files) == 3

            batch_id = response.batch_id

            # Step 2: Verify batch job was created in MongoDB
            assert batch_id in batch_jobs_collection
            batch_job = batch_jobs_collection[batch_id]
            assert batch_job["user_id"] == "teacher123"
            assert batch_job["total_files"] == 3
            assert batch_job["status"] == "processing"
            assert len(batch_job["files"]) == 3
            assert batch_job["subject"] == "Physics"
            assert batch_job["tags"] == ["quantum", "mechanics"]

            # Step 3: Simulate background processing (normally runs via asyncio.create_task)
            # We need to prepare file_metadata similar to what bulk_upload creates
            file_metadata = []
            for idx, (upload_file, (filename, content)) in enumerate(zip(upload_files, test_files_data)):
                # Reset file position for re-reading
                upload_file.file.seek(0)
                file_metadata.append({
                    "filename": filename,
                    "extension": filename.split('.')[-1].lower(),
                    "size_bytes": len(content),
                    "upload_file": upload_file
                })

            # Run the streaming processor
            await process_batch_files_streaming(
                batch_id=batch_id,
                user_id="teacher123",
                file_metadata=file_metadata,
                title_prefix="Physics",
                subject="Physics",
                tags_list=["quantum", "mechanics"]
            )

            # Step 4: Verify all files were processed
            final_batch = batch_jobs_collection[batch_id]
            assert final_batch["completed_files"] == 3, f"Expected 3 completed, got {final_batch['completed_files']}"
            assert final_batch["failed_files"] == 0, f"Expected 0 failed, got {final_batch['failed_files']}"
            assert final_batch["status"] == "completed"

            # Step 5: Verify each file status
            for idx, file_status in enumerate(final_batch["files"]):
                assert file_status["status"] == "completed", f"File {idx} should be completed"
                assert file_status.get("content_id") is not None, f"File {idx} should have content_id"

            # Step 6: Verify content was saved to MongoDB
            assert len(content_collection) == 3, f"Expected 3 documents, got {len(content_collection)}"

            # Step 7: Verify RabbitMQ was called for each file
            assert mock_publisher.publish_chunks.call_count == 3

            # Step 8: Verify WebSocket events were published
            assert mock_ws_manager.publish_status.call_count > 0

            # Step 9: Verify parser and chunker were called for each file
            assert mock_parser.parse_document.call_count == 3
            assert mock_chunker.chunk_document.call_count == 3

    @pytest.mark.asyncio
    async def test_batch_upload_with_partial_failures(self):
        """Test 51: Integration test where 1 of 3 files fails."""
        from unittest.mock import AsyncMock, MagicMock, patch
        from io import BytesIO
        from fastapi import UploadFile

        # Setup: 3 files, middle one will fail
        test_files_data = [
            ("good1.pdf", b"Good content 1" * 100),
            ("bad.pdf", b"This will fail" * 100),
            ("good2.txt", b"Good content 2" * 50),
        ]

        upload_files = []
        for filename, content in test_files_data:
            file_obj = BytesIO(content)
            upload_file = UploadFile(filename=filename, file=file_obj)
            upload_files.append(upload_file)

        # Track processing
        processing_results = {}

        mock_db = MagicMock()
        batch_jobs_collection = {}

        async def mock_count_documents(query):
            return 0

        async def mock_aggregate(pipeline):
            class MockCursor:
                async def to_list(self, limit):
                    return []
            return MockCursor()

        async def mock_insert_batch(doc):
            batch_jobs_collection[doc["batch_id"]] = doc

        async def mock_update_one_batch(query, update):
            batch_id = query.get("batch_id")
            if batch_id in batch_jobs_collection:
                if "$inc" in update:
                    for key, val in update["$inc"].items():
                        batch_jobs_collection[batch_id][key] = batch_jobs_collection[batch_id].get(key, 0) + val
                if "$set" in update:
                    for key, val in update["$set"].items():
                        if key.startswith("files."):
                            parts = key.split(".")
                            idx = int(parts[1])
                            field = parts[2]
                            batch_jobs_collection[batch_id]["files"][idx][field] = val
                        else:
                            batch_jobs_collection[batch_id][key] = val

        async def mock_find_one_content(query):
            return None

        async def mock_insert_content(doc):
            pass

        async def mock_find_one_user(query):
            return {"full_name": "Test User"}

        mock_db.batch_jobs.count_documents = mock_count_documents
        mock_db.batch_jobs.aggregate = mock_aggregate
        mock_db.batch_jobs.insert_one = mock_insert_batch
        mock_db.batch_jobs.update_one = mock_update_one_batch
        mock_db.content.find_one = mock_find_one_content
        mock_db.content.insert_one = mock_insert_content
        mock_db.users.find_one = mock_find_one_user

        # Mock parser to fail on "bad.pdf"
        def mock_parse(filepath):
            if "bad.pdf" in filepath:
                raise Exception("Corrupt PDF file")
            return {
                'content': 'Content',
                'metadata': {'page_count': 1, 'tables': [], 'figures': []},
                'structure': []
            }

        mock_parser = MagicMock()
        mock_parser.parse_document.side_effect = mock_parse

        mock_chunker = MagicMock()
        mock_chunker.chunk_document.return_value = [
            {'text': 'chunk', 'token_count': 50, 'chunk_index': 0, 'metadata': {}}
        ]

        mock_publisher = MagicMock()
        mock_publisher.publish_chunks = AsyncMock()

        mock_ws_manager = MagicMock()
        mock_ws_manager.publish_status = AsyncMock()

        with patch('main.get_mongodb', return_value=mock_db), \
             patch('main.docling_parser', mock_parser), \
             patch('main.chunker', mock_chunker), \
             patch('main.rabbitmq_publisher', mock_publisher), \
             patch('main.save_uploaded_file', side_effect=lambda f, c: f'/tmp/{f}'), \
             patch('main.content_hasher.generate_content_hash', return_value='hash123'), \
             patch('main.mongodb_client.get_database', return_value=mock_db), \
             patch('websocket_handler.manager', mock_ws_manager), \
             patch('os.remove'):

            from main import bulk_upload, process_batch_files_streaming

            # Upload
            response = await bulk_upload(
                files=upload_files,
                user_id="teacher123",
                title_prefix=None,
                subject=None,
                tags=None,
                db=mock_db
            )

            batch_id = response.batch_id

            # Process
            file_metadata = []
            for idx, (upload_file, (filename, content)) in enumerate(zip(upload_files, test_files_data)):
                upload_file.file.seek(0)
                file_metadata.append({
                    "filename": filename,
                    "extension": filename.split('.')[-1].lower(),
                    "size_bytes": len(content),
                    "upload_file": upload_file
                })

            await process_batch_files_streaming(
                batch_id=batch_id,
                user_id="teacher123",
                file_metadata=file_metadata,
                title_prefix=None,
                subject=None,
                tags_list=[]
            )

            # Verify partial success
            final_batch = batch_jobs_collection[batch_id]
            assert final_batch["completed_files"] == 2, "Should have 2 completed files"
            assert final_batch["failed_files"] == 1, "Should have 1 failed file"
            assert final_batch["status"] == "completed_with_errors"

            # Verify correct file failed
            for file_status in final_batch["files"]:
                if file_status["filename"] == "bad.pdf":
                    assert file_status["status"] == "failed"
                    assert "Corrupt PDF" in file_status.get("error_message", "")
                else:
                    assert file_status["status"] == "completed"


class TestPerformance:
    """Test performance-related aspects."""

    @pytest.mark.asyncio
    async def test_concurrent_processing_faster_than_sequential(self):
        """Test 46: Concurrent processing is faster than sequential."""
        task_count = 10
        task_duration = 0.1  # 100ms per task

        async def task():
            await asyncio.sleep(task_duration)

        # Concurrent (with semaphore limiting to 5)
        semaphore = asyncio.Semaphore(5)

        async def limited_task():
            async with semaphore:
                await task()

        start = asyncio.get_event_loop().time()
        await asyncio.gather(*[limited_task() for _ in range(task_count)])
        concurrent_time = asyncio.get_event_loop().time() - start

        # Sequential would take task_count * task_duration = 1.0 seconds
        sequential_time = task_count * task_duration

        # Concurrent should be faster (roughly 2x with semaphore of 5)
        assert concurrent_time < sequential_time

    def test_memory_efficiency_with_file_contents(self):
        """Test 47: File contents are stored efficiently."""
        # Simulate file contents list
        file_contents = []
        for i in range(10):
            file_contents.append({
                "filename": f"file_{i}.pdf",
                "content": b"x" * (1024 * 1024),  # 1MB each
                "extension": "pdf",
                "size_bytes": 1024 * 1024
            })

        # Should be able to store 10 files
        assert len(file_contents) == 10

        # Total memory usage tracking
        total_bytes = sum(f["size_bytes"] for f in file_contents)
        assert total_bytes == 10 * 1024 * 1024  # 10MB


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
