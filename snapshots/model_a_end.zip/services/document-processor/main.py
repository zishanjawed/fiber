"""
Document Processing Service - Handles document upload, parsing, and chunking.
"""
from fastapi import FastAPI, UploadFile, File, Form, Depends, HTTPException, status, WebSocket
from fastapi.middleware.cors import CORSMiddleware
import os
import asyncio
from uuid import uuid4
from datetime import datetime
from typing import List

from parsers.docling_parser import DoclingParser, save_uploaded_file
from chunking.chunker_factory import get_chunker
from publisher.rabbitmq_publisher import rabbitmq_publisher
from models.schemas import (
    DocumentUploadResponse,
    ContentMetadata,
    BatchJob,
    BatchFileStatus,
    BatchUploadResponse,
    BatchStatusResponse
)
from deletion_service import deletion_service
from config import settings
from shared.database.mongodb_client import mongodb_client, get_mongodb
from shared.database.redis_client import redis_client
from shared.observability.langfuse_client import langfuse_client
from shared.middleware.error_handler import register_exception_handlers
from shared.exceptions.custom_exceptions import (
    DocumentProcessingError,
    ValidationError,
    FileValidationError
)
from shared.logging.logger import get_logger
from shared.utils.content_hash import content_hasher

logger = get_logger(settings.service_name, settings.log_level)

# Create FastAPI app
app = FastAPI(
    title="RAG Edtech - Document Processor",
    description="Document upload, parsing, and chunking service",
    version="1.0.0"
)

# Add CORS middleware (centralized configuration)
from shared.middleware.cors_config import configure_cors
configure_cors(app, settings.cors_origins)

# Register exception handlers
register_exception_handlers(app)

# Initialize parser and chunker
docling_parser = DoclingParser()

# Get chunker from factory (configured via CHUNKING_STRATEGY env var)
try:
    chunker = get_chunker(
        strategy=getattr(settings, 'chunking_strategy', None),
        max_tokens=settings.chunk_size,
        chunk_overlap=settings.chunk_overlap,
        merge_peers=getattr(settings, 'chunking_merge_peers', True)
    )
    chunking_strategy = getattr(settings, 'chunking_strategy', os.getenv('CHUNKING_STRATEGY', 'docling'))
    logger.info(f"[OK] Chunker initialized with strategy: {chunking_strategy}")
except Exception as e:
    logger.error(f"Failed to initialize chunker: {str(e)}")
    raise


@app.on_event("startup")
async def startup_event():
    """Initialize connections on startup."""
    logger.info("Starting Document Processing Service...")
    
    # Connect to MongoDB
    await mongodb_client.connect(
        settings.mongodb_url,
        settings.mongodb_database
    )
    
    # Connect to RabbitMQ
    await rabbitmq_publisher.connect(settings.rabbitmq_url)
    
    # Initialize Langfuse
    if settings.langfuse_public_key and settings.langfuse_secret_key:
        langfuse_client.initialize(
            settings.langfuse_public_key,
            settings.langfuse_secret_key,
            settings.langfuse_host
        )
    
    # Create indexes
    db = mongodb_client.get_database()
    await db.content.create_index("content_id")
    await db.content.create_index("user_id")
    await db.content.create_index("upload_date")
    await db.content.create_index("content_hash")  # For deduplication
    await db.content.create_index("original_uploader_id")  # For traceability
    await db.content.create_index("parent_content_id")  # For version tracking
    await db.content.create_index("tags")  # For filtering by tags
    await db.suggested_questions.create_index("content_id")  # For question lookups
    await db.suggested_questions.create_index("created_at")  # For sorting

    # Batch jobs indexes
    await db.batch_jobs.create_index("batch_id")
    await db.batch_jobs.create_index("user_id")
    await db.batch_jobs.create_index("status")
    await db.batch_jobs.create_index("created_at")

    logger.info("Document Processing Service started successfully")


@app.on_event("shutdown")
async def shutdown_event():
    """Cleanup on shutdown."""
    logger.info("Shutting down Document Processing Service...")
    await mongodb_client.disconnect()
    await rabbitmq_publisher.disconnect()
    
    # Properly shutdown Langfuse (flush all pending traces)
    if langfuse_client.is_enabled():
        langfuse_client.shutdown()
    
    logger.info("Document Processing Service shut down successfully")


@app.get("/health")
async def health_check():
    """Health check endpoint."""
    mongo_healthy = await mongodb_client.health_check()
    
    return {
        "status": "healthy" if mongo_healthy else "unhealthy",
        "service": "document-processor",
        "mongodb": "connected" if mongo_healthy else "disconnected",
        "rabbitmq": "connected" if rabbitmq_publisher.connection else "disconnected"
    }


@app.websocket("/ws/document/{content_id}/status")
async def websocket_status_endpoint(websocket: WebSocket, content_id: str):
    """
    WebSocket endpoint for real-time document processing status updates.
    
    Usage:
        const ws = new WebSocket('ws://localhost:8002/ws/document/{content_id}/status')
        ws.onmessage = (event) => {
            const status = JSON.parse(event.data)
            // status: { status, progress, processed_chunks, total_chunks, message }
        }
    """
    from websocket_handler import websocket_endpoint
    await websocket_endpoint(websocket, content_id)


@app.delete("/api/content/{content_id}")
async def delete_content(
    content_id: str,
    user_id: str,
    db=Depends(get_mongodb)
):
    """
    Delete a document and all associated data.
    
    This performs a complete deletion:
    - MongoDB content record
    - Pinecone vectors (entire namespace)
    - Physical file from uploads directory
    - Redis cache entries
    - Related questions
    
    Args:
        content_id: Content ID to delete
        user_id: User requesting deletion (from auth middleware)
        db: MongoDB database instance
    
    Returns:
        Deletion confirmation
    
    Raises:
        HTTPException: If document not found or user lacks permission
    """
    logger.info(f"Delete request for content {content_id} by user {user_id}")
    
    # Get document from MongoDB
    content_doc = await db.content.find_one({"content_id": content_id})
    
    if not content_doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document {content_id} not found"
        )
    
    # Get user to check permissions
    user = await db.users.find_one({"user_id": user_id})
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found"
        )
    
    # Check permissions: User must be the owner or a teacher
    is_owner = content_doc.get('user_id') == user_id or content_doc.get('original_uploader_id') == user_id
    is_teacher = user.get('role') == 'teacher'
    is_uploader = any(
        entry.get('user_id') == user_id 
        for entry in content_doc.get('upload_history', [])
    )
    
    if not (is_owner or is_teacher or is_uploader):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to delete this document"
        )
    
    logger.info(f"Permission granted for deletion (owner: {is_owner}, teacher: {is_teacher}, uploader: {is_uploader})")
    
    # Perform complete deletion
    deletion_stats = await deletion_service.delete_document_complete(
        content_id=content_id,
        pinecone_client=None  # Will be handled by separate service if needed
    )
    
    return {
        "content_id": content_id,
        "filename": content_doc.get('filename'),
        "message": "Document deleted successfully",
        "deletion_stats": deletion_stats
    }


@app.post("/api/content/upload", response_model=DocumentUploadResponse)
async def upload_content(
    file: UploadFile = File(...),
    user_id: str = Form(...),
    title: str = Form(None),
    description: str = Form(None),
    subject: str = Form(None),
    tags: str = Form(None),  # Comma-separated tags
    instructor_id: str = Form(None),
    grade_level: str = Form(None),  # Optional, kept for backward compatibility
    db=Depends(get_mongodb)
):
    """
    Upload and process educational content.
    
    Args:
        file: Uploaded file (PDF, MD, TXT, DOCX)
        user_id: ID of the user uploading the content
        title: Optional content title
        description: Optional content description
        subject: Optional subject area - accepts any string (e.g., Chemistry, Physics, Biology)
        tags: Optional comma-separated tags for filtering
        instructor_id: Optional instructor/teacher ID
        grade_level: Optional grade level (backward compatibility)
        db: MongoDB database instance
    
    Returns:
        Upload response with content ID and status
    
    Raises:
        FileValidationError: If file validation fails
        DocumentProcessingError: If processing fails
    """
    logger.info(f"Upload request from user {user_id}: {file.filename} " +
                (f"({subject})" if subject else ""))
    
    # Validate file type
    file_extension = file.filename.split('.')[-1].lower()
    if file_extension not in ['pdf', 'md', 'txt', 'docx', 'doc']:
        raise FileValidationError(
            "Unsupported file type. Allowed types: PDF, MD, TXT, DOCX",
            details={"filename": file.filename, "extension": file_extension}
        )
    
    # Validate file size
    file_content = await file.read()
    file_size_mb = len(file_content) / (1024 * 1024)
    
    if file_size_mb > settings.max_file_size_mb:
        raise FileValidationError(
            f"File too large. Maximum size: {settings.max_file_size_mb}MB",
            details={"file_size_mb": file_size_mb, "max_size_mb": settings.max_file_size_mb}
        )
    
    # Generate content ID
    content_id = str(uuid4())
    
    # Prepare langfuse tags (different from document tags)
    langfuse_tags = ["document_upload"]
    if subject:
        langfuse_tags.append(subject.lower())
    if grade_level:
        langfuse_tags.append(f"grade_{grade_level}")
    
    # Start Langfuse trace with enhanced metadata
    trace = None
    if langfuse_client.is_enabled():
        try:
            trace = langfuse_client.client.trace(
                name="document_upload",
                user_id=user_id,
                metadata={
                    "content_id": content_id,
                    "filename": file.filename,
                    "file_size_mb": round(file_size_mb, 2),
                    "file_type": file_extension,
                    "title": title,
                    "subject": subject,
                    "grade_level": grade_level,
                    "instructor_id": instructor_id,
                    "description": description
                },
                tags=langfuse_tags
            )
        except Exception as e:
            logger.warning(f"Failed to create Langfuse trace: {str(e)}")
    
    try:
        # Save file temporarily
        file_path = save_uploaded_file(file_content, file.filename)
        
        logger.info(f"Processing document: {file_path}")
        
        # Parse document with observations
        with langfuse_client.create_observation(
            name="parse_document",
            trace_id=trace.id if trace else None,
            input_data={"filename": file.filename, "file_type": file_extension, "file_size_mb": round(file_size_mb, 2)}
        ) as parse_obs:
            parsed_doc = docling_parser.parse_document(file_path, file_extension)
            
            parse_obs.set_output({
                "title": parsed_doc['title'],
                "page_count": parsed_doc['metadata'].get('page_count', 1),
                "content_length": len(parsed_doc['content']),
                "tables_found": len(parsed_doc['metadata'].get('tables', [])),
                "figures_found": len(parsed_doc['metadata'].get('figures', []))
            })
        
        # Chunk document with observations
        with langfuse_client.create_observation(
            name="chunk_document",
            trace_id=trace.id if trace else None,
            input_data={"content_length": len(parsed_doc['content'])},
            metadata={"chunking_strategy": os.getenv('CHUNKING_STRATEGY', 'token_based')}
        ) as chunk_obs:
            chunks = chunker.chunk_document(
                content=parsed_doc['content'],
                metadata=parsed_doc['metadata'],
                structure=parsed_doc['structure']
            )
            
            # Calculate chunk statistics
            chunk_sizes = [chunk.get('token_count', 0) for chunk in chunks]
            avg_chunk_size = sum(chunk_sizes) / len(chunk_sizes) if chunk_sizes else 0
            
            chunk_obs.set_output({
                "total_chunks": len(chunks),
                "avg_chunk_size": round(avg_chunk_size, 1),
                "min_chunk_size": min(chunk_sizes) if chunk_sizes else 0,
                "max_chunk_size": max(chunk_sizes) if chunk_sizes else 0,
                "chunking_strategy": chunks[0]['metadata'].get('chunking_strategy', 'unknown') if chunks else 'unknown'
            })
        
        logger.info(f"Created {len(chunks)} chunks from document {file.filename}")
        
        # Generate content hash for deduplication
        content_hash = content_hasher.generate_content_hash(parsed_doc['content'])
        logger.info(f"Generated content hash: {content_hash[:16]}...")
        
        # Check for duplicate content
        existing_doc = await db.content.find_one({"content_hash": content_hash})
        
        if existing_doc:
            # Duplicate found - update upload history instead of reprocessing
            logger.info(f"Duplicate content detected! Existing content_id: {existing_doc['content_id']}")
            
            # Get uploader name
            user = await db.users.find_one({"user_id": user_id})
            uploader_name = user.get('full_name', 'Unknown') if user else 'Unknown'
            
            # Add to upload history
            upload_history_entry = {
                "user_id": user_id,
                "user_name": uploader_name,
                "upload_date": datetime.utcnow(),
                "filename": file.filename,
                "content_hash": content_hash
            }
            
            await db.content.update_one(
                {"content_id": existing_doc['content_id']},
                {
                    "$push": {"upload_history": upload_history_entry},
                    "$set": {"updated_at": datetime.utcnow()}
                }
            )
            
            logger.info(f"Added upload history entry for user {uploader_name}")
            
            # Return response indicating duplicate
            return DocumentUploadResponse(
                content_id=existing_doc['content_id'],
                filename=file.filename,
                file_type=file_extension,
                status=existing_doc.get('status', 'completed'),
                total_chunks=existing_doc.get('total_chunks', 0),
                message="Document already exists in knowledge base. Linked to your account.",
                is_duplicate=True,
                duplicate_of=existing_doc['content_id']
            )
        
        # New document - process normally
        logger.info("New document - processing...")
        
        # Get uploader name for tracking
        user = await db.users.find_one({"user_id": user_id})
        uploader_name = user.get('full_name', 'Unknown') if user else 'Unknown'
        
        # Create initial upload history entry
        upload_history_entry = {
            "user_id": user_id,
            "user_name": uploader_name,
            "upload_date": datetime.utcnow(),
            "filename": file.filename,
            "content_hash": content_hash
        }
        
        # Parse tags from comma-separated string
        tags_list = []
        if tags:
            tags_list = [tag.strip() for tag in tags.split(',') if tag.strip()]
        
        # Store metadata in MongoDB with deduplication fields
        content_metadata = ContentMetadata(
            content_id=content_id,
            filename=file.filename,
            file_type=file_extension,
            user_id=user_id,
            content_hash=content_hash,
            is_duplicate=False,
            original_uploader_id=user_id,
            original_upload_date=datetime.utcnow(),
            upload_history=[upload_history_entry],
            version_number=1,
            parent_content_id=None,
            status="processing",
            total_chunks=len(chunks),
            tags=tags_list,  # Store parsed tags
            metadata={
                "title": parsed_doc['title'],
                "page_count": parsed_doc['metadata'].get('page_count', 1),
                "file_size": file_size_mb,
                "tables": len(parsed_doc['metadata'].get('tables', [])),
                "figures": len(parsed_doc['metadata'].get('figures', [])),
                "uploader_name": uploader_name,
                "subject": subject or "General",
                "grade_level": grade_level or ""
            }
        )
        
        await db.content.insert_one(content_metadata.model_dump())
        
        # Enhance chunks with source metadata before publishing
        for chunk in chunks:
            chunk['metadata']['document_title'] = parsed_doc['title']
            chunk['metadata']['uploader_name'] = uploader_name
            chunk['metadata']['uploader_id'] = user_id
            chunk['metadata']['upload_date'] = datetime.utcnow().isoformat()
            chunk['metadata']['subject'] = subject or "General"
            chunk['metadata']['grade_level'] = grade_level or ""
            chunk['metadata']['tags'] = tags_list
        
        # Publish chunks to RabbitMQ with observations
        with langfuse_client.create_observation(
            name="publish_chunks",
            trace_id=trace.id if trace else None,
            input_data={"chunk_count": len(chunks), "content_id": content_id}
        ) as publish_obs:
            await rabbitmq_publisher.publish_chunks(chunks, content_id)
            publish_obs.set_output({"published": True, "chunk_count": len(chunks)})
        
        # Publish WebSocket status update
        try:
            from websocket_handler import manager
            await manager.publish_status(content_id, {
                "status": "processing",
                "progress": 10,
                "processed_chunks": 0,
                "total_chunks": len(chunks),
                "message": f"Processing {len(chunks)} chunks..."
            })
        except Exception as e:
            logger.warning(f"Failed to publish WebSocket status: {e}")
        
        # Clean up temp file
        try:
            os.remove(file_path)
        except Exception:
            pass
        
        # Update trace with final output
        if trace:
            try:
                trace.update(
                    output={
                        "content_id": content_id,
                        "status": "processing",
                        "total_chunks": len(chunks)
                    },
                    metadata={
                        "content_id": content_id,
                        "filename": file.filename,
                        "file_type": file_extension,
                        "chunks_created": len(chunks),
                        "avg_chunk_size": round(avg_chunk_size, 1),
                        "subject": subject,
                        "grade_level": grade_level
                    }
                )
            except Exception as e:
                logger.warning(f"Failed to update trace: {str(e)}")
        
        logger.info(f"Successfully processed document {file.filename} (content_id: {content_id})")
        
        # Generate suggested questions in background (don't block upload response)
        import asyncio
        asyncio.create_task(
            generate_and_store_questions(
                content_id=content_id,
                title=parsed_doc['title'],
                subject=subject or "General",
                content_preview=parsed_doc['content'],
                tags=tags_list
            )
        )
        
        return DocumentUploadResponse(
            content_id=content_id,
            filename=file.filename,
            file_type=file_extension,
            status="processing",
            total_chunks=len(chunks),
            message=f"Document uploaded successfully. Processing {len(chunks)} chunks."
        )

    except Exception as e:
        # Update status to failed
        await db.content.update_one(
            {"content_id": content_id},
            {"$set": {"status": "failed"}}
        )

        # Log error to trace
        if trace:
            try:
                trace.update(
                    level="ERROR",
                    status_message=str(e),
                    metadata={
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                        "filename": file.filename
                    }
                )
            except Exception as update_error:
                logger.warning(f"Failed to log error to trace: {str(update_error)}")

        logger.error(f"Failed to process document {file.filename}: {str(e)}")

        raise DocumentProcessingError(
            f"Failed to process document: {str(e)}",
            details={"filename": file.filename, "content_id": content_id}
        )


# ============================================================================
# Bulk Upload Endpoints
# ============================================================================

# Constants for batch validation
MAX_BATCH_FILES = 50
MAX_FILE_SIZE_MB = 50
MAX_BATCH_SIZE_MB = 500
ALLOWED_EXTENSIONS = ['pdf', 'md', 'txt', 'docx', 'doc']
MAX_CONCURRENT_PROCESSING = 5
FILE_PROCESSING_TIMEOUT = 30  # seconds

# Rate limiting for batch uploads (abuse prevention)
MAX_BATCHES_PER_USER_PER_HOUR = 5
MAX_TOTAL_FILES_PER_USER_PER_DAY = 200
MAX_TOTAL_SIZE_PER_USER_PER_DAY_GB = 10
MAX_CONCURRENT_BATCHES_PER_USER = 2  # Prevent resource monopolization


@app.post("/api/documents/bulk-upload", response_model=BatchUploadResponse)
async def bulk_upload(
    files: List[UploadFile] = File(...),
    user_id: str = Form(...),
    title_prefix: str = Form(None),
    subject: str = Form(None),
    tags: str = Form(None),
    db=Depends(get_mongodb)
):
    """
    Bulk upload multiple documents at once.

    Validates all files upfront (without loading into memory), creates a batch job,
    and processes files concurrently with streaming.
    Returns immediately with batch_id for status tracking.

    Memory Optimization: Files are validated using seek operations, not full reads.
    Each file is only loaded into memory when being processed (max 5 concurrent = ~250MB).

    Constraints:
        - Max 50 files per batch
        - Max 50MB per file
        - Max 500MB total batch size
        - Allowed types: PDF, MD, TXT, DOCX, DOC

    Args:
        files: List of uploaded files
        user_id: User performing the upload
        title_prefix: Optional prefix for document titles
        subject: Optional subject for all documents
        tags: Optional comma-separated tags for all documents

    Returns:
        BatchUploadResponse with batch_id for tracking

    Raises:
        FileValidationError: If any validation fails (rejects entire batch)
    """
    logger.info(f"Bulk upload request from user {user_id}: {len(files)} files")

    # ABUSE PREVENTION: Check user's batch upload history
    one_hour_ago = datetime.utcnow() - __import__('datetime').timedelta(hours=1)
    one_day_ago = datetime.utcnow() - __import__('datetime').timedelta(days=1)

    # Count batches in last hour
    batches_last_hour = await db.batch_jobs.count_documents({
        "user_id": user_id,
        "created_at": {"$gte": one_hour_ago}
    })

    if batches_last_hour >= MAX_BATCHES_PER_USER_PER_HOUR:
        logger.warning(f"User {user_id} exceeded batch rate limit: {batches_last_hour} batches in last hour")
        raise FileValidationError(
            f"Too many batch uploads. Maximum {MAX_BATCHES_PER_USER_PER_HOUR} batches per hour.",
            details={
                "batches_last_hour": batches_last_hour,
                "max_per_hour": MAX_BATCHES_PER_USER_PER_HOUR,
                "retry_after_minutes": 60
            }
        )

    # Check concurrent batches (prevent resource monopolization)
    concurrent_batches = await db.batch_jobs.count_documents({
        "user_id": user_id,
        "status": "processing"
    })

    if concurrent_batches >= MAX_CONCURRENT_BATCHES_PER_USER:
        logger.warning(f"User {user_id} already has {concurrent_batches} batches processing")
        raise FileValidationError(
            f"You already have {concurrent_batches} batch(es) processing. Please wait for them to complete before starting another.",
            details={
                "concurrent_batches": concurrent_batches,
                "max_concurrent": MAX_CONCURRENT_BATCHES_PER_USER,
                "suggestion": "Check batch status or wait for completion"
            }
        )

    # Count total files uploaded today
    files_today_pipeline = [
        {"$match": {"user_id": user_id, "created_at": {"$gte": one_day_ago}}},
        {"$group": {"_id": None, "total_files": {"$sum": "$total_files"}, "total_bytes": {"$sum": "$total_size_bytes"}}}
    ]
    files_today_result = await db.batch_jobs.aggregate(files_today_pipeline).to_list(1)

    if files_today_result:
        total_files_today = files_today_result[0].get("total_files", 0)
        total_bytes_today = files_today_result[0].get("total_bytes", 0)

        if total_files_today + len(files) > MAX_TOTAL_FILES_PER_USER_PER_DAY:
            logger.warning(f"User {user_id} exceeded daily file limit: {total_files_today} files today")
            raise FileValidationError(
                f"Daily upload limit exceeded. You've uploaded {total_files_today} files today. Maximum: {MAX_TOTAL_FILES_PER_USER_PER_DAY}.",
                details={
                    "files_today": total_files_today,
                    "attempting": len(files),
                    "max_per_day": MAX_TOTAL_FILES_PER_USER_PER_DAY
                }
            )

        total_gb_today = total_bytes_today / (1024 * 1024 * 1024)
        # Note: Can't calculate new_batch_gb here as we haven't validated sizes yet
        # Will check again after validation loop with actual total_size_bytes
        # For now, use a rough estimate based on count (worst case: all files max size)
        estimated_new_batch_gb = len(files) * MAX_FILE_SIZE_MB / 1024  # Conservative estimate

        if total_gb_today + estimated_new_batch_gb > MAX_TOTAL_SIZE_PER_USER_PER_DAY_GB:
            logger.warning(f"User {user_id} exceeded daily size limit: {total_gb_today:.2f}GB today")
            raise FileValidationError(
                f"Daily upload size limit exceeded. You've uploaded {total_gb_today:.2f}GB today. Maximum: {MAX_TOTAL_SIZE_PER_USER_PER_DAY_GB}GB.",
                details={
                    "gb_today": round(total_gb_today, 2),
                    "attempting_gb": round(estimated_new_batch_gb, 2),
                    "max_gb_per_day": MAX_TOTAL_SIZE_PER_USER_PER_DAY_GB
                }
            )

    # Validate number of files
    if len(files) > MAX_BATCH_FILES:
        raise FileValidationError(
            f"Too many files. Maximum {MAX_BATCH_FILES} files per batch.",
            details={"file_count": len(files), "max_files": MAX_BATCH_FILES}
        )

    if len(files) == 0:
        raise FileValidationError(
            "No files provided.",
            details={"file_count": 0}
        )

    # MEMORY OPTIMIZATION: Validate files WITHOUT loading into memory
    # Only store metadata, keep UploadFile references for streaming
    total_size_bytes = 0
    file_metadata = []  # Lightweight metadata only
    batch_files = []

    for idx, file in enumerate(files):
        # Validate file type (no read needed)
        file_extension = file.filename.split('.')[-1].lower() if '.' in file.filename else ''
        if file_extension not in ALLOWED_EXTENSIONS:
            raise FileValidationError(
                f"Invalid file type for '{file.filename}'. Allowed types: {', '.join(ALLOWED_EXTENSIONS).upper()}",
                details={
                    "filename": file.filename,
                    "extension": file_extension,
                    "file_index": idx,
                    "allowed": ALLOWED_EXTENSIONS
                }
            )

        # Get file size using seek (no full read into memory)
        file.file.seek(0, 2)  # Seek to end
        file_size = file.file.tell()
        file.file.seek(0)  # Reset to beginning for later reading
        file_size_mb = file_size / (1024 * 1024)

        if file_size_mb > MAX_FILE_SIZE_MB:
            raise FileValidationError(
                f"File '{file.filename}' is too large ({file_size_mb:.2f}MB). Maximum: {MAX_FILE_SIZE_MB}MB",
                details={
                    "filename": file.filename,
                    "file_size_mb": round(file_size_mb, 2),
                    "max_size_mb": MAX_FILE_SIZE_MB,
                    "file_index": idx
                }
            )

        total_size_bytes += file_size

        # Store only metadata, NOT the file content
        file_metadata.append({
            "filename": file.filename,
            "extension": file_extension,
            "size_bytes": file_size,
            "upload_file": file  # Keep reference to UploadFile for streaming
        })

        # Create file status entry
        batch_files.append(BatchFileStatus(
            filename=file.filename,
            file_index=idx,
            status="pending"
        ))

    # Validate total batch size
    total_size_mb = total_size_bytes / (1024 * 1024)
    if total_size_mb > MAX_BATCH_SIZE_MB:
        raise FileValidationError(
            f"Total batch size ({total_size_mb:.2f}MB) exceeds maximum ({MAX_BATCH_SIZE_MB}MB)",
            details={
                "total_size_mb": round(total_size_mb, 2),
                "max_batch_size_mb": MAX_BATCH_SIZE_MB,
                "file_count": len(files)
            }
        )

    # Parse tags
    tags_list = []
    if tags:
        tags_list = [tag.strip() for tag in tags.split(',') if tag.strip()]

    # Create batch job
    batch_id = str(uuid4())
    batch_job = BatchJob(
        batch_id=batch_id,
        user_id=user_id,
        total_files=len(files),
        status="processing",
        files=batch_files,
        total_size_bytes=total_size_bytes,
        subject=subject,
        tags=tags_list
    )

    # Store batch job in MongoDB
    await db.batch_jobs.insert_one(batch_job.model_dump())
    logger.info(f"Created batch job {batch_id} with {len(files)} files (total: {total_size_mb:.2f}MB)")

    # Publish initial batch status via WebSocket
    try:
        from websocket_handler import manager
        await manager.publish_status(f"batch:{batch_id}", {
            "type": "batch_started",
            "batch_id": batch_id,
            "total_files": len(files),
            "status": "processing",
            "message": f"Starting batch upload of {len(files)} files..."
        })
    except Exception as e:
        logger.warning(f"Failed to publish batch start event: {e}")

    # Start background processing task with streaming
    asyncio.create_task(
        process_batch_files_streaming(
            batch_id=batch_id,
            user_id=user_id,
            file_metadata=file_metadata,
            title_prefix=title_prefix,
            subject=subject,
            tags_list=tags_list
        )
    )

    # Return response immediately
    return BatchUploadResponse(
        batch_id=batch_id,
        total_files=len(files),
        status="processing",
        message=f"Batch upload started. Processing {len(files)} files.",
        files=[
            {
                "filename": f["filename"],
                "size_mb": round(f["size_bytes"] / (1024 * 1024), 2),
                "status": "pending"
            }
            for f in file_metadata
        ]
    )


async def process_batch_files_streaming(
    batch_id: str,
    user_id: str,
    file_metadata: List[dict],
    title_prefix: str,
    subject: str,
    tags_list: List[str]
):
    """
    Process multiple files concurrently with streaming (memory-optimized).

    Uses asyncio.Semaphore to limit concurrent processing.
    Files are read into memory only when being processed, then immediately freed.
    Max memory usage: 5 files * 50MB = 250MB (vs 2.5GB for all files at once).

    Updates batch status in MongoDB and publishes WebSocket events.
    """
    db = mongodb_client.get_database()
    semaphore = asyncio.Semaphore(MAX_CONCURRENT_PROCESSING)

    async def process_single_file_streaming(file_info: dict, file_index: int):
        """Process a single file within the batch with streaming."""
        async with semaphore:
            filename = file_info["filename"]
            upload_file = file_info["upload_file"]
            logger.info(f"Batch {batch_id}: Processing file {file_index + 1}/{len(file_metadata)}: {filename}")

            # Update file status to processing
            await update_batch_file_status(
                db, batch_id, file_index, "processing", started_at=datetime.utcnow()
            )

            # Publish progress event
            await publish_batch_progress(batch_id, file_index, "processing", filename)

            file_content = None
            try:
                # READ FILE INTO MEMORY ONLY NOW (inside semaphore)
                # This limits memory to max 5 concurrent files
                file_content = await upload_file.read()
                logger.debug(f"Batch {batch_id}: Loaded {filename} into memory ({len(file_content)} bytes)")

                # Apply timeout to file processing
                result = await asyncio.wait_for(
                    process_single_document(
                        file_content=file_content,
                        filename=filename,
                        file_extension=file_info["extension"],
                        user_id=user_id,
                        title_prefix=title_prefix,
                        subject=subject,
                        tags_list=tags_list,
                        db=db
                    ),
                    timeout=FILE_PROCESSING_TIMEOUT
                )

                # Update file status to completed
                await update_batch_file_status(
                    db, batch_id, file_index, "completed",
                    content_id=result.get("content_id"),
                    is_duplicate=result.get("is_duplicate", False),
                    duplicate_of=result.get("duplicate_of"),
                    total_chunks=result.get("total_chunks", 0),
                    completed_at=datetime.utcnow()
                )

                # Update batch counters
                await db.batch_jobs.update_one(
                    {"batch_id": batch_id},
                    {
                        "$inc": {"completed_files": 1},
                        "$set": {"updated_at": datetime.utcnow()}
                    }
                )

                # Publish success event
                await publish_batch_progress(
                    batch_id, file_index, "completed", filename,
                    content_id=result.get("content_id"),
                    is_duplicate=result.get("is_duplicate", False)
                )

                logger.info(f"Batch {batch_id}: Completed file {filename}")

            except asyncio.TimeoutError:
                error_msg = f"Processing timeout after {FILE_PROCESSING_TIMEOUT} seconds"
                logger.error(f"Batch {batch_id}: {error_msg} for {filename}")

                await update_batch_file_status(
                    db, batch_id, file_index, "failed",
                    error_message=error_msg,
                    completed_at=datetime.utcnow()
                )

                await db.batch_jobs.update_one(
                    {"batch_id": batch_id},
                    {
                        "$inc": {"failed_files": 1},
                        "$set": {"updated_at": datetime.utcnow()}
                    }
                )

                await publish_batch_progress(batch_id, file_index, "failed", filename, error=error_msg)

            except Exception as e:
                error_msg = str(e)
                logger.error(f"Batch {batch_id}: Failed to process {filename}: {error_msg}")

                await update_batch_file_status(
                    db, batch_id, file_index, "failed",
                    error_message=error_msg,
                    completed_at=datetime.utcnow()
                )

                await db.batch_jobs.update_one(
                    {"batch_id": batch_id},
                    {
                        "$inc": {"failed_files": 1},
                        "$set": {"updated_at": datetime.utcnow()}
                    }
                )

                await publish_batch_progress(batch_id, file_index, "failed", filename, error=error_msg)

            finally:
                # CRITICAL: Free memory immediately after processing
                if file_content is not None:
                    del file_content
                    logger.debug(f"Batch {batch_id}: Released memory for {filename}")

    # Process all files concurrently (semaphore limits to 5 at once)
    tasks = [
        process_single_file_streaming(file_info, idx)
        for idx, file_info in enumerate(file_metadata)
    ]

    await asyncio.gather(*tasks)

    # Update batch status to completed
    batch = await db.batch_jobs.find_one({"batch_id": batch_id})
    final_status = "completed" if batch["failed_files"] == 0 else "completed_with_errors"

    await db.batch_jobs.update_one(
        {"batch_id": batch_id},
        {
            "$set": {
                "status": final_status,
                "updated_at": datetime.utcnow(),
                "completed_at": datetime.utcnow()
            }
        }
    )

    # Publish batch completion event
    try:
        from websocket_handler import manager
        await manager.publish_status(f"batch:{batch_id}", {
            "type": "batch_completed",
            "batch_id": batch_id,
            "status": final_status,
            "total_files": batch["total_files"],
            "completed_files": batch["completed_files"],
            "failed_files": batch["failed_files"],
            "message": f"Batch processing complete. {batch['completed_files']} succeeded, {batch['failed_files']} failed."
        })
    except Exception as e:
        logger.warning(f"Failed to publish batch completion event: {e}")

    logger.info(f"Batch {batch_id} completed: {batch['completed_files']} success, {batch['failed_files']} failed")


async def process_batch_files(
    batch_id: str,
    user_id: str,
    file_contents: List[dict],
    title_prefix: str,
    subject: str,
    tags_list: List[str]
):
    """
    DEPRECATED: Old non-streaming version. Use process_batch_files_streaming instead.
    Kept for backward compatibility.
    """
    # Redirect to streaming version by wrapping file_contents
    file_metadata = [
        {
            "filename": f["filename"],
            "extension": f["extension"],
            "size_bytes": f["size_bytes"],
            "upload_file": type('MockUploadFile', (), {
                'read': lambda self=f: asyncio.coroutine(lambda: f["content"])()
            })()
        }
        for f in file_contents
    ]

    await process_batch_files_streaming(
        batch_id, user_id, file_metadata, title_prefix, subject, tags_list
    )


async def process_single_document(
    file_content: bytes,
    filename: str,
    file_extension: str,
    user_id: str,
    title_prefix: str,
    subject: str,
    tags_list: List[str],
    db
) -> dict:
    """
    Process a single document within a batch.

    Reuses the same logic as single upload but without HTTP overhead.
    Returns dict with content_id, is_duplicate, duplicate_of, total_chunks.
    """
    content_id = str(uuid4())
    file_size_mb = len(file_content) / (1024 * 1024)
    mongodb_inserted = False  # Track if we need to cleanup on failure

    # Save file temporarily
    file_path = save_uploaded_file(file_content, filename)

    try:
        # Parse document
        parsed_doc = docling_parser.parse_document(file_path, file_extension)

        # Chunk document
        chunks = chunker.chunk_document(
            content=parsed_doc['content'],
            metadata=parsed_doc['metadata'],
            structure=parsed_doc['structure']
        )

        logger.info(f"Created {len(chunks)} chunks from document {filename}")

        # Generate content hash for deduplication
        content_hash = content_hasher.generate_content_hash(parsed_doc['content'])

        # Check for duplicate content
        existing_doc = await db.content.find_one({"content_hash": content_hash})

        if existing_doc:
            # Duplicate found - update upload history
            logger.info(f"Duplicate content detected for {filename}! Existing: {existing_doc['content_id']}")

            user = await db.users.find_one({"user_id": user_id})
            uploader_name = user.get('full_name', 'Unknown') if user else 'Unknown'

            upload_history_entry = {
                "user_id": user_id,
                "user_name": uploader_name,
                "upload_date": datetime.utcnow(),
                "filename": filename,
                "content_hash": content_hash
            }

            await db.content.update_one(
                {"content_id": existing_doc['content_id']},
                {
                    "$push": {"upload_history": upload_history_entry},
                    "$set": {"updated_at": datetime.utcnow()}
                }
            )

            return {
                "content_id": existing_doc['content_id'],
                "is_duplicate": True,
                "duplicate_of": existing_doc['content_id'],
                "total_chunks": existing_doc.get('total_chunks', 0)
            }

        # New document - process normally
        user = await db.users.find_one({"user_id": user_id})
        uploader_name = user.get('full_name', 'Unknown') if user else 'Unknown'

        upload_history_entry = {
            "user_id": user_id,
            "user_name": uploader_name,
            "upload_date": datetime.utcnow(),
            "filename": filename,
            "content_hash": content_hash
        }

        # Generate title
        title = filename.rsplit('.', 1)[0] if '.' in filename else filename
        if title_prefix:
            title = f"{title_prefix} - {title}"

        # Store metadata in MongoDB
        content_metadata = ContentMetadata(
            content_id=content_id,
            filename=filename,
            file_type=file_extension,
            user_id=user_id,
            content_hash=content_hash,
            is_duplicate=False,
            original_uploader_id=user_id,
            original_upload_date=datetime.utcnow(),
            upload_history=[upload_history_entry],
            version_number=1,
            parent_content_id=None,
            status="processing",
            total_chunks=len(chunks),
            tags=tags_list,
            metadata={
                "title": title,
                "page_count": parsed_doc['metadata'].get('page_count', 1),
                "file_size": file_size_mb,
                "tables": len(parsed_doc['metadata'].get('tables', [])),
                "figures": len(parsed_doc['metadata'].get('figures', [])),
                "uploader_name": uploader_name,
                "subject": subject or "General",
                "grade_level": ""
            }
        )

        await db.content.insert_one(content_metadata.model_dump())
        mongodb_inserted = True  # Mark that we've inserted

        # Enhance chunks with source metadata
        for chunk in chunks:
            chunk['metadata']['document_title'] = title
            chunk['metadata']['uploader_name'] = uploader_name
            chunk['metadata']['uploader_id'] = user_id
            chunk['metadata']['upload_date'] = datetime.utcnow().isoformat()
            chunk['metadata']['subject'] = subject or "General"
            chunk['metadata']['grade_level'] = ""
            chunk['metadata']['tags'] = tags_list

        # Publish chunks to RabbitMQ for vectorization
        # If this fails, we need to clean up the MongoDB record
        try:
            await rabbitmq_publisher.publish_chunks(chunks, content_id)
        except Exception as rabbitmq_error:
            logger.error(f"Failed to publish chunks to RabbitMQ for {filename}: {rabbitmq_error}")
            # Clean up orphaned MongoDB record
            await db.content.delete_one({"content_id": content_id})
            mongodb_inserted = False
            raise  # Re-raise to mark file as failed

        # Generate suggested questions in background
        asyncio.create_task(
            generate_and_store_questions(
                content_id=content_id,
                title=title,
                subject=subject or "General",
                content_preview=parsed_doc['content'],
                tags=tags_list
            )
        )

        logger.info(f"Successfully processed document {filename} (content_id: {content_id})")

        return {
            "content_id": content_id,
            "is_duplicate": False,
            "duplicate_of": None,
            "total_chunks": len(chunks)
        }

    except Exception as e:
        # Clean up partial data if MongoDB was inserted but processing failed
        if mongodb_inserted:
            try:
                await db.content.update_one(
                    {"content_id": content_id},
                    {"$set": {"status": "failed"}}
                )
                logger.info(f"Marked orphaned document {content_id} as failed")
            except Exception as cleanup_error:
                logger.error(f"Failed to clean up orphaned document: {cleanup_error}")
        raise  # Re-raise the original exception

    finally:
        # Clean up temp file
        try:
            os.remove(file_path)
        except Exception:
            pass


async def update_batch_file_status(
    db,
    batch_id: str,
    file_index: int,
    status: str,
    content_id: str = None,
    error_message: str = None,
    is_duplicate: bool = False,
    duplicate_of: str = None,
    total_chunks: int = 0,
    started_at: datetime = None,
    completed_at: datetime = None
):
    """Update the status of a specific file within a batch job."""
    update_fields = {
        f"files.{file_index}.status": status,
        "updated_at": datetime.utcnow()
    }

    if content_id:
        update_fields[f"files.{file_index}.content_id"] = content_id
    if error_message:
        update_fields[f"files.{file_index}.error_message"] = error_message
    if is_duplicate:
        update_fields[f"files.{file_index}.is_duplicate"] = is_duplicate
    if duplicate_of:
        update_fields[f"files.{file_index}.duplicate_of"] = duplicate_of
    if total_chunks:
        update_fields[f"files.{file_index}.total_chunks"] = total_chunks
    if started_at:
        update_fields[f"files.{file_index}.started_at"] = started_at
    if completed_at:
        update_fields[f"files.{file_index}.completed_at"] = completed_at

    await db.batch_jobs.update_one(
        {"batch_id": batch_id},
        {"$set": update_fields}
    )


async def publish_batch_progress(
    batch_id: str,
    file_index: int,
    status: str,
    filename: str,
    content_id: str = None,
    is_duplicate: bool = False,
    error: str = None
):
    """Publish batch file progress update via WebSocket."""
    try:
        from websocket_handler import manager

        # Get current batch status
        db = mongodb_client.get_database()
        batch = await db.batch_jobs.find_one({"batch_id": batch_id})

        if batch:
            completed = batch.get("completed_files", 0)
            failed = batch.get("failed_files", 0)
            total = batch.get("total_files", 0)
            progress = int(((completed + failed) / total) * 100) if total > 0 else 0

            event = {
                "type": "file_progress",
                "batch_id": batch_id,
                "file_index": file_index,
                "filename": filename,
                "file_status": status,
                "completed_files": completed,
                "failed_files": failed,
                "total_files": total,
                "progress": progress,
                "message": f"Processing {completed + failed}/{total} files..."
            }

            if content_id:
                event["content_id"] = content_id
            if is_duplicate:
                event["is_duplicate"] = is_duplicate
            if error:
                event["error"] = error

            await manager.publish_status(f"batch:{batch_id}", event)
    except Exception as e:
        logger.warning(f"Failed to publish batch progress: {e}")


@app.get("/api/documents/batch/{batch_id}", response_model=BatchStatusResponse)
async def get_batch_status(batch_id: str, db=Depends(get_mongodb)):
    """
    Get the current status of a batch upload job.

    Args:
        batch_id: The batch job ID

    Returns:
        BatchStatusResponse with full batch status and per-file details

    Raises:
        HTTPException: If batch not found
    """
    batch = await db.batch_jobs.find_one({"batch_id": batch_id})

    if not batch:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Batch job {batch_id} not found"
        )

    # Convert to response model
    files = [
        BatchFileStatus(**file_data) for file_data in batch.get("files", [])
    ]

    # Calculate progress percentage
    total = batch.get("total_files", 0)
    completed = batch.get("completed_files", 0)
    failed = batch.get("failed_files", 0)
    progress = ((completed + failed) / total * 100) if total > 0 else 0

    return BatchStatusResponse(
        batch_id=batch["batch_id"],
        user_id=batch["user_id"],
        total_files=total,
        completed_files=completed,
        failed_files=failed,
        status=batch["status"],
        files=files,
        created_at=batch["created_at"],
        updated_at=batch["updated_at"],
        completed_at=batch.get("completed_at"),
        progress_percentage=round(progress, 1)
    )


@app.get("/api/documents/batches/pending")
async def get_pending_batches(user_id: str, db=Depends(get_mongodb)):
    """
    Get all pending/processing batch jobs for a user.

    Allows users to reconnect to in-progress batches after page refresh
    or accidental navigation away. Prevents duplicate batch creation.

    Args:
        user_id: The user ID to check for pending batches

    Returns:
        List of pending batch jobs with their current status
    """
    # Find batches that are still processing (not completed or failed)
    pending_batches = await db.batch_jobs.find(
        {
            "user_id": user_id,
            "status": {"$in": ["pending", "processing"]}
        }
    ).sort("created_at", -1).limit(10).to_list(10)

    # Format response with summary info
    result = []
    for batch in pending_batches:
        total = batch.get("total_files", 0)
        completed = batch.get("completed_files", 0)
        failed = batch.get("failed_files", 0)
        progress = ((completed + failed) / total * 100) if total > 0 else 0

        result.append({
            "batch_id": batch["batch_id"],
            "total_files": total,
            "completed_files": completed,
            "failed_files": failed,
            "status": batch["status"],
            "progress_percentage": round(progress, 1),
            "created_at": batch["created_at"].isoformat() if hasattr(batch["created_at"], 'isoformat') else batch["created_at"],
            "updated_at": batch["updated_at"].isoformat() if hasattr(batch["updated_at"], 'isoformat') else batch["updated_at"],
            "files_preview": [
                {
                    "filename": f["filename"],
                    "status": f["status"]
                }
                for f in batch.get("files", [])[:5]  # First 5 files as preview
            ]
        })

    return {
        "pending_batches": result,
        "count": len(result)
    }


@app.websocket("/ws/batch/{batch_id}/status")
async def websocket_batch_status_endpoint(websocket: WebSocket, batch_id: str):
    """
    WebSocket endpoint for real-time batch upload status updates.

    Usage:
        const ws = new WebSocket('ws://localhost:8002/ws/batch/{batch_id}/status')
        ws.onmessage = (event) => {
            const data = JSON.parse(event.data)
            // Events: batch_started, file_progress, batch_completed
        }
    """
    from websocket_handler import manager

    # Use batch: prefix for channel isolation
    channel_id = f"batch:{batch_id}"
    await manager.connect(websocket, channel_id)

    try:
        # Send initial batch status
        db = mongodb_client.get_database()
        batch = await db.batch_jobs.find_one({"batch_id": batch_id})

        if batch:
            completed = batch.get("completed_files", 0)
            failed = batch.get("failed_files", 0)
            total = batch.get("total_files", 0)
            progress = int(((completed + failed) / total) * 100) if total > 0 else 0

            initial_status = {
                "type": "batch_status",
                "batch_id": batch_id,
                "status": batch["status"],
                "total_files": total,
                "completed_files": completed,
                "failed_files": failed,
                "progress": progress,
                "files": [
                    {
                        "filename": f["filename"],
                        "status": f["status"],
                        "content_id": f.get("content_id"),
                        "error_message": f.get("error_message")
                    }
                    for f in batch.get("files", [])
                ]
            }
            await websocket.send_text(__import__("json").dumps(initial_status))

        # Keep connection alive with heartbeats
        while True:
            try:
                data = await asyncio.wait_for(websocket.receive_text(), timeout=30.0)

                if data:
                    message = __import__("json").loads(data)
                    if message.get("type") == "ping":
                        await websocket.send_text(__import__("json").dumps({"type": "pong"}))

            except asyncio.TimeoutError:
                await websocket.send_text(__import__("json").dumps({"type": "heartbeat"}))

    except Exception as e:
        logger.error(f"Batch WebSocket error: {e}")
    finally:
        manager.disconnect(websocket, channel_id)


@app.get("/api/content/{content_id}/status")
async def get_content_status(content_id: str, db=Depends(get_mongodb)):
    """
    Get processing status of a content.
    
    Args:
        content_id: Content ID
        db: MongoDB database instance
    
    Returns:
        Content status information
    """
    content = await db.content.find_one({"content_id": content_id})
    
    if not content:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Content with ID {content_id} not found"
        )
    
    return {
        "content_id": content_id,
        "filename": content['filename'],
        "status": content['status'],
        "total_chunks": content['total_chunks'],
        "processed_chunks": content.get('processed_chunks', 0),
        "upload_date": content['upload_date']
    }


@app.get("/api/content/{content_id}")
async def get_content(content_id: str, db=Depends(get_mongodb)):
    """
    Get a single document by content_id.
    
    Args:
        content_id: Content ID
        db: MongoDB database instance
    
    Returns:
        Document information
    """
    content = await db.content.find_one({"content_id": content_id})
    
    if not content:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Content with ID {content_id} not found"
        )
    
    # Remove MongoDB ObjectId
    if "_id" in content:
        del content["_id"]
    
    # Convert datetime fields
    for date_field in ["upload_date", "updated_at", "original_upload_date"]:
        if date_field in content and hasattr(content[date_field], "isoformat"):
            content[date_field] = content[date_field].isoformat()
    
    # Format upload history dates
    if "upload_history" in content:
        for entry in content["upload_history"]:
            if "upload_date" in entry and hasattr(entry["upload_date"], "isoformat"):
                entry["upload_date"] = entry["upload_date"].isoformat()
    
    # Add frontend-friendly fields
    content["chunks_count"] = content.get("total_chunks", 0)
    metadata = content.get("metadata", {})
    content["title"] = metadata.get("title", content.get("filename", "Untitled"))
    content["subject"] = metadata.get("subject", "General")
    content["grade_level"] = metadata.get("grade_level", "N/A")
    content["uploader_name"] = metadata.get("uploader_name", "Unknown")
    
    return content


@app.get("/api/content/user/{user_id}")
async def get_user_documents(
    user_id: str,
    filter: str = "all",  # all, owned, shared
    search: str = None,
    subjects: str = None,  # comma-separated
    tags: str = None,  # comma-separated
    page: int = 1,
    limit: int = 50,
    db=Depends(get_mongodb)
):
    """
    Get documents for a user with filtering and search.
    
    Query Parameters:
        - filter: all/owned/shared (default: all)
        - search: search in title/subject/tags
        - subjects: comma-separated subjects to filter
        - tags: comma-separated tags to filter
        - page: page number (default: 1)
        - limit: results per page (default: 50)
    
    Returns:
        Paginated list of documents with metadata
    """
    logger.info(f"Getting documents for user {user_id}, filter={filter}, search={search}")
    
    # Build base query
    base_query = {}
    
    # Apply ownership filter
    if filter == "owned":
        base_query["user_id"] = user_id
    elif filter == "shared":
        # Documents in upload_history but not owned
        base_query = {
            "upload_history.user_id": user_id,
            "user_id": {"$ne": user_id}
        }
    else:  # all
        # Get all teacher IDs for student access
        teachers = await db.users.find({"role": "teacher"}, {"user_id": 1}).to_list(length=None)
        teacher_ids = [t["user_id"] for t in teachers]
        
        base_query = {
            "$or": [
                {"user_id": user_id},  # Student owns
                {"upload_history.user_id": user_id},  # Student uploaded
                {"user_id": {"$in": teacher_ids}},  # Teacher uploaded
                {"original_uploader_id": {"$in": teacher_ids}}  # Originally by teacher
            ]
        }
    
    # Build search/filter conditions
    conditions = []
    
    # Apply search
    if search:
        search_conditions = [
            {"metadata.title": {"$regex": search, "$options": "i"}},
            {"metadata.subject": {"$regex": search, "$options": "i"}},
            {"tags": {"$regex": search, "$options": "i"}},
            {"filename": {"$regex": search, "$options": "i"}}
        ]
        conditions.append({"$or": search_conditions})
    
    # Apply subject filter
    if subjects:
        subject_list = [s.strip() for s in subjects.split(",") if s.strip()]
        if subject_list:
            conditions.append({"metadata.subject": {"$in": subject_list}})
    
    # Apply tags filter
    if tags:
        tag_list = [t.strip() for t in tags.split(",") if t.strip()]
        if tag_list:
            conditions.append({"tags": {"$in": tag_list}})
    
    # Combine all conditions
    if conditions:
        if "$or" in base_query or "$and" in base_query:
            # If base_query already has complex logic, wrap it
            final_query = {"$and": [base_query] + conditions}
        else:
            base_query["$and"] = conditions
            final_query = base_query
    else:
        final_query = base_query
    
    # Get total count
    total = await db.content.count_documents(final_query)
    
    # Get paginated results
    skip = (page - 1) * limit
    cursor = db.content.find(final_query).sort("upload_date", -1).skip(skip).limit(limit)
    documents = await cursor.to_list(length=limit)
    
    # Enhance documents with additional fields and convert to JSON-serializable format
    result_docs = []
    for doc in documents:
        # Remove MongoDB ObjectId
        if "_id" in doc:
            del doc["_id"]
        
        # Convert datetime to ISO string
        if "upload_date" in doc and hasattr(doc["upload_date"], "isoformat"):
            doc["upload_date"] = doc["upload_date"].isoformat()
        if "updated_at" in doc and hasattr(doc["updated_at"], "isoformat"):
            doc["updated_at"] = doc["updated_at"].isoformat()
        if "original_upload_date" in doc and hasattr(doc["original_upload_date"], "isoformat"):
            doc["original_upload_date"] = doc["original_upload_date"].isoformat()
        
        # Convert upload_history dates
        if "upload_history" in doc:
            for entry in doc["upload_history"]:
                if "upload_date" in entry and hasattr(entry["upload_date"], "isoformat"):
                    entry["upload_date"] = entry["upload_date"].isoformat()
        
        # Calculate is_owned and is_shared
        doc["is_owned"] = doc.get("user_id") == user_id
        doc["is_shared"] = not doc["is_owned"] and any(
            entry.get("user_id") == user_id
            for entry in doc.get("upload_history", [])
        )
        
        # Get last activity from questions collection
        last_question = await db.questions.find_one(
            {"content_id": doc["content_id"]},
            sort=[("created_at", -1)]
        )
        if last_question:
            last_activity = last_question.get("created_at")
            if hasattr(last_activity, "isoformat"):
                doc["last_activity"] = last_activity.isoformat()
            else:
                doc["last_activity"] = str(last_activity)
        else:
            doc["last_activity"] = doc.get("upload_date")
        
        # Get uploader name
        doc["uploader_name"] = doc.get("metadata", {}).get("uploader_name", "Unknown")
        
        # Add chunks_count for frontend display
        doc["chunks_count"] = doc.get("total_chunks", 0)
        
        # Extract title and subject from metadata for frontend
        metadata = doc.get("metadata", {})
        doc["title"] = metadata.get("title", doc.get("filename", "Untitled"))
        doc["subject"] = metadata.get("subject", "General")
        doc["grade_level"] = metadata.get("grade_level", "N/A")
        
        result_docs.append(doc)
    
    logger.info(f"Returning {len(result_docs)} of {total} documents")
    
    return {
        "documents": result_docs,
        "total": total,
        "page": page,
        "pages": (total + limit - 1) // limit if limit > 0 else 1
    }


async def generate_and_store_questions(
    content_id: str,
    title: str,
    subject: str,
    content_preview: str,
    tags: list
):
    """
    Generate suggested questions and store them in MongoDB.
    Runs in background after document upload.
    """
    try:
        from question_generator import generate_questions_for_document
        
        logger.info(f"Generating questions for document {content_id}")
        
        questions = await generate_questions_for_document(
            content_id=content_id,
            title=title,
            subject=subject,
            content_preview=content_preview,
            tags=tags
        )
        
        # Store in MongoDB
        db = mongodb_client.get_database()
        if questions:
            await db.suggested_questions.insert_many(questions)
            logger.info(f"Stored {len(questions)} suggested questions for {content_id}")
        
    except Exception as e:
        logger.error(f"Failed to generate/store questions for {content_id}: {e}")


@app.get("/api/prompts/document/{content_id}")
async def get_document_prompts(
    content_id: str,
    db=Depends(get_mongodb)
):
    """
    Get suggested questions for a specific document.
    
    Args:
        content_id: Document ID
    
    Returns:
        List of suggested prompts/questions
    """
    # Try to get generated questions from database
    questions = await db.suggested_questions.find(
        {"content_id": content_id}
    ).to_list(length=5)
    
    if questions:
        # Format for frontend
        prompts = [
            {
                "id": q.get("id", q.get("_id")),
                "text": q.get("question"),
                "category": q.get("category"),
                "icon": get_category_icon(q.get("category"))
            }
            for q in questions
        ]
        return {"prompts": prompts}
    
    # If no questions generated yet, return fallback
    doc = await db.content.find_one({"content_id": content_id})
    
    if not doc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Document {content_id} not found"
        )
    
    subject = doc.get("metadata", {}).get("subject", "General")
    tags = doc.get("tags", [])
    
    from question_generator import get_fallback_questions
    fallback = get_fallback_questions(content_id, subject, tags)
    
    prompts = [
        {
            "id": q["id"],
            "text": q["question"],
            "category": q["category"],
            "icon": get_category_icon(q["category"])
        }
        for q in fallback
    ]
    
    return {"prompts": prompts}


@app.get("/api/prompts/global")
async def get_global_prompts(
    user_id: str,
    db=Depends(get_mongodb)
):
    """
    Get suggested questions for global chat across user's documents.
    
    Args:
        user_id: User ID
    
    Returns:
        List of cross-document prompts
    """
    from shared.database.redis_client import redis_client
    import json
    
    # Check cache first
    cache_key = f"global_prompts:{user_id}"
    try:
        cached = await redis_client.get(cache_key)
        if cached:
            return json.loads(cached)
    except Exception:
        pass
    
    # Get user's role
    user = await db.users.find_one({"user_id": user_id})
    role = user.get("role", "student") if user else "student"
    
    # Get teacher IDs for student access
    teachers = await db.users.find({"role": "teacher"}, {"user_id": 1}).to_list(length=None)
    teacher_ids = [t["user_id"] for t in teachers]
    
    # Get user's documents (including teacher documents for students)
    cursor = db.content.find(
        {
            "$or": [
                {"user_id": user_id},  # Student owns
                {"upload_history.user_id": user_id},  # Student uploaded
                {"user_id": {"$in": teacher_ids}},  # Teacher uploaded
                {"original_uploader_id": {"$in": teacher_ids}}  # Originally by teacher
            ],
            "status": "completed"
        }
    )
    documents = await cursor.to_list(length=None)
    
    if not documents:
        # Return helpful message for empty state
        return {
            "prompts": [
                {
                    "id": "g1", 
                    "text": "Upload your first document or ask your teacher to share materials", 
                    "category": "information",
                    "icon": "upload"
                }
            ]
        }
    
    # Generate global questions
    from question_generator import generate_global_questions
    
    questions = await generate_global_questions(user_id, documents)
    
    prompts = [
        {
            "id": q["id"],
            "text": q["question"],
            "category": q["category"],
            "icon": get_category_icon(q["category"])
        }
        for q in questions
    ]
    
    result = {"prompts": prompts}
    
    # Cache for 24 hours
    try:
        await redis_client.setex(cache_key, 86400, json.dumps(result))
    except Exception:
        pass
    
    return result


def get_category_icon(category: str) -> str:
    """Map category to icon name."""
    icons = {
        "definition": "book-open",
        "explanation": "lightbulb",
        "comparison": "scale",
        "procedure": "list-ordered",
        "application": "zap",
        "evaluation": "target"
    }
    return icons.get(category, "lightbulb")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)

