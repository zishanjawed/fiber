# WebSocket Flow - Detailed Trace

## Scenario: User Uploads 3 Files

### Timeline of Events

```
User Action: Clicks "Upload All (3 files)"
    ↓
Frontend: POST /api/documents/bulk-upload
    ↓
Backend: Receives request (main.py:786)
```

---

### Event 1: Batch Started
**Location**: `services/document-processor/main.py:912-924`

```python
# Line 912-922: After batch metadata created
try:
    from websocket_handler import manager
    await manager.publish_status(f"batch:{batch_id}", {
        "type": "batch_started",
        "batch_id": batch_id,
        "total_files": len(accepted_files),  # 3
        "completed_files": 0,
        "failed_files": 0,
        "status": "processing"
    })
except Exception as e:
    logger.warning(f"Failed to publish WebSocket status: {e}")
```

**Message Format**:
```json
{
  "type": "batch_started",
  "batch_id": "uuid-abc-123",
  "total_files": 3,
  "completed_files": 0,
  "failed_files": 0,
  "status": "processing"
}
```

**How it's sent**:
1. `manager.publish_status()` is called (main.py:915)
2. Goes to `websocket_handler.py:68-79` (publish_status method)
3. Publishes to Redis channel: `document:status:batch:uuid-abc-123`
4. Redis pubsub listener picks it up (websocket_handler.py:81-112)
5. Broadcasts to all connected WebSocket clients for this batch_id

---

### Event 2: File 1 Completed
**Location**: `services/document-processor/main.py:705-725`

After `process_single_file_in_batch()` successfully processes file 1:

```python
# Line 705-725: After chunks published to RabbitMQ
try:
    from websocket_handler import manager
    await manager.publish_status(content_id, {
        "status": "processing",
        "progress": 10,
        "processed_chunks": 0,
        "total_chunks": len(chunks),
        "message": f"Processing {len(chunks)} chunks..."
    })

    # Publish batch-level update
    await manager.publish_status(f"batch:{batch_id}", {
        "type": "file_completed",
        "batch_id": batch_id,
        "filename": file.filename,  # "document1.pdf"
        "content_id": content_id,
        "status": "processing"
    })
except Exception as e:
    logger.warning(f"Failed to publish WebSocket status: {e}")
```

**Message Format**:
```json
{
  "type": "file_completed",
  "batch_id": "uuid-abc-123",
  "filename": "document1.pdf",
  "content_id": "uuid-doc-1",
  "status": "processing"
}
```

---

### Event 3: File 2 Failed
**Location**: `services/document-processor/main.py:765-775`

If file 2 fails during processing:

```python
# Line 765-775: In exception handler
try:
    from websocket_handler import manager
    await manager.publish_status(f"batch:{batch_id}", {
        "type": "file_failed",
        "batch_id": batch_id,
        "filename": file.filename,  # "document2.pdf"
        "error": str(e)
    })
except:
    pass
```

**Message Format**:
```json
{
  "type": "file_failed",
  "batch_id": "uuid-abc-123",
  "filename": "document2.pdf",
  "error": "Failed to parse document: Invalid PDF structure"
}
```

---

### Event 4: File 3 Completed
Same as Event 2, but for file 3.

---

### Event 5: Batch Completed
**Location**: `services/document-processor/main.py:1054-1066`

After all files finish in `process_batch_files()`:

```python
# Line 1054-1066: After batch metadata updated
try:
    from websocket_handler import manager
    await manager.publish_status(f"batch:{batch_id}", {
        "type": "batch_completed",
        "batch_id": batch_id,
        "total_files": len(tasks),  # 3
        "completed_files": completed_count,  # 2
        "failed_files": failed_count,  # 1
        "status": batch_status  # "partial"
    })
except Exception as e:
    logger.warning(f"Failed to publish final WebSocket status: {e}")
```

**Message Format**:
```json
{
  "type": "batch_completed",
  "batch_id": "uuid-abc-123",
  "total_files": 3,
  "completed_files": 2,
  "failed_files": 1,
  "status": "partial"
}
```

---

## Complete Event Sequence

For 3 files (2 succeed, 1 fails):

```
t=0s    → batch_started (total: 3)
t=1s    → file_completed (document1.pdf)
t=2s    → file_failed (document2.pdf, error: "Parse error")
t=3s    → file_completed (document3.pdf)
t=3.1s  → batch_completed (completed: 2, failed: 1, status: "partial")
```

---

## WebSocket Connection Details

### Frontend Connection
**Location**: `frontend/src/features/documents/components/BatchUploadProgress.tsx:23-101`

```typescript
// Line 23: Component receives batch_id
export function BatchUploadProgress({ batchId, totalFiles, onComplete }) {

  useEffect(() => {
    // Line 28: Connect to WebSocket
    const wsBaseUrl = import.meta.env.VITE_WS_BASE_URL || 'ws://localhost:8000'
    const ws = new WebSocket(`${wsBaseUrl}/ws/batch/${batchId}/status`)

    ws.onopen = () => {
      console.log(`Connected to batch ${batchId} WebSocket`)
    }

    // Line 35: Handle incoming messages
    ws.onmessage = (event) => {
      const update: BatchWebSocketUpdate = JSON.parse(event.data)

      switch (update.type) {
        case 'batch_started':
          // Update UI
          break

        case 'file_completed':
          // Update file status map
          setFiles((prev) => {
            const newMap = new Map(prev)
            newMap.set(update.filename!, {
              filename: update.filename!,
              content_id: update.content_id,
              status: 'completed',
              upload_index: newMap.get(update.filename!)?.upload_index || 0,
            })
            return newMap
          })
          setCompletedFiles((prev) => prev + 1)
          break

        case 'file_failed':
          // Update file status as failed
          break

        case 'batch_completed':
          setBatchStatus(update.status as any || 'completed')
          ws.close()  // Close WebSocket when done

          if (onComplete) {
            onComplete(update.completed_files || 0, update.failed_files || 0)
          }
          break
      }
    }

    // Line 95: Cleanup on unmount
    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close()
      }
    }
  }, [batchId, onComplete])
}
```

### Backend WebSocket Handler
**Location**: `services/document-processor/websocket_handler.py:15-172`

The ConnectionManager handles all WebSocket connections:

```python
class ConnectionManager:
    def __init__(self):
        # Line 20: Map of content_id/batch_id -> WebSocket connections
        self.active_connections: Dict[str, Set[WebSocket]] = {}
        self._pubsub = None
        self._listener_task = None

    async def connect(self, websocket: WebSocket, content_id: str):
        """Accept new WebSocket connection."""
        await websocket.accept()

        if content_id not in self.active_connections:
            self.active_connections[content_id] = set()

        self.active_connections[content_id].add(websocket)

        # Start Redis listener if not already running
        if not self._listener_task:
            self._listener_task = asyncio.create_task(self._listen_redis())

    async def publish_status(self, content_id: str, status: dict):
        """Publish status to Redis for cross-service communication."""
        try:
            channel = f"document:status:{content_id}"
            message = json.dumps(status)
            await redis_client.client.publish(channel, message)
        except Exception as e:
            logger.error(f"Failed to publish to Redis: {e}")

    async def _listen_redis(self):
        """Listen for status updates from Redis pubsub."""
        pubsub = redis_client.client.pubsub()
        await pubsub.psubscribe("document:status:*")

        async for message in pubsub.listen():
            if message["type"] == "pmessage":
                # Extract content_id from channel name
                channel = message["channel"].decode()
                content_id = channel.split(":")[-1]

                # Parse and forward to WebSocket clients
                data = message["data"].decode()
                status = json.loads(data)
                await self.send_status(content_id, status)
```

---

## What Happens if WebSocket Disconnects?

### Short Answer: **Upload continues!**

### Detailed Explanation:

**Location**: `services/document-processor/main.py:973-975`

```python
# Line 973-975: Background task started
asyncio.create_task(
    process_batch_files(batch_id, tasks, db)
)

# Line 977-984: Response returned IMMEDIATELY
return BatchUploadResponse(
    batch_id=batch_id,
    total_files=len(files),
    accepted_files=len(accepted_files),
    rejected_files=rejected_files,
    message=f"Batch upload started. Processing {len(accepted_files)} files."
)
```

**Key Points**:

1. **Background Task**: Batch processing runs in `asyncio.create_task()` - completely independent of HTTP request or WebSocket

2. **MongoDB Tracking**: Status stored in `batch_jobs` collection regardless of WebSocket

3. **WebSocket is Optional**: WebSocket failures are caught and logged but don't stop processing:
   ```python
   # Line 923: WebSocket publish wrapped in try/except
   try:
       await manager.publish_status(...)
   except Exception as e:
       logger.warning(f"Failed to publish WebSocket status: {e}")
       # Processing continues!
   ```

4. **Recovery**: User can:
   - Close browser → processing continues
   - Disconnect WiFi → processing continues
   - Refresh page → reconnect to same batch_id
   - Poll REST endpoint: `GET /api/documents/batch/{batch_id}`

### Frontend Fallback
**Location**: `frontend/src/features/documents/components/UploadDialog.tsx:199-246`

The original single-file upload has polling fallback:

```typescript
// Line 199: Polling fallback if WebSocket fails
const startPolling = (contentId: string) => {
  let attempts = 0
  const maxAttempts = 150 // 5 minutes

  pollInterval = setInterval(async () => {
    attempts++

    try {
      const doc = await documentsService.getDocument(contentId)

      if (doc.status === 'completed') {
        // Update UI
        if (pollInterval) clearInterval(pollInterval)
      }
    } catch (error) {
      // Continue polling despite errors
    }
  }, 2000) // Poll every 2 seconds
}

// Line 177: Triggered on WebSocket error
ws.onerror = (error) => {
  console.error('WebSocket error:', error)
  if (!pollInterval) {
    startPolling(contentId)  // Fallback to polling
  }
}
```

**For batch uploads**, you can add similar polling:

```typescript
// Poll batch status if WebSocket fails
const pollBatchStatus = async (batchId: string) => {
  const status = await documentsService.getBatchStatus(batchId)
  // Update UI with status
  if (status.status === 'completed' || status.status === 'failed') {
    // Stop polling
  }
}
```

---

## Verification Commands

### Check WebSocket Connections
```bash
# See active WebSocket connections
netstat -an | grep 8000 | grep ESTABLISHED

# Monitor WebSocket traffic (if using wscat)
wscat -c ws://localhost:8000/ws/batch/YOUR_BATCH_ID/status
```

### Check Redis Pubsub
```bash
# Monitor Redis channels
redis-cli
> PSUBSCRIBE document:status:*

# In another terminal, trigger upload and watch messages flow
```

### Test Disconnect Scenario
```javascript
// In browser console during upload:
const ws = new WebSocket('ws://localhost:8000/ws/batch/BATCH_ID/status')
ws.onmessage = (e) => console.log('Event:', JSON.parse(e.data))

// After a few events:
ws.close()  // Disconnect

// Then check batch still processing:
fetch('/api/documents/batch/BATCH_ID')
  .then(r => r.json())
  .then(d => console.log('Status:', d))
```

---

## Summary

### Event Order for 3 Files:
1. `batch_started` - immediately after validation
2. `file_completed` - for each successful file
3. `file_failed` - for any failed files
4. `batch_completed` - when all files finish

### WebSocket Independence:
- Processing is **NOT** dependent on WebSocket
- WebSocket failures are logged but ignored
- Can reconnect anytime with same batch_id
- Fallback to REST polling always available

### Connection Lifecycle:
```
User clicks upload
    ↓
HTTP POST returns batch_id (< 1 second)
    ↓
Frontend opens WebSocket
    ↓
Backend processes files (1-30 minutes)
    ↓
Redis pubsub distributes events
    ↓
WebSocket sends to client
    ↓
Frontend updates UI
    ↓
WebSocket closes on completion
```
