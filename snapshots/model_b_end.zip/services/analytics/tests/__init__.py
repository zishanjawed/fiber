"""
Analytics service tests.
"""

