"""
API Gateway tests.
"""

