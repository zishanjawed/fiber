"""
Visual demonstration of semaphore limiting concurrent processing.

Run this to see exactly how the semaphore prevents more than 5 files
from processing simultaneously.
"""
import asyncio
from datetime import datetime


def log_with_time(message):
    """Print message with timestamp."""
    timestamp = datetime.now().strftime("%H:%M:%S.%f")[:-3]
    print(f"[{timestamp}] {message}")


async def process_file(file_id, semaphore, results):
    """
    Simulates processing a single file.
    The semaphore ensures max 5 files process concurrently.
    """
    log_with_time(f"File {file_id:2d} - WAITING for semaphore...")

    async with semaphore:  # THIS IS THE KEY LINE - BLOCKS IF 5 ALREADY RUNNING
        log_with_time(f"File {file_id:2d} - ✓ ACQUIRED semaphore, starting processing")

        # Track that we started
        results['started'].append(file_id)
        results['current_active'] += 1
        results['max_concurrent'] = max(results['max_concurrent'], results['current_active'])

        log_with_time(f"File {file_id:2d} - Processing... (active: {results['current_active']})")

        # Simulate file processing (parse, chunk, vectorize)
        await asyncio.sleep(1.0)  # 1 second processing time

        # Track that we finished
        results['current_active'] -= 1
        results['completed'].append(file_id)

        log_with_time(f"File {file_id:2d} - ✓ COMPLETED, releasing semaphore (active: {results['current_active']})")


async def demonstrate_concurrent_limit():
    """
    Demonstrates how semaphore limits concurrent processing to 5.

    Expected behavior:
    - Files 0-4 start immediately
    - File 5 waits until one completes
    - File 6 waits until another completes
    - etc.
    """
    print("\n" + "="*80)
    print("SEMAPHORE CONCURRENCY DEMONSTRATION")
    print("="*80)
    print("\nUploading 10 files with Semaphore(5) limit")
    print("Watch how files 5-9 WAIT until earlier files complete\n")

    # Create semaphore with limit of 5 (same as production code)
    semaphore = asyncio.Semaphore(5)

    # Track results
    results = {
        'started': [],
        'completed': [],
        'current_active': 0,
        'max_concurrent': 0
    }

    # Launch 10 files simultaneously
    tasks = [
        process_file(i, semaphore, results)
        for i in range(10)
    ]

    log_with_time("All 10 tasks created, starting execution...")
    print()

    # Wait for all to complete
    await asyncio.gather(*tasks)

    # Print summary
    print("\n" + "="*80)
    print("RESULTS")
    print("="*80)
    print(f"✓ Total files processed: {len(results['completed'])}")
    print(f"✓ Max concurrent processing: {results['max_concurrent']}")
    print(f"✓ Expected max concurrent: 5")
    print(f"✓ Test {'PASSED' if results['max_concurrent'] == 5 else 'FAILED'}")
    print("="*80 + "\n")

    # Verify the limit was respected
    assert results['max_concurrent'] == 5, \
        f"Expected max 5 concurrent, but got {results['max_concurrent']}"

    assert len(results['completed']) == 10, \
        f"Expected 10 files completed, but got {len(results['completed'])}"


async def demonstrate_what_happens_without_semaphore():
    """
    Shows what happens WITHOUT semaphore - all 10 files start at once.
    This is what we're PREVENTING with the semaphore.
    """
    print("\n" + "="*80)
    print("WITHOUT SEMAPHORE (for comparison)")
    print("="*80)
    print("\nAll 10 files start processing IMMEDIATELY - no limit!\n")

    results = {
        'started': [],
        'completed': [],
        'current_active': 0,
        'max_concurrent': 0
    }

    async def process_without_limit(file_id):
        log_with_time(f"File {file_id:2d} - Starting immediately")
        results['current_active'] += 1
        results['max_concurrent'] = max(results['max_concurrent'], results['current_active'])

        await asyncio.sleep(1.0)

        results['current_active'] -= 1
        log_with_time(f"File {file_id:2d} - Completed")

    tasks = [process_without_limit(i) for i in range(10)]
    await asyncio.gather(*tasks)

    print(f"\n✓ Max concurrent: {results['max_concurrent']} (NO LIMIT!)")
    print("This is why we NEED the semaphore!\n")


async def demonstrate_semaphore_blocking():
    """
    Shows EXACTLY when and where file #6 blocks.
    """
    print("\n" + "="*80)
    print("DETAILED BLOCKING DEMONSTRATION - 6 FILES")
    print("="*80)
    print("\nThis shows EXACTLY where file #6 waits\n")

    semaphore = asyncio.Semaphore(5)

    async def process_with_detail(file_id):
        log_with_time(f"File {file_id} - Created task")
        log_with_time(f"File {file_id} - Attempting to acquire semaphore...")

        async with semaphore:  # File #6 will BLOCK HERE
            log_with_time(f"File {file_id} - ✓✓✓ ENTERED SEMAPHORE ✓✓✓")
            await asyncio.sleep(0.5)
            log_with_time(f"File {file_id} - Exiting semaphore")

    # Start 6 files
    tasks = [process_with_detail(i) for i in range(6)]
    await asyncio.gather(*tasks)

    print("\nNotice how file 5 waits until file 0-4 complete!")


if __name__ == "__main__":
    print("\n" + "🔬 RUNNING CONCURRENCY DEMONSTRATIONS" + "\n")

    # Main demonstration
    asyncio.run(demonstrate_concurrent_limit())

    # Comparison without semaphore
    asyncio.run(demonstrate_what_happens_without_semaphore())

    # Detailed blocking view
    asyncio.run(demonstrate_semaphore_blocking())

    print("\n✅ All demonstrations complete!\n")
