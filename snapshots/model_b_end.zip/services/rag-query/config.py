"""
Configuration for RAG query service.
"""
from shared.config.settings import settings

# Re-export settings for convenience
__all__ = ['settings']

