"""
Vectorization service tests.
"""

