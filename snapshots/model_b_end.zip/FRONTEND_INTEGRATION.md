# Frontend Integration - Deep Dive

## WebSocket Subscription in BatchUploadProgress

### Component Location
`frontend/src/features/documents/components/BatchUploadProgress.tsx`

---

## 1. WebSocket Connection Establishment

### Code: Lines 23-36

```typescript
export function BatchUploadProgress({ batchId, totalFiles, onComplete }) {
  // State management
  const [files, setFiles] = useState<Map<string, BatchFileStatus>>(new Map())
  const [completedFiles, setCompletedFiles] = useState(0)
  const [failedFiles, setFailedFiles] = useState(0)
  const [batchStatus, setBatchStatus] = useState<'processing' | 'completed' | 'partial' | 'failed'>('processing')

  useEffect(() => {
    // Line 28: WEBSOCKET CONNECTION HAPPENS HERE
    const wsBaseUrl = import.meta.env.VITE_WS_BASE_URL || 'ws://localhost:8000'
    const ws = new WebSocket(`${wsBaseUrl}/ws/batch/${batchId}/status`)

    ws.onopen = () => {
      console.log(`Connected to batch ${batchId} WebSocket`)
    }

    // ... message handlers
```

**Key Points**:
1. Connection created in `useEffect` hook
2. Triggers when component mounts
3. Uses `batchId` from props
4. Reads WebSocket URL from environment variable

---

## 2. Message Handling

### Code: Lines 35-83

```typescript
ws.onmessage = (event) => {
  try {
    const update: BatchWebSocketUpdate = JSON.parse(event.data)
    console.log('Batch update:', update)

    switch (update.type) {
      case 'batch_started':
        // Initial batch info - no UI update needed
        break

      case 'file_completed':
        if (update.filename) {
          // UPDATE STATE: Add/update file in map
          setFiles((prev) => {
            const newMap = new Map(prev)
            newMap.set(update.filename!, {
              filename: update.filename!,
              content_id: update.content_id,
              status: 'completed',
              upload_index: newMap.get(update.filename!)?.upload_index || 0,
            })
            return newMap
          })
          // INCREMENT COUNTER
          setCompletedFiles((prev) => prev + 1)
        }
        break

      case 'file_failed':
        if (update.filename) {
          // MARK FILE AS FAILED
          setFiles((prev) => {
            const newMap = new Map(prev)
            newMap.set(update.filename!, {
              filename: update.filename!,
              status: 'failed',
              error_message: update.error,
              upload_index: newMap.get(update.filename!)?.upload_index || 0,
            })
            return newMap
          })
          setFailedFiles((prev) => prev + 1)
        }
        break

      case 'batch_completed':
        // FINAL UPDATE
        setBatchStatus(update.status as any || 'completed')
        setCompletedFiles(update.completed_files || 0)
        setFailedFiles(update.failed_files || 0)

        // CALL PARENT CALLBACK
        if (onComplete) {
          onComplete(update.completed_files || 0, update.failed_files || 0)
        }

        // CLOSE WEBSOCKET - THIS IS KEY
        ws.close()
        break
    }
  } catch (error) {
    console.error('Error parsing WebSocket message:', error)
  }
}
```

**State Updates Flow**:
```
WebSocket message received
    ↓
Parse JSON
    ↓
Switch on update.type
    ↓
Update React state (setFiles, setCompletedFiles, etc.)
    ↓
React re-renders component
    ↓
UI updates (progress bar, file list, counters)
```

---

## 3. How Component Knows When to Stop

### Answer: Multiple mechanisms

### Mechanism 1: batch_completed Event
**Code**: Lines 77-82

```typescript
case 'batch_completed':
  setBatchStatus(update.status as any || 'completed')

  if (onComplete) {
    onComplete(update.completed_files || 0, update.failed_files || 0)
  }

  ws.close()  // ← WEBSOCKET CLOSED HERE
  break
```

**Flow**:
1. Backend sends `batch_completed` event
2. Frontend receives it
3. Updates final state
4. Calls parent's `onComplete` callback
5. **Closes WebSocket connection**

### Mechanism 2: Component Unmount
**Code**: Lines 95-101

```typescript
// Cleanup on unmount
return () => {
  if (ws.readyState === WebSocket.OPEN) {
    ws.close()
  }
}
```

**When This Triggers**:
- User closes dialog
- User navigates away
- Component removed from DOM
- Parent component re-renders without this child

### Mechanism 3: Error Handler
**Code**: Lines 84-86

```typescript
ws.onerror = (error) => {
  console.error('WebSocket error:', error)
}
```

**Note**: Current implementation doesn't close on error, could be improved:

```typescript
ws.onerror = (error) => {
  console.error('WebSocket error:', error)
  ws.close()  // Close on error
  // Could add fallback to REST polling here
}
```

---

## 4. What Happens if batch_id is Invalid?

### Current Behavior:

**Code Path**:
```
Frontend: new WebSocket(`/ws/batch/INVALID_ID/status`)
    ↓
API Gateway: Proxies to document-processor
    ↓
Document Processor: Accepts connection
    ↓
websocket_handler.py: Adds to active_connections
    ↓
Redis listener: Subscribes to "document:status:batch:INVALID_ID"
    ↓
No messages ever published to this channel
    ↓
WebSocket stays open, no data received
```

**Problem**: WebSocket stays connected but receives no data

### Better Solution: Add validation

**Backend**: `services/document-processor/main.py:153-171`

```python
@app.websocket("/ws/batch/{batch_id}/status")
async def websocket_batch_status_endpoint(websocket: WebSocket, batch_id: str):
    """WebSocket endpoint for batch status updates."""

    # ADD VALIDATION HERE
    db = mongodb_client.get_database()
    batch = await db.batch_jobs.find_one({"batch_id": batch_id})

    if not batch:
        await websocket.close(code=4404, reason="Batch not found")
        return

    # Proceed with normal connection
    from websocket_handler import websocket_endpoint
    await websocket_endpoint(websocket, f"batch:{batch_id}")
```

**Frontend**: Handle close code

```typescript
ws.onclose = (event) => {
  if (event.code === 4404) {
    console.error('Batch not found')
    // Show error to user
  }
}
```

---

## 5. What if WebSocket Never Connects?

### Scenario: Network issues, wrong URL, server down

### Current Behavior:

**Code**: Lines 84-86 (error handler)

```typescript
ws.onerror = (error) => {
  console.error('WebSocket error:', error)
  // PROBLEM: No fallback mechanism!
}
```

**Issue**: Component continues to show "Processing..." forever with no updates

### Better Solution: Add Fallback Polling

Let me add this to the component:

```typescript
useEffect(() => {
  const wsBaseUrl = import.meta.env.VITE_WS_BASE_URL || 'ws://localhost:8000'
  const ws = new WebSocket(`${wsBaseUrl}/ws/batch/${batchId}/status`)
  let wsConnected = false
  let pollInterval: NodeJS.Timeout | null = null

  ws.onopen = () => {
    console.log(`Connected to batch ${batchId} WebSocket`)
    wsConnected = true
  }

  ws.onmessage = (event) => {
    // ... existing message handling
  }

  ws.onerror = (error) => {
    console.error('WebSocket error:', error)

    // START POLLING IF WEBSOCKET FAILS
    if (!pollInterval) {
      console.log('WebSocket failed, falling back to polling')
      startPolling()
    }
  }

  ws.onclose = (event) => {
    // If closed unexpectedly and batch not complete, start polling
    if (wsConnected && batchStatus === 'processing') {
      console.log('WebSocket closed unexpectedly, falling back to polling')
      if (!pollInterval) {
        startPolling()
      }
    }
  }

  // POLLING FALLBACK FUNCTION
  const startPolling = () => {
    pollInterval = setInterval(async () => {
      try {
        // Call REST API instead of WebSocket
        const status = await documentsService.getBatchStatus(batchId)

        // Update state based on polling response
        setCompletedFiles(status.completed_files)
        setFailedFiles(status.failed_files)
        setBatchStatus(status.status)

        // Update files map
        const newFiles = new Map<string, BatchFileStatus>()
        status.files.forEach(file => {
          newFiles.set(file.filename, file)
        })
        setFiles(newFiles)

        // Stop polling if complete
        if (status.status !== 'processing') {
          if (pollInterval) clearInterval(pollInterval)

          if (onComplete) {
            onComplete(status.completed_files, status.failed_files)
          }
        }
      } catch (error) {
        console.error('Polling error:', error)
        // Continue polling despite errors
      }
    }, 2000) // Poll every 2 seconds
  }

  // Cleanup
  return () => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.close()
    }
    if (pollInterval) {
      clearInterval(pollInterval)
    }
  }
}, [batchId, onComplete, batchStatus])
```

---

## 6. Parent Component Integration

### How UploadDialog Uses BatchUploadProgress

**Location**: `frontend/src/features/documents/components/UploadDialog.tsx:369-375`

```typescript
{/* Batch Upload Progress */}
{isBatchUpload && batchId && isUploading && (
  <BatchUploadProgress
    batchId={batchId}              // ← Passes batch_id from API response
    totalFiles={totalBatchFiles}   // ← Passes expected file count
    onComplete={handleBatchComplete}  // ← Callback when done
  />
)}
```

### Callback Handler

**Location**: Lines 176-186

```typescript
const handleBatchComplete = (completedCount: number, failedCount: number) => {
  // SAVE RESULTS
  setBatchCompleted(completedCount)
  setBatchFailed(failedCount)
  setUploadSuccess(true)
  setIsUploading(false)

  // SHOW RESULTS MODAL
  setTimeout(() => {
    setShowResultsModal(true)
  }, 500)
}
```

**Flow**:
```
BatchUploadProgress receives 'batch_completed'
    ↓
Calls onComplete(18, 2)  // 18 succeeded, 2 failed
    ↓
UploadDialog.handleBatchComplete() executes
    ↓
Updates parent state
    ↓
Shows BatchResultsModal
```

---

## 7. Component Lifecycle

### Visual Timeline:

```
t=0s    User clicks "Upload All"
            ↓
t=0.1s  API call: POST /api/documents/bulk-upload
            ↓
t=0.5s  Response received: { batch_id: "uuid-123" }
            ↓
t=0.6s  setBatchId("uuid-123") → triggers re-render
            ↓
t=0.7s  <BatchUploadProgress batchId="uuid-123" /> mounts
            ↓
t=0.8s  useEffect runs → WebSocket connection opens
            ↓
t=1.0s  WebSocket onopen fires
            ↓
t=1.5s  First event received: { type: "batch_started" }
            ↓
t=5.0s  Event: { type: "file_completed", filename: "doc1.pdf" }
            ↓
        State updates → React re-renders → Progress bar updates
            ↓
t=10s   Event: { type: "file_completed", filename: "doc2.pdf" }
            ↓
t=15s   Event: { type: "file_failed", filename: "doc3.pdf" }
            ↓
t=20s   Event: { type: "batch_completed", status: "partial" }
            ↓
        handleBatchComplete(2, 1) called
            ↓
        WebSocket.close() called
            ↓
t=20.5s BatchResultsModal opens
```

---

## 8. Error Scenarios & Handling

### Scenario A: Invalid batch_id
**Current**: WebSocket opens but no data
**Better**: Validate and close with error code
**Fix**: Added validation code above

### Scenario B: WebSocket fails to connect
**Current**: Component shows "Processing..." forever
**Better**: Fallback to REST polling
**Fix**: Added polling fallback above

### Scenario C: Connection drops mid-upload
**Current**: No more updates shown
**Better**: Detect disconnect and poll
**Fix**: Added onclose handler above

### Scenario D: Malformed message received
**Current**: Caught by try/catch, logged to console
**Better**: Same, works well
**Status**: ✅ Already handled

---

## 9. State Management

### Component State:

```typescript
// File tracking - Map for O(1) lookup
const [files, setFiles] = useState<Map<string, BatchFileStatus>>(new Map())

// Counters - for UI display
const [completedFiles, setCompletedFiles] = useState(0)
const [failedFiles, setFailedFiles] = useState(0)

// Overall status
const [batchStatus, setBatchStatus] = useState<'processing' | ...>('processing')
```

### Why Map Instead of Array?

**Performance**:
```typescript
// With Map: O(1) lookup/update
setFiles(prev => {
  const newMap = new Map(prev)
  newMap.set(filename, updatedFile)  // O(1)
  return newMap
})

// With Array: O(n) lookup
setFiles(prev => prev.map(f =>
  f.filename === filename ? updatedFile : f  // O(n)
))
```

**For 50 files**: Map is significantly faster

---

## 10. Rendering Performance

### Code: Lines 155-183 (Rendering file list)

```typescript
{Array.from(files.values())
  .sort((a, b) => a.upload_index - b.upload_index)
  .map((file) => (
    <div key={file.filename} className="flex items-center...">
      {/* File icon, name, status */}
    </div>
  ))}
```

**Optimization**: Using `file.filename` as key for React reconciliation

**Performance Consideration**:
- Sorting on every render could be expensive for 50 files
- Better: Sort once when files complete, store sorted array

**Improved version**:
```typescript
const sortedFiles = useMemo(
  () => Array.from(files.values()).sort((a, b) => a.upload_index - b.upload_index),
  [files]
)

// Then render sortedFiles
```

---

## Summary

### WebSocket Lifecycle:
1. ✅ Opens when component mounts
2. ✅ Listens for events
3. ✅ Updates state on each event
4. ✅ Closes on batch_completed
5. ✅ Cleans up on unmount

### Error Handling:
1. ⚠️ Invalid batch_id - needs validation
2. ⚠️ Connection failure - needs polling fallback
3. ✅ Malformed messages - handled
4. ✅ Cleanup on unmount - handled

### Improvements Made:
1. Added batch_id validation
2. Added polling fallback
3. Added disconnect detection
4. Added performance optimization (useMemo)

### Code Locations:
- WebSocket connection: `BatchUploadProgress.tsx:28`
- Message handling: `BatchUploadProgress.tsx:35-83`
- Cleanup: `BatchUploadProgress.tsx:95-101`
- Parent integration: `UploadDialog.tsx:369-375`
- Callback: `UploadDialog.tsx:176-186`
