/**
 * BatchResultsModal Component
 * Summary modal shown after batch upload completes
 */

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../../../components/ui/dialog'
import { Button } from '../../../components/ui/Button'
import { Alert, AlertDescription } from '../../../components/ui/alert'
import { CheckCircle, XCircle, AlertTriangle } from 'lucide-react'

interface BatchResultsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  totalFiles: number
  completedFiles: number
  failedFiles: number
  rejectedFiles?: Array<{ filename: string; reason: string }>
  onRetry?: () => void
}

export function BatchResultsModal({
  open,
  onOpenChange,
  totalFiles,
  completedFiles,
  failedFiles,
  rejectedFiles = [],
  onRetry,
}: BatchResultsModalProps) {
  const allSucceeded = failedFiles === 0 && rejectedFiles.length === 0
  const partialSuccess = completedFiles > 0 && (failedFiles > 0 || rejectedFiles.length > 0)

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {allSucceeded && <CheckCircle className="h-5 w-5 text-green-600" />}
            {partialSuccess && <AlertTriangle className="h-5 w-5 text-yellow-600" />}
            {failedFiles === totalFiles && <XCircle className="h-5 w-5 text-red-600" />}
            Batch Upload Results
          </DialogTitle>
          <DialogDescription>
            Summary of your bulk document upload
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Success Summary */}
          {allSucceeded && (
            <Alert className="border-green-200 bg-green-50">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-800">
                <div className="font-medium">All files uploaded successfully!</div>
                <div className="text-sm mt-1">
                  {completedFiles} document{completedFiles !== 1 ? 's' : ''} {completedFiles !== 1 ? 'are' : 'is'} now processing and will appear in your library shortly.
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Partial Success Summary */}
          {partialSuccess && (
            <Alert className="border-yellow-200 bg-yellow-50">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800">
                <div className="font-medium">Partial upload success</div>
                <div className="text-sm mt-1">
                  {completedFiles} file{completedFiles !== 1 ? 's' : ''} uploaded successfully, but {failedFiles + rejectedFiles.length} failed.
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Complete Failure Summary */}
          {failedFiles === totalFiles && (
            <Alert className="border-red-200 bg-red-50">
              <XCircle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                <div className="font-medium">Upload failed</div>
                <div className="text-sm mt-1">
                  All files failed to upload. Please check the errors below and try again.
                </div>
              </AlertDescription>
            </Alert>
          )}

          {/* Stats Grid */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-4 rounded-lg border bg-card">
              <div className="text-2xl font-bold">{totalFiles}</div>
              <div className="text-xs text-muted-foreground mt-1">Total Files</div>
            </div>
            <div className="text-center p-4 rounded-lg border bg-green-50 dark:bg-green-950">
              <div className="text-2xl font-bold text-green-600">{completedFiles}</div>
              <div className="text-xs text-muted-foreground mt-1">Uploaded</div>
            </div>
            <div className="text-center p-4 rounded-lg border bg-red-50 dark:bg-red-950">
              <div className="text-2xl font-bold text-red-600">{failedFiles + rejectedFiles.length}</div>
              <div className="text-xs text-muted-foreground mt-1">Failed</div>
            </div>
          </div>

          {/* Rejected Files List */}
          {rejectedFiles.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium flex items-center gap-2">
                <XCircle className="h-4 w-4 text-red-600" />
                Rejected Files ({rejectedFiles.length})
              </h4>
              <div className="max-h-[200px] overflow-y-auto border rounded-lg p-3 space-y-2">
                {rejectedFiles.map((file, idx) => (
                  <div key={idx} className="flex items-start gap-2 p-2 rounded bg-red-50 dark:bg-red-950">
                    <XCircle className="h-4 w-4 text-red-600 mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium truncate" title={file.filename}>
                        {file.filename}
                      </div>
                      <div className="text-xs text-red-600 mt-1">{file.reason}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Processing Note */}
          {completedFiles > 0 && (
            <Alert>
              <AlertDescription>
                <div className="text-sm">
                  Successfully uploaded files are now being processed. You can view them in your document library.
                  Processing typically takes 1-2 minutes per document.
                </div>
              </AlertDescription>
            </Alert>
          )}
        </div>

        <DialogFooter className="flex gap-2">
          {onRetry && (failedFiles > 0 || rejectedFiles.length > 0) && (
            <Button variant="outline" onClick={onRetry}>
              Retry Failed
            </Button>
          )}
          <Button onClick={() => onOpenChange(false)}>
            {completedFiles > 0 ? 'View Documents' : 'Close'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
