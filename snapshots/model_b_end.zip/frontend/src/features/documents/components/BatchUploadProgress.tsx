/**
 * BatchUploadProgress Component
 * Real-time progress tracking for bulk document uploads
 */

import { useEffect, useState } from 'react'
import { Progress } from '../../../components/ui/progress'
import { Alert, AlertDescription } from '../../../components/ui/alert'
import { CheckCircle, XCircle, Loader2, FileText, AlertCircle } from 'lucide-react'
import type { BatchFileStatus, BatchWebSocketUpdate } from '../../../api/types'

interface BatchUploadProgressProps {
  batchId: string
  totalFiles: number
  onComplete?: (completedCount: number, failedCount: number) => void
}

export function BatchUploadProgress({ batchId, totalFiles, onComplete }: BatchUploadProgressProps) {
  const [files, setFiles] = useState<Map<string, BatchFileStatus>>(new Map())
  const [completedFiles, setCompletedFiles] = useState(0)
  const [failedFiles, setFailedFiles] = useState(0)
  const [batchStatus, setBatchStatus] = useState<'processing' | 'completed' | 'partial' | 'failed'>('processing')

  useEffect(() => {
    const wsBaseUrl = import.meta.env.VITE_WS_BASE_URL || 'ws://localhost:8000'
    const ws = new WebSocket(`${wsBaseUrl}/ws/batch/${batchId}/status`)
    let wsConnected = false
    let pollInterval: NodeJS.Timeout | null = null

    ws.onopen = () => {
      console.log(`Connected to batch ${batchId} WebSocket`)
      wsConnected = true
    }

    ws.onmessage = (event) => {
      try {
        const update: BatchWebSocketUpdate = JSON.parse(event.data)
        console.log('Batch update:', update)

        switch (update.type) {
          case 'batch_started':
            // Initial batch info
            break

          case 'file_completed':
            if (update.filename) {
              setFiles((prev) => {
                const newMap = new Map(prev)
                newMap.set(update.filename!, {
                  filename: update.filename!,
                  content_id: update.content_id,
                  status: 'completed',
                  upload_index: newMap.get(update.filename!)?.upload_index || 0,
                })
                return newMap
              })
              setCompletedFiles((prev) => prev + 1)
            }
            break

          case 'file_failed':
            if (update.filename) {
              setFiles((prev) => {
                const newMap = new Map(prev)
                newMap.set(update.filename!, {
                  filename: update.filename!,
                  status: 'failed',
                  error_message: update.error,
                  upload_index: newMap.get(update.filename!)?.upload_index || 0,
                })
                return newMap
              })
              setFailedFiles((prev) => prev + 1)
            }
            break

          case 'batch_completed':
            setBatchStatus(update.status as any || 'completed')
            setCompletedFiles(update.completed_files || 0)
            setFailedFiles(update.failed_files || 0)

            if (onComplete) {
              onComplete(update.completed_files || 0, update.failed_files || 0)
            }

            ws.close()
            break
        }
      } catch (error) {
        console.error('Error parsing WebSocket message:', error)
      }
    }

    ws.onerror = (error) => {
      console.error('WebSocket error:', error)
      // FALLBACK: Start polling if WebSocket fails
      if (!pollInterval) {
        console.log('WebSocket failed, falling back to polling')
        startPolling()
      }
    }

    ws.onclose = (event) => {
      console.log('Batch WebSocket closed', event.code, event.reason)

      // Handle invalid batch_id (code 4404)
      if (event.code === 4404) {
        console.error('Batch not found')
        setBatchStatus('failed')
        return
      }

      // If closed unexpectedly and not complete, start polling
      if (wsConnected && batchStatus === 'processing') {
        console.log('WebSocket closed unexpectedly, falling back to polling')
        if (!pollInterval) {
          startPolling()
        }
      }
    }

    // POLLING FALLBACK FUNCTION
    const startPolling = () => {
      pollInterval = setInterval(async () => {
        try {
          // Import documentsService dynamically
          const { documentsService } = await import('../../../api/documents.service')
          const status = await documentsService.getBatchStatus(batchId)

          // Update state from polling
          setCompletedFiles(status.completed_files)
          setFailedFiles(status.failed_files)
          setBatchStatus(status.status)

          // Update files map
          const newFiles = new Map<string, BatchFileStatus>()
          status.files.forEach(file => {
            newFiles.set(file.filename, file)
          })
          setFiles(newFiles)

          // Stop polling if complete
          if (status.status !== 'processing') {
            if (pollInterval) clearInterval(pollInterval)

            if (onComplete) {
              onComplete(status.completed_files, status.failed_files)
            }
          }
        } catch (error) {
          console.error('Polling error:', error)
          // Continue polling despite errors
        }
      }, 2000) // Poll every 2 seconds
    }

    return () => {
      if (ws.readyState === WebSocket.OPEN) {
        ws.close()
      }
      if (pollInterval) {
        clearInterval(pollInterval)
      }
    }
  }, [batchId, onComplete, batchStatus])

  const progressPercent = totalFiles > 0 ? ((completedFiles + failedFiles) / totalFiles) * 100 : 0
  const isCompleted = batchStatus !== 'processing'

  return (
    <div className="space-y-4">
      {/* Overall Progress */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="font-medium">
            {isCompleted ? 'Upload Complete' : 'Uploading Files...'}
          </span>
          <span className="text-muted-foreground">
            {completedFiles + failedFiles} / {totalFiles}
          </span>
        </div>
        <Progress value={progressPercent} className="h-2" />
      </div>

      {/* Status Summary */}
      <div className="grid grid-cols-3 gap-2 text-sm">
        <div className="flex items-center gap-2 p-2 rounded-lg bg-blue-50 dark:bg-blue-950">
          <Loader2 className={`h-4 w-4 text-blue-600 ${isCompleted ? '' : 'animate-spin'}`} />
          <div>
            <div className="font-medium">{totalFiles - completedFiles - failedFiles}</div>
            <div className="text-xs text-muted-foreground">Pending</div>
          </div>
        </div>
        <div className="flex items-center gap-2 p-2 rounded-lg bg-green-50 dark:bg-green-950">
          <CheckCircle className="h-4 w-4 text-green-600" />
          <div>
            <div className="font-medium">{completedFiles}</div>
            <div className="text-xs text-muted-foreground">Success</div>
          </div>
        </div>
        <div className="flex items-center gap-2 p-2 rounded-lg bg-red-50 dark:bg-red-950">
          <XCircle className="h-4 w-4 text-red-600" />
          <div>
            <div className="font-medium">{failedFiles}</div>
            <div className="text-xs text-muted-foreground">Failed</div>
          </div>
        </div>
      </div>

      {/* Per-File Status List */}
      {files.size > 0 && (
        <div className="max-h-[300px] overflow-y-auto space-y-1 border rounded-lg p-3">
          {Array.from(files.values())
            .sort((a, b) => a.upload_index - b.upload_index)
            .map((file) => (
              <div
                key={file.filename}
                className="flex items-center justify-between p-2 rounded hover:bg-muted/50 transition-colors"
              >
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <FileText className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
                  <span className="text-sm truncate" title={file.filename}>
                    {file.filename}
                  </span>
                </div>
                <div className="flex items-center gap-2 ml-2">
                  {file.status === 'completed' && (
                    <CheckCircle className="h-4 w-4 text-green-600 flex-shrink-0" />
                  )}
                  {file.status === 'failed' && (
                    <div className="flex items-center gap-1">
                      <XCircle className="h-4 w-4 text-red-600 flex-shrink-0" />
                      {file.error_message && (
                        <span className="text-xs text-red-600 max-w-[200px] truncate" title={file.error_message}>
                          {file.error_message}
                        </span>
                      )}
                    </div>
                  )}
                  {file.status === 'processing' && (
                    <Loader2 className="h-4 w-4 text-blue-600 animate-spin flex-shrink-0" />
                  )}
                  {file.status === 'pending' && (
                    <div className="h-4 w-4 rounded-full border-2 border-gray-300 flex-shrink-0" />
                  )}
                </div>
              </div>
            ))}
        </div>
      )}

      {/* Final Status Message */}
      {isCompleted && (
        <Alert className={failedFiles === 0 ? 'border-green-200 bg-green-50' : 'border-yellow-200 bg-yellow-50'}>
          {failedFiles === 0 ? (
            <CheckCircle className="h-4 w-4 text-green-600" />
          ) : (
            <AlertCircle className="h-4 w-4 text-yellow-600" />
          )}
          <AlertDescription className={failedFiles === 0 ? 'text-green-800' : 'text-yellow-800'}>
            {failedFiles === 0 ? (
              <>All {completedFiles} files uploaded successfully!</>
            ) : (
              <>
                {completedFiles} files uploaded successfully, {failedFiles} failed.
                {failedFiles > 0 && ' You can retry the failed uploads.'}
              </>
            )}
          </AlertDescription>
        </Alert>
      )}
    </div>
  )
}
