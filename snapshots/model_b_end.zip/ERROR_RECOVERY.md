# Error Recovery & Cleanup Analysis

## Question: What happens to MongoDB if file processing fails?

Let's trace through the code to see if orphaned records are created.

---

## Scenario: File Processing Fails

### Step 1: File Enters Processing
**Location**: `services/document-processor/main.py:576-593`

```python
async def process_single_file_in_batch(...):
    file_size_mb = len(file_content) / (1024 * 1024)
    file_extension = file.filename.split('.')[-1].lower()
    content_id = str(uuid4())  # Line 592: Generate content_id BEFORE any DB writes

    try:
        # Save file temporarily
        file_path = save_uploaded_file(file_content, file.filename)

        # Parse document
        parsed_doc = docling_parser.parse_document(file_path, file_extension)
        # ... more processing
```

**Key Point**: `content_id` generated immediately, but **NO database write yet**

---

### Step 2: MongoDB Write Happens Here
**Location**: `services/document-processor/main.py:662-690`

```python
# Line 662-690: Store metadata in MongoDB
content_metadata = ContentMetadata(
    content_id=content_id,
    filename=file.filename,
    file_type=file_extension,
    user_id=user_id,
    content_hash=content_hash,
    # ... other fields
    status="processing",  # ← IMPORTANT: Status is "processing"
    total_chunks=len(chunks),
    # ...
)

await db.content.insert_one(content_metadata.model_dump())  # Line 690: DB WRITE
```

**Critical Observation**: Record created with `status="processing"` AFTER successful parsing/chunking

---

### Step 3: Failure Occurs
Let's say RabbitMQ publish fails:

**Location**: `services/document-processor/main.py:702-703`

```python
# Line 702-703: Publish chunks to RabbitMQ
await rabbitmq_publisher.publish_chunks(chunks, content_id)
# ↑ THIS FAILS - exception raised
```

---

### Step 4: Exception Handler - CLEANUP HAPPENS HERE
**Location**: `services/document-processor/main.py:753-783`

```python
except Exception as e:
    logger.error(f"[Batch {batch_id}] Failed to process {file.filename}: {str(e)}")

    # UPDATE CONTENT TO FAILED STATUS
    # Line 756-762: Cleanup - mark as failed
    try:
        await db.content.update_one(
            {"content_id": content_id},
            {"$set": {"status": "failed"}}  # ← CLEANUP: Set status to "failed"
        )
    except:
        pass  # Even if update fails, we continue

    # Publish batch-level error
    try:
        from websocket_handler import manager
        await manager.publish_status(f"batch:{batch_id}", {
            "type": "file_failed",
            "batch_id": batch_id,
            "filename": file.filename,
            "error": str(e)
        })
    except:
        pass

    # Line 777-783: Return failure status
    return {
        "filename": file.filename,
        "content_id": None,  # ← No content_id returned
        "status": "failed",
        "error_message": str(e),
        "file_size_mb": file_size_mb
    }
```

---

## Analysis: Are Orphaned Records Created?

### Answer: **Partially - but marked as failed**

### What Gets Created:

1. **MongoDB `content` record**:
   - ✅ Created if parsing/chunking succeeds
   - ✅ Marked as `status="failed"` in exception handler
   - ❌ NOT deleted

2. **MongoDB `batch_jobs` record**:
   - ✅ Always created for batch
   - ✅ File marked as failed in batch metadata
   - ❌ NOT deleted

3. **RabbitMQ messages**:
   - ❌ Not created (failure occurred before publish)

4. **Pinecone vectors**:
   - ❌ Not created (vectorization happens after RabbitMQ)

5. **Temp files**:
   - ✅ Cleaned up: `os.remove(file_path)` in try/except

### Orphaned Record Status:

```javascript
// In MongoDB content collection
{
  content_id: "uuid-failed-doc",
  filename: "corrupted.pdf",
  status: "failed",  // ← Clearly marked as failed
  user_id: "user-123",
  total_chunks: 0,
  // ... other fields
}
```

**Problem**: This record exists but is incomplete. However, it's marked as failed, so:
- Won't appear in "completed" document lists
- Can be filtered out in queries
- Provides audit trail of failed uploads

---

## Improved Cleanup Strategy

### Current Behavior:
- Failed records marked as `status="failed"` but kept

### Better Approach: Add Cleanup Function

Let me add a cleanup function:

**Location**: Add to `services/document-processor/main.py`

```python
async def cleanup_failed_content(content_id: str, db):
    """
    Clean up failed content record and associated data.

    Called when file processing fails to prevent orphaned records.
    """
    try:
        # Check if content exists and is failed
        content = await db.content.find_one({"content_id": content_id})

        if content and content.get("status") == "failed":
            logger.info(f"Cleaning up failed content: {content_id}")

            # Delete from MongoDB
            await db.content.delete_one({"content_id": content_id})

            # Delete any associated questions
            await db.suggested_questions.delete_many({"content_id": content_id})

            # Note: No need to clean Pinecone/RabbitMQ since they were never created

            logger.info(f"Cleanup complete for {content_id}")
            return True
        return False

    except Exception as e:
        logger.error(f"Failed to cleanup {content_id}: {e}")
        return False
```

### Updated Exception Handler:

```python
except Exception as e:
    logger.error(f"[Batch {batch_id}] Failed to process {file.filename}: {str(e)}")

    # Option 1: Mark as failed (current behavior)
    try:
        await db.content.update_one(
            {"content_id": content_id},
            {"$set": {"status": "failed"}}
        )
    except:
        pass

    # Option 2: Delete entirely (cleaner but loses audit trail)
    # try:
    #     await cleanup_failed_content(content_id, db)
    # except:
    #     pass

    return {
        "filename": file.filename,
        "content_id": None,
        "status": "failed",
        "error_message": str(e),
        "file_size_mb": file_size_mb
    }
```

---

## When MongoDB Records Are Created

Let me trace ALL database writes:

### 1. Batch Job Record
**Location**: `main.py:908`
**Timing**: BEFORE processing starts
**Content**: Batch metadata with all files marked as "pending"

```python
await db.batch_jobs.insert_one(batch_metadata.model_dump())
```

### 2. Content Record (Per File)
**Location**: `main.py:690`
**Timing**: AFTER successful parsing/chunking
**Content**: Document metadata with status="processing"

```python
await db.content.insert_one(content_metadata.model_dump())
```

**Critical Point**: This write happens INSIDE the try block, so if parsing fails, NO record is created.

### 3. Content Update on Failure
**Location**: `main.py:758-762`
**Timing**: In exception handler
**Content**: Updates status to "failed"

```python
await db.content.update_one(
    {"content_id": content_id},
    {"$set": {"status": "failed"}}
)
```

**Problem**: If `insert_one` succeeded but later steps failed, this record remains.

---

## Failure Scenarios & Cleanup

### Scenario A: Parse Fails
```
1. Generate content_id
2. Try to parse → FAILS
3. Exception handler runs
4. Try to update content → NOTHING TO UPDATE (no record exists)
5. Return failure status
```

**Result**: ✅ No orphaned record (never created)

### Scenario B: Parse Succeeds, Chunking Fails
```
1. Parse succeeds
2. Try to chunk → FAILS
3. Exception handler runs
4. Try to update content → NOTHING TO UPDATE (no record exists)
5. Return failure status
```

**Result**: ✅ No orphaned record (insert happens after chunking)

### Scenario C: Insert Succeeds, RabbitMQ Fails
```
1. Parse succeeds
2. Chunk succeeds
3. Insert to MongoDB → SUCCEEDS (status="processing")
4. Publish to RabbitMQ → FAILS
5. Exception handler runs
6. Update content status → SUCCEEDS (status="failed")
7. Return failure status
```

**Result**: ⚠️ Failed record exists in MongoDB
- Marked as `status="failed"`
- Can be queried and cleaned up
- Provides audit trail

### Scenario D: Everything Succeeds
```
1-4. All steps succeed
5. Vectorization happens asynchronously
6. Status updated to "completed" by vectorization service
```

**Result**: ✅ Complete successful record

---

## MongoDB Query to Find Orphaned Records

```javascript
// Find all failed records
db.content.find({ status: "failed" })

// Find old failed records (> 7 days)
db.content.find({
  status: "failed",
  upload_date: { $lt: new Date(Date.now() - 7*24*60*60*1000) }
})

// Count orphaned records
db.content.countDocuments({ status: "failed" })

// Clean up old failed records (manual)
db.content.deleteMany({
  status: "failed",
  upload_date: { $lt: new Date(Date.now() - 7*24*60*60*1000) }
})
```

---

## Recommended Cleanup Strategy

### Option 1: Keep Failed Records (Current)
**Pros**:
- Audit trail of failures
- Can debug issues
- Can retry manually

**Cons**:
- Database clutter
- Confusing for users

### Option 2: Auto-Delete After 24 Hours
Add a cleanup job:

```python
async def cleanup_old_failed_content():
    """Background job to clean up old failed records."""
    cutoff = datetime.utcnow() - timedelta(hours=24)

    result = await db.content.delete_many({
        "status": "failed",
        "upload_date": {"$lt": cutoff}
    })

    logger.info(f"Cleaned up {result.deleted_count} failed records")
```

### Option 3: Immediate Cleanup (Cleanest)
Update exception handler:

```python
except Exception as e:
    # If record was created, delete it
    try:
        await db.content.delete_one({"content_id": content_id})
    except:
        pass

    return {"status": "failed", "error_message": str(e)}
```

---

## Temp File Cleanup

**Location**: `main.py:727-731`

```python
# Clean up temp file
try:
    os.remove(file_path)
except Exception:
    pass  # Ignore cleanup errors
```

**Analysis**: ✅ Temp files are cleaned up even on failure

---

## Summary

### What Gets Left Behind on Failure:

| Resource | Created? | Cleaned Up? | Notes |
|----------|----------|-------------|-------|
| MongoDB content record | Sometimes* | Marked as failed | Only if parse/chunk succeeds |
| MongoDB batch_jobs | Always | No (but marked failed) | Provides audit trail |
| Temp files | Always | ✅ Yes | Cleaned in finally block |
| RabbitMQ messages | No | N/A | Not created if fails before publish |
| Pinecone vectors | No | N/A | Only created async after success |

*Only created if processing gets past parsing/chunking

### Recommendations:

1. **Short-term**: Current behavior is acceptable
   - Failed records are marked clearly
   - Can be filtered out
   - Provides debugging info

2. **Medium-term**: Add cleanup job
   - Delete failed records > 24 hours old
   - Run daily as cron job

3. **Long-term**: Implement retry mechanism
   - Allow users to retry failed uploads
   - Reuse failed content_id
   - Update status to "processing" on retry

### No Critical Issues:
- ✅ No memory leaks
- ✅ No file system clutter
- ✅ No vector database pollution
- ⚠️ Minor MongoDB clutter (failed records)
- ✅ All failures properly logged
