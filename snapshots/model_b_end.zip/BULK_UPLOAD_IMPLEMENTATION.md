# Bulk Document Upload Feature - Implementation Summary

## Overview
Implemented a comprehensive bulk document upload feature for the RAG-Edtech platform that allows teachers to upload up to 50 documents simultaneously with real-time progress tracking, concurrent processing, and detailed error handling.

## Architecture

### Backend Components

#### 1. Document Processor Service (`services/document-processor/`)

**New Schemas** (`models/schemas.py`):
- `BatchFileStatus`: Tracks individual file status within a batch
- `BatchUploadMetadata`: MongoDB document for batch job tracking
- `BatchUploadResponse`: API response for batch upload initiation

**New Endpoints** (`main.py`):
- `POST /api/documents/bulk-upload`: Initiates batch upload
  - Accepts up to 50 files (max 50MB each, 500MB total)
  - Validates file types (PDF, DOCX, TXT, MD)
  - Returns batch_id immediately
  - Processes files concurrently in background

- `GET /api/documents/batch/{batch_id}`: Gets batch status
  - Returns real-time progress
  - Includes per-file status
  - Shows completed/failed counts

- `WebSocket /ws/batch/{batch_id}/status`: Real-time updates
  - Emits file completion events
  - Sends batch progress updates
  - Notifies on final completion

**Key Functions**:
- `process_single_file_in_batch()`: Processes one file in batch context
  - Reuses existing parsing/chunking pipeline
  - Handles deduplication
  - Publishes to RabbitMQ
  - Updates MongoDB batch status

- `process_batch_files()`: Background batch coordinator
  - Runs as async task
  - Manages concurrent processing (max 5 simultaneous)
  - Updates batch metadata
  - Publishes WebSocket events

**MongoDB Collections**:
- `batch_jobs`: New collection for batch tracking
  ```javascript
  {
    batch_id: string,
    user_id: string,
    total_files: number,
    completed_files: number,
    failed_files: number,
    status: "processing" | "completed" | "partial" | "failed",
    files: [{
      filename: string,
      content_id: string?,
      status: "pending" | "processing" | "completed" | "failed",
      error_message: string?,
      upload_index: number
    }],
    created_at: datetime,
    updated_at: datetime
  }
  ```

#### 2. API Gateway Service (`services/api-gateway/`)

**New Endpoints** (`main.py`):
- `POST /api/documents/bulk-upload`: Proxies to document processor
  - Increased rate limits (10x for user, 5x globally)
  - Extended timeout (600s)
  - Handles multipart form data

- `GET /api/documents/batch/{batch_id}`: Proxies status requests

- `WebSocket /ws/batch/{batch_id}/status`: Proxies WebSocket connections

### Frontend Components

#### 1. Type Definitions (`frontend/src/api/types.ts`)

New types:
- `BatchFileStatus`: Per-file status tracking
- `BatchUploadMetadata`: Complete batch information
- `BatchUploadResponse`: Initial upload response
- `BatchUploadRequest`: Upload request payload
- `BatchWebSocketUpdate`: WebSocket event types

#### 2. API Service (`frontend/src/api/documents.service.ts`)

New methods:
- `bulkUploadDocuments()`: Uploads multiple files
- `getBatchStatus()`: Fetches batch progress

#### 3. React Components

**BatchUploadProgress.tsx** (NEW):
- Real-time progress display
- WebSocket connection management
- Per-file status indicators
- Overall progress bar
- Success/failure counts
- Error message display

Features:
- Connects to `/ws/batch/{batch_id}/status`
- Handles WebSocket reconnection
- Updates UI on file completion
- Shows final summary

**BatchResultsModal.tsx** (NEW):
- Post-upload summary dialog
- Success/failure breakdown
- Rejected files list with reasons
- Retry option for failed uploads
- Navigation to document library

Features:
- Shows completion statistics
- Lists rejected files with error reasons
- Provides retry functionality
- Clear success/failure indicators

**UploadDialog.tsx** (UPDATED):
- Now supports both single and bulk uploads
- Auto-detects bulk mode when multiple files selected
- Conditional UI based on upload mode:
  - Single: Shows title field (required)
  - Bulk: Hides title, shows file count in button
  - Both: Subject and tags apply to all files

Changes:
- Added batch upload state management
- Integrated BatchUploadProgress component
- Integrated BatchResultsModal component
- Updated FileUploader to accept up to 50 files
- Dynamic button text: "Upload All (N files)"
- Conditional form validation

## Validation Rules

### File Validation
- **Allowed types**: PDF, DOCX, TXT, MD
- **Max file size**: 50MB per file
- **Max files**: 50 per batch
- **Max batch size**: 500MB total

### Error Handling
- Individual file failures don't stop batch
- 30-second timeout per file
- Rejected files listed with specific reasons
- Partial upload success supported
- Background processing continues if user navigates away

## Concurrent Processing

### Implementation
- Uses `asyncio.Semaphore(5)` to limit concurrent files
- Maximum 5 files processing simultaneously
- Prevents resource exhaustion
- Optimizes throughput

### Benefits
- Prevents overwhelming parsing service
- Maintains system stability
- Balances speed and resource usage

## WebSocket Updates

### Event Types

1. **batch_started**:
   ```json
   {
     "type": "batch_started",
     "batch_id": "uuid",
     "total_files": 20,
     "status": "processing"
   }
   ```

2. **file_completed**:
   ```json
   {
     "type": "file_completed",
     "batch_id": "uuid",
     "filename": "chemistry_chapter1.pdf",
     "content_id": "uuid",
     "status": "processing"
   }
   ```

3. **file_failed**:
   ```json
   {
     "type": "file_failed",
     "batch_id": "uuid",
     "filename": "corrupt_file.pdf",
     "error": "Failed to parse document"
   }
   ```

4. **batch_completed**:
   ```json
   {
     "type": "batch_completed",
     "batch_id": "uuid",
     "completed_files": 18,
     "failed_files": 2,
     "status": "partial"
   }
   ```

## Testing

### Backend Tests (`services/document-processor/tests/test_bulk_upload.py`)

**Test Coverage**:
1. **Validation Tests**:
   - Empty file list rejection
   - Too many files (>50) rejection
   - Invalid file type rejection
   - File size limit enforcement
   - Total batch size limit enforcement

2. **Processing Tests**:
   - Concurrent processing limit (max 5)
   - Failure isolation (one failure doesn't stop others)
   - Timeout handling (30s per file)

3. **Status Tracking Tests**:
   - Batch metadata creation
   - Status updates during processing
   - Non-existent batch handling

4. **Integration Tests**:
   - Full batch upload flow
   - End-to-end processing verification

### Running Tests

```bash
# Backend tests
cd services/document-processor
pytest tests/test_bulk_upload.py -v

# Run specific test class
pytest tests/test_bulk_upload.py::TestBatchUploadValidation -v

# Run with coverage
pytest tests/test_bulk_upload.py --cov=. --cov-report=html
```

### Manual Testing

#### Test Scenario 1: Basic Bulk Upload (5 PDFs)
1. Navigate to Documents page
2. Click "Upload Document"
3. Select 5 PDF files
4. Add subject: "Chemistry"
5. Add tags: "chapter1, fundamentals"
6. Click "Upload All (5 files)"
7. **Expected**: Progress modal shows real-time updates per file
8. **Expected**: Final summary shows "5 uploaded, 0 failed"
9. **Expected**: All files appear in document library

#### Test Scenario 2: Large Batch (20 files)
1. Select 20 mixed PDF/DOCX files
2. Upload with subject "Physics"
3. **Expected**: Processing shows max 5 concurrent
4. **Expected**: Batch completes in reasonable time
5. **Expected**: All files vectorized correctly

#### Test Scenario 3: Mixed Success/Failure
1. Select mix of valid PDFs and invalid files (.exe, .zip)
2. Include one >50MB file
3. **Expected**: Invalid files rejected immediately
4. **Expected**: Valid files process successfully
5. **Expected**: Summary shows partial success

#### Test Scenario 4: WebSocket Reconnection
1. Start large batch upload
2. Disconnect internet briefly
3. Reconnect
4. **Expected**: Progress updates resume
5. **Expected**: Batch completes successfully

## User Flow

### Teacher Experience

1. **Selection**:
   - Drag & drop folder OR select multiple files
   - Sees file list preview
   - Gets immediate feedback on rejected files

2. **Configuration**:
   - Optionally set subject (applies to all)
   - Optionally add tags (applies to all)
   - Clicks "Upload All (N files)"

3. **Progress**:
   - Sees real-time progress bar
   - Watches per-file status updates
   - Views success/failed counts

4. **Completion**:
   - Gets summary modal
   - Sees final statistics
   - Can retry failed files
   - Navigates to document library

## Files Modified/Created

### Backend
**Modified**:
- `services/document-processor/models/schemas.py` - Added batch schemas
- `services/document-processor/main.py` - Added bulk upload endpoints
- `services/document-processor/websocket_handler.py` - Enhanced for batch support
- `services/api-gateway/main.py` - Added routing for bulk endpoints

**Created**:
- `services/document-processor/tests/test_bulk_upload.py` - Comprehensive tests

### Frontend
**Modified**:
- `frontend/src/api/types.ts` - Added batch types
- `frontend/src/api/documents.service.ts` - Added bulk upload methods
- `frontend/src/features/documents/components/UploadDialog.tsx` - Added bulk support

**Created**:
- `frontend/src/features/documents/components/BatchUploadProgress.tsx`
- `frontend/src/features/documents/components/BatchResultsModal.tsx`

## Success Criteria ✓

All success criteria met:

1. ✓ Teacher can drag 20 files and see preview list
2. ✓ "Upload All (20 files)" button initiates batch upload
3. ✓ Progress modal shows "Processing 3/20..." with live per-file updates
4. ✓ Final summary displays "18 uploaded, 2 failed" with error messages
5. ✓ All successful files appear in document library
6. ✓ All files properly vectorized and searchable
7. ✓ One file failure doesn't stop processing of others
8. ✓ Concurrent processing limited to 5 files at a time
9. ✓ File validation prevents invalid uploads
10. ✓ WebSocket provides real-time progress updates

## Performance Considerations

1. **Memory**: Files loaded into memory for validation
   - Max 500MB batch size prevents excessive memory usage
   - Files released after validation

2. **Concurrency**: Semaphore limit prevents overload
   - Max 5 concurrent parsers
   - Balances throughput and resource usage

3. **Database**: Batch tracking uses single document
   - Efficient status updates
   - Indexed on batch_id and user_id

4. **WebSocket**: Event-driven updates
   - Minimal bandwidth usage
   - Automatic reconnection support

## Future Enhancements

1. **Resumable Uploads**: Allow pausing/resuming large batches
2. **Folder Structure**: Preserve folder hierarchy in uploads
3. **Duplicate Detection**: Smart merging of duplicate batches
4. **Batch Analytics**: Track upload patterns and performance
5. **Scheduled Processing**: Defer processing to off-peak hours
6. **Priority Queue**: Allow expedited processing for urgent uploads

## Deployment Notes

1. **Database Migration**: Create `batch_jobs` collection indexes:
   ```bash
   db.batch_jobs.createIndex({ "batch_id": 1 })
   db.batch_jobs.createIndex({ "user_id": 1 })
   db.batch_jobs.createIndex({ "created_at": -1 })
   ```

2. **Environment Variables**: No new variables required

3. **Dependencies**: No new dependencies added

4. **Backward Compatibility**: Single file upload unchanged

## API Reference

### POST /api/documents/bulk-upload

**Request**:
```
Content-Type: multipart/form-data

files: [File, File, ...]  # Up to 50 files
user_id: string
subject: string (optional)
tags: string (optional, comma-separated)
```

**Response 200**:
```json
{
  "batch_id": "uuid",
  "total_files": 20,
  "accepted_files": 18,
  "rejected_files": [
    {
      "filename": "invalid.exe",
      "reason": "Unsupported file type. Allowed: PDF, DOCX, TXT, MD"
    }
  ],
  "message": "Batch upload started. Processing 18 files."
}
```

### GET /api/documents/batch/{batch_id}

**Response 200**:
```json
{
  "batch_id": "uuid",
  "user_id": "user-123",
  "total_files": 18,
  "completed_files": 15,
  "failed_files": 1,
  "status": "processing",
  "files": [
    {
      "filename": "doc1.pdf",
      "content_id": "uuid",
      "status": "completed",
      "upload_index": 0
    },
    {
      "filename": "doc2.pdf",
      "status": "failed",
      "error_message": "Parsing failed",
      "upload_index": 1
    }
  ],
  "created_at": "2025-11-13T10:30:00Z",
  "updated_at": "2025-11-13T10:32:15Z"
}
```

## Troubleshooting

### Issue: WebSocket not connecting
**Solution**: Check VITE_WS_BASE_URL environment variable

### Issue: Files rejected for no reason
**Solution**: Verify file extensions are lowercase in validation

### Issue: Batch stuck in "processing"
**Solution**: Check background task logs for exceptions

### Issue: Concurrent limit not working
**Solution**: Verify asyncio.Semaphore(5) is properly initialized

## Contact

For questions or issues, refer to:
- Backend implementation: `services/document-processor/main.py:786-1112`
- Frontend implementation: `frontend/src/features/documents/components/UploadDialog.tsx`
- Tests: `services/document-processor/tests/test_bulk_upload.py`
