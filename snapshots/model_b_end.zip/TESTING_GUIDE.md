# Bulk Upload Feature - Testing Guide

## Quick Start

### Prerequisites
- Backend services running (document-processor, api-gateway)
- Frontend development server running
- MongoDB with `batch_jobs` collection indexes
- RabbitMQ for message queuing
- Sample test files (PDFs, DOCX, TXT, MD)

### Start Services

```bash
# Terminal 1: Start document processor
cd services/document-processor
uvicorn main:app --reload --port 8002

# Terminal 2: Start API gateway
cd services/api-gateway
uvicorn main:app --reload --port 8000

# Terminal 3: Start frontend
cd frontend
npm run dev
```

## Test Scenarios

### Scenario 1: Happy Path (5 Files)
**Objective**: Verify basic bulk upload works

**Steps**:
1. Login as teacher
2. Navigate to Documents page
3. Click "Upload Document" button
4. Select 5 PDF files (drag & drop or file picker)
5. Fill in:
   - Subject: "Chemistry"
   - Tags: "test, batch1"
6. Click "Upload All (5 files)"

**Expected Results**:
- ✓ Progress modal appears immediately
- ✓ Shows "Processing 0/5..." initially
- ✓ Per-file status updates in real-time
- ✓ Progress bar fills as files complete
- ✓ Success count increments: 1/5, 2/5, 3/5, 4/5, 5/5
- ✓ Final modal shows "All 5 files uploaded successfully!"
- ✓ Files appear in document library
- ✓ Subject and tags applied to all files

**Timeline**: Should complete in 5-10 minutes (1-2 min per file)

### Scenario 2: Large Batch (20 Files)
**Objective**: Test concurrent processing and scalability

**Steps**:
1. Select 20 mixed PDF/DOCX files
2. Add subject: "Physics"
3. Upload batch

**Expected Results**:
- ✓ All files accepted
- ✓ Processing shows controlled concurrency
- ✓ No more than 5 files processing simultaneously
- ✓ Batch completes successfully
- ✓ All 20 files in library
- ✓ All properly vectorized

**Check Concurrency**:
```bash
# Watch logs to verify max 5 concurrent
tail -f services/document-processor/logs/*.log | grep "Processing file"
```

### Scenario 3: Mixed Valid/Invalid Files
**Objective**: Test file validation and rejection

**Steps**:
1. Select mix of files:
   - 3 valid PDFs
   - 1 invalid .exe file
   - 1 oversized file (>50MB)
   - 1 valid DOCX
2. Try to upload

**Expected Results**:
- ✓ Rejected files shown immediately
- ✓ Rejection reasons displayed:
  - ".exe: Unsupported file type"
  - "large.pdf: File too large (52.3MB). Maximum 50MB"
- ✓ Only 4 valid files process
- ✓ Final summary: "4 uploaded, 0 failed"

### Scenario 4: Processing Failures
**Objective**: Test failure isolation

**Steps**:
1. Include mix of:
   - Good PDFs
   - Corrupted PDF (intentionally damaged file)
   - Good DOCX
2. Upload batch

**Expected Results**:
- ✓ All files accepted initially (valid types/sizes)
- ✓ Corrupted file fails during processing
- ✓ Other files continue processing
- ✓ Final summary shows partial success
- ✓ Error message shown for failed file
- ✓ Option to retry failed file

### Scenario 5: Network Interruption
**Objective**: Test resilience and recovery

**Steps**:
1. Start large batch (15 files)
2. After 5 files complete, disconnect internet
3. Wait 10 seconds
4. Reconnect internet

**Expected Results**:
- ✓ Progress continues from where it left off
- ✓ No duplicate processing
- ✓ All remaining files complete
- ✓ Batch status remains consistent

### Scenario 6: User Navigation During Upload
**Objective**: Test background processing

**Steps**:
1. Start batch upload (10 files)
2. Immediately close upload dialog
3. Navigate to different page
4. Come back to Documents page after 2 minutes

**Expected Results**:
- ✓ Upload continues in background
- ✓ Files appear in library as they complete
- ✓ No data loss
- ✓ Batch completes successfully

### Scenario 7: Duplicate Content
**Objective**: Test deduplication in batch

**Steps**:
1. Upload batch with duplicate content:
   - Same PDF uploaded twice with different names
   - Or identical content in different formats
2. Check results

**Expected Results**:
- ✓ Both files accepted initially
- ✓ Second file detected as duplicate
- ✓ Status shows "Duplicate detected - linked to your account"
- ✓ No duplicate vectors created
- ✓ Upload history updated on both

### Scenario 8: Maximum Limits
**Objective**: Test boundary conditions

**Test 8a: Max Files (51)**:
```
Expected: Rejected with "Maximum 50 files per batch"
```

**Test 8b: Total Size (>500MB)**:
```
Expected: Rejected with "Total batch size exceeds maximum 500MB"
```

**Test 8c: Single Large File (51MB)**:
```
Expected: Rejected with "File too large. Maximum 50MB per file"
```

## Backend Testing

### Run Unit Tests
```bash
cd services/document-processor
pytest tests/test_bulk_upload.py -v
```

### Run Specific Test Classes
```bash
# Validation tests only
pytest tests/test_bulk_upload.py::TestBatchUploadValidation -v

# Processing tests only
pytest tests/test_bulk_upload.py::TestBatchUploadProcessing -v

# Status tracking tests only
pytest tests/test_bulk_upload.py::TestBatchStatusTracking -v

# Integration tests only
pytest tests/test_bulk_upload.py::TestBatchUploadIntegration -v
```

### Run with Coverage
```bash
pytest tests/test_bulk_upload.py --cov=. --cov-report=html
open htmlcov/index.html
```

## API Testing with curl

### Test Bulk Upload Endpoint
```bash
# Prepare test files
echo "Test content 1" > test1.pdf
echo "Test content 2" > test2.pdf

# Upload batch
curl -X POST http://localhost:8000/api/documents/bulk-upload \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "files=@test1.pdf" \
  -F "files=@test2.pdf" \
  -F "user_id=test-user-123" \
  -F "subject=Testing" \
  -F "tags=test,curl"

# Expected response:
# {
#   "batch_id": "uuid-here",
#   "total_files": 2,
#   "accepted_files": 2,
#   "rejected_files": [],
#   "message": "Batch upload started. Processing 2 files."
# }
```

### Test Batch Status Endpoint
```bash
# Get batch status
curl http://localhost:8000/api/documents/batch/BATCH_ID_HERE \
  -H "Authorization: Bearer YOUR_TOKEN"

# Expected response:
# {
#   "batch_id": "uuid-here",
#   "user_id": "test-user-123",
#   "total_files": 2,
#   "completed_files": 2,
#   "failed_files": 0,
#   "status": "completed",
#   "files": [...]
# }
```

### Test WebSocket Connection
```javascript
// In browser console
const ws = new WebSocket('ws://localhost:8000/ws/batch/BATCH_ID_HERE/status')

ws.onopen = () => console.log('Connected')
ws.onmessage = (event) => console.log('Update:', JSON.parse(event.data))
ws.onerror = (error) => console.error('Error:', error)

// You should see messages like:
// { type: "batch_started", batch_id: "...", total_files: 5 }
// { type: "file_completed", filename: "doc1.pdf", content_id: "..." }
// { type: "batch_completed", completed_files: 5, failed_files: 0 }
```

## Performance Testing

### Test Concurrent Processing Limit
```python
# Check that max 5 files process concurrently
import asyncio
import time

async def monitor_concurrency():
    # Start batch with 20 files
    # Monitor logs for concurrent processing
    # Verify never more than 5 at once
    pass
```

### Measure Upload Time
```bash
# Time a 10-file upload
time curl -X POST http://localhost:8000/api/documents/bulk-upload \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -F "files=@doc1.pdf" \
  ... (10 files total)

# Expected: Immediate response (<1s)
# Background processing: ~10-20 minutes for 10 files
```

## Database Verification

### Check Batch Jobs Collection
```javascript
// MongoDB shell
use edtech_db

// Find recent batches
db.batch_jobs.find().sort({created_at: -1}).limit(5).pretty()

// Check specific batch
db.batch_jobs.findOne({batch_id: "BATCH_ID_HERE"})

// Verify indexes
db.batch_jobs.getIndexes()
```

### Check Content Collection
```javascript
// Verify uploaded documents
db.content.find({
  "metadata.batch_id": "BATCH_ID_HERE"
}).pretty()

// Count successful uploads from batch
db.content.countDocuments({
  "metadata.batch_id": "BATCH_ID_HERE",
  status: "completed"
})
```

## Troubleshooting Tests

### WebSocket Not Connecting
```bash
# Check WebSocket URL
echo $VITE_WS_BASE_URL

# Should be: ws://localhost:8000

# Test WebSocket endpoint directly
wscat -c ws://localhost:8000/ws/batch/test-batch-id/status
```

### Files Not Processing
```bash
# Check RabbitMQ
# Verify queues exist and messages are being consumed
curl http://localhost:15672/api/queues

# Check document processor logs
tail -f services/document-processor/app.log
```

### Batch Stuck in "Processing"
```bash
# Check background task status
# Look for exceptions in logs
grep "Fatal error in batch processing" services/document-processor/*.log

# Manually update batch status if needed (development only)
db.batch_jobs.updateOne(
  {batch_id: "STUCK_BATCH_ID"},
  {$set: {status: "failed", updated_at: new Date()}}
)
```

## Test Data Generation

### Create Test PDFs
```python
# generate_test_pdfs.py
from reportlab.pdfgen import canvas

for i in range(20):
    c = canvas.Canvas(f"test_doc_{i}.pdf")
    c.drawString(100, 750, f"Test Document {i}")
    c.drawString(100, 700, "Sample content for testing bulk upload")
    c.drawString(100, 650, "Chemistry - Chapter 1")
    c.save()

print("Created 20 test PDFs")
```

### Create Invalid Test Files
```bash
# Create oversized file
dd if=/dev/zero of=large.pdf bs=1M count=51

# Create invalid type
echo "Not a PDF" > invalid.exe
```

## Performance Benchmarks

### Expected Performance
- **Small batch (5 files)**: 5-10 minutes total
- **Medium batch (20 files)**: 20-40 minutes total
- **Concurrent processing**: Never more than 5 simultaneous
- **Memory usage**: <2GB for 50-file batch
- **API response time**: <500ms for batch initiation
- **WebSocket latency**: <100ms for status updates

### Monitoring Commands
```bash
# Watch memory usage
watch -n 1 'ps aux | grep "uvicorn main:app"'

# Watch file processing rate
watch -n 5 'curl -s http://localhost:8000/api/documents/batch/BATCH_ID | jq ".completed_files"'

# Monitor WebSocket connections
netstat -an | grep 8000 | grep ESTABLISHED | wc -l
```

## Success Checklist

Before considering feature complete, verify:

- [ ] Unit tests pass (pytest)
- [ ] Can upload 5 files successfully
- [ ] Can upload 20 files successfully
- [ ] Invalid files rejected properly
- [ ] File size limits enforced
- [ ] Batch size limits enforced
- [ ] Concurrent limit works (max 5)
- [ ] One failure doesn't stop others
- [ ] WebSocket updates work
- [ ] Progress modal shows real-time updates
- [ ] Results modal shows accurate summary
- [ ] Files appear in document library
- [ ] Files are vectorized correctly
- [ ] Can search uploaded documents
- [ ] Deduplication works in batch
- [ ] Background processing continues on navigation
- [ ] Subject applies to all files
- [ ] Tags apply to all files

## Common Issues and Solutions

| Issue | Solution |
|-------|----------|
| "Module not found" error | Run `pip install -r requirements.txt` |
| WebSocket 403 error | Check authentication token |
| Files not vectorizing | Check RabbitMQ connection |
| Slow processing | Verify only 5 concurrent (not more) |
| Modal not appearing | Check frontend console for errors |
| Batch stuck | Check background task logs |

## Contact

For test failures or questions:
1. Check logs in `services/document-processor/app.log`
2. Verify database state in MongoDB
3. Test API endpoints directly with curl
4. Review implementation in `BULK_UPLOAD_IMPLEMENTATION.md`
