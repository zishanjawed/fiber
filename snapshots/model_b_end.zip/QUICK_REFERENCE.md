# Bulk Upload - Quick Reference Card

## 🔍 Key Code Locations

| Component | File | Line | What It Does |
|-----------|------|------|--------------|
| Semaphore limit | `main.py` | 927 | `Semaphore(5)` - limits concurrent processing |
| Batch upload endpoint | `main.py` | 786 | POST /api/documents/bulk-upload |
| Batch status endpoint | `main.py` | 1082 | GET /api/documents/batch/{batch_id} |
| WebSocket endpoint | `main.py` | 153 | WS /ws/batch/{batch_id}/status |
| File processing | `main.py` | 576 | `process_single_file_in_batch()` |
| Cleanup handler | `main.py` | 753 | Exception handler - marks as failed |
| Progress component | `BatchUploadProgress.tsx` | 23 | Real-time WebSocket updates |
| Results modal | `BatchResultsModal.tsx` | 1 | Summary after completion |
| Upload dialog | `UploadDialog.tsx` | 67 | Handles both single and bulk |

## 🎯 Quick Tests

### Test Concurrent Limit
```bash
cd services/document-processor/tests
python test_concurrency_demo.py
# Watch: Max 5 concurrent, file #6 waits
```

### Test WebSocket Disconnect
```javascript
// In browser console
const ws = new WebSocket('ws://localhost:8000/ws/batch/BATCH_ID/status')
ws.onmessage = e => console.log(JSON.parse(e.data))
setTimeout(() => ws.close(), 5000)  // Disconnect after 5s
// Upload continues!
```

### Find Failed Records
```javascript
// MongoDB
db.content.find({ status: "failed" })
db.content.countDocuments({ status: "failed" })
```

### Manual Upload Test
```bash
curl -X POST http://localhost:8000/api/documents/bulk-upload \
  -H "Authorization: Bearer TOKEN" \
  -F "files=@doc1.pdf" \
  -F "files=@doc2.pdf" \
  -F "user_id=user-123"
```

## 📊 Event Flow (3 files)

```
t=0s   → batch_started        (total: 3)
t=1s   → file_completed       (doc1.pdf)
t=2s   → file_failed          (doc2.pdf)
t=3s   → file_completed       (doc3.pdf)
t=3.1s → batch_completed      (completed: 2, failed: 1)
```

## 🔧 Common Issues

| Issue | Solution | Code Location |
|-------|----------|---------------|
| Files stuck processing | Check RabbitMQ connection | `main.py:702` |
| WebSocket not connecting | Verify VITE_WS_BASE_URL | `BatchUploadProgress.tsx:28` |
| Orphaned records | Query: `db.content.find({status:"failed"})` | N/A |
| Concurrent > 5 | Check semaphore creation | `main.py:927` |

## 🎨 State Flow

```
User clicks "Upload All (5 files)"
    ↓
UploadDialog.handleUpload()
    ↓
isBatchUpload? → handleBatchUpload()
    ↓
API: POST /api/documents/bulk-upload
    ↓
Response: { batch_id: "uuid-123" }
    ↓
setBatchId() → triggers render
    ↓
<BatchUploadProgress batchId="uuid-123" /> mounts
    ↓
useEffect → WebSocket connects
    ↓
Events received → State updates → UI updates
    ↓
batch_completed → onComplete() → Results modal
```

## 🚀 Validation Rules

- **Max files**: 50 per batch
- **Max file size**: 50MB each
- **Max batch size**: 500MB total
- **Allowed types**: PDF, DOCX, TXT, MD
- **Concurrent limit**: 5 files at once
- **Timeout**: 30 seconds per file

## 📝 WebSocket Events

```typescript
// batch_started
{ type: "batch_started", batch_id, total_files, status: "processing" }

// file_completed
{ type: "file_completed", batch_id, filename, content_id, status }

// file_failed
{ type: "file_failed", batch_id, filename, error }

// batch_completed
{ type: "batch_completed", batch_id, completed_files, failed_files, status }
```

## 🔐 Security Considerations

- ✅ Rate limits: 10x normal for batch uploads
- ✅ File type validation
- ✅ File size validation
- ✅ User authentication required
- ✅ Batch ownership verified

## 📈 Performance Metrics

| Metric | Expected Value |
|--------|----------------|
| API response time | < 500ms |
| WebSocket latency | < 100ms |
| Concurrent processing | Max 5 files |
| Memory per batch | < 2GB |
| Processing time | 1-2 min per file |

## 🐛 Debugging

### Check WebSocket Connection
```bash
# See active connections
netstat -an | grep 8000 | grep ESTABLISHED

# Monitor WebSocket
wscat -c ws://localhost:8000/ws/batch/BATCH_ID/status
```

### Check Redis Pubsub
```bash
redis-cli
> PSUBSCRIBE document:status:*
```

### Check Batch Processing
```bash
# Get batch status
curl http://localhost:8000/api/documents/batch/BATCH_ID | jq

# Watch logs
tail -f services/document-processor/app.log | grep "Batch"
```

### Check Semaphore Limit
```bash
# In logs, count concurrent processing
tail -f app.log | grep "Processing file" | wc -l
# Should never exceed 5
```

## 📚 Documentation Files

- `BULK_UPLOAD_IMPLEMENTATION.md` - Complete implementation details
- `TESTING_GUIDE.md` - Comprehensive testing scenarios
- `WEBSOCKET_FLOW.md` - WebSocket event flow details
- `ERROR_RECOVERY.md` - Error handling and cleanup
- `FRONTEND_INTEGRATION.md` - React component details
- `VERIFICATION_SUMMARY.md` - Answers to critical questions

## ✅ Quick Verification

```bash
# 1. Test concurrency
python tests/test_concurrency_demo.py

# 2. Run unit tests
pytest tests/test_bulk_upload.py -v

# 3. Upload 3 files
curl -X POST ... (see manual test above)

# 4. Check WebSocket
wscat -c ws://localhost:8000/ws/batch/BATCH_ID/status

# 5. Verify in MongoDB
mongo edtech_db --eval "db.batch_jobs.find().limit(1).pretty()"
```

## 🎓 Key Concepts

**Semaphore**: Python's `asyncio.Semaphore(5)` guarantees max 5 concurrent. Uses event loop to block coroutines. Cannot be bypassed.

**WebSocket Independence**: Background task runs regardless of WebSocket. WebSocket failures logged but ignored.

**Error Isolation**: One file failure doesn't stop others. Each file in try/except block.

**Cleanup**: Temp files always cleaned. MongoDB records marked "failed" for audit trail.

**State Management**: React uses Map for O(1) file lookup. State updates trigger re-renders.

## 🔗 API Endpoints

```
POST   /api/documents/bulk-upload        # Initiate batch
GET    /api/documents/batch/{batch_id}   # Get status
WS     /ws/batch/{batch_id}/status       # Real-time updates
```

## 🎨 UI Components

```
<UploadDialog>
  ├── Multiple file selection
  ├── Conditional title field (single only)
  └── <BatchUploadProgress>
        ├── WebSocket connection
        ├── Per-file status list
        ├── Progress bar
        └── Success/fail counters

<BatchResultsModal>
  ├── Statistics grid
  ├── Rejected files list
  └── Retry option
```
