"""
Tests for bulk document upload functionality.

Tests cover:
- Batch upload creation
- File validation (type, size, count)
- Concurrent processing limits
- Failure isolation
- Status tracking
- WebSocket updates
"""
import pytest
import asyncio
from fastapi.testclient import TestClient
from io import BytesIO
from unittest.mock import Mock, patch, AsyncMock
import json

# Import the app
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from main import app


@pytest.fixture
def client():
    """Create test client."""
    return TestClient(app)


@pytest.fixture
def mock_db():
    """Mock MongoDB database."""
    mock = AsyncMock()
    mock.batch_jobs = AsyncMock()
    mock.content = AsyncMock()
    mock.users = AsyncMock()

    # Mock user
    mock.users.find_one = AsyncMock(return_value={
        "user_id": "test-user-123",
        "full_name": "Test User"
    })

    return mock


@pytest.fixture
def sample_files():
    """Create sample test files."""
    files = []
    for i in range(5):
        content = f"Sample PDF content {i}" * 100
        file = BytesIO(content.encode())
        file.name = f"test_doc_{i}.pdf"
        files.append(("files", (f"test_doc_{i}.pdf", file, "application/pdf")))
    return files


class TestBatchUploadValidation:
    """Test batch upload validation."""

    def test_empty_file_list(self, client):
        """Test validation error when no files provided."""
        response = client.post(
            "/api/documents/bulk-upload",
            data={"user_id": "test-user-123"},
            files=[]
        )
        assert response.status_code == 422  # Validation error

    def test_too_many_files(self, client):
        """Test rejection when exceeding max file count."""
        # Create 51 files (max is 50)
        files = []
        for i in range(51):
            content = f"Test content {i}"
            file = BytesIO(content.encode())
            files.append(("files", (f"test_{i}.pdf", file, "application/pdf")))

        response = client.post(
            "/api/documents/bulk-upload",
            data={"user_id": "test-user-123"},
            files=files
        )

        assert response.status_code == 400
        assert "Maximum 50 files" in response.json()["detail"]

    def test_invalid_file_type(self, client):
        """Test rejection of invalid file types."""
        invalid_file = BytesIO(b"test content")

        response = client.post(
            "/api/documents/bulk-upload",
            data={"user_id": "test-user-123"},
            files=[
                ("files", ("test.txt", BytesIO(b"valid content"), "text/plain")),
                ("files", ("test.exe", invalid_file, "application/x-executable"))
            ]
        )

        assert response.status_code == 200
        data = response.json()
        assert data["accepted_files"] == 1
        assert len(data["rejected_files"]) == 1
        assert "test.exe" in data["rejected_files"][0]["filename"]

    def test_file_too_large(self, client):
        """Test rejection of files exceeding size limit."""
        # Create a 51MB file (max is 50MB)
        large_content = b"x" * (51 * 1024 * 1024)

        response = client.post(
            "/api/documents/bulk-upload",
            data={"user_id": "test-user-123"},
            files=[
                ("files", ("large.pdf", BytesIO(large_content), "application/pdf"))
            ]
        )

        assert response.status_code == 200
        data = response.json()
        assert len(data["rejected_files"]) > 0
        assert "too large" in data["rejected_files"][0]["reason"].lower()

    def test_total_batch_size_exceeded(self, client):
        """Test rejection when total batch size exceeds limit."""
        # Create files totaling over 500MB
        files = []
        for i in range(11):  # 11 * 48MB = 528MB > 500MB limit
            content = b"x" * (48 * 1024 * 1024)
            files.append(("files", (f"big_{i}.pdf", BytesIO(content), "application/pdf")))

        response = client.post(
            "/api/documents/bulk-upload",
            data={"user_id": "test-user-123"},
            files=files
        )

        assert response.status_code == 400
        assert "batch size" in response.json()["detail"].lower()


class TestBatchUploadProcessing:
    """Test batch upload processing logic."""

    @pytest.mark.asyncio
    async def test_concurrent_processing_limit(self):
        """Test that concurrent processing respects semaphore limit (max 5)."""
        import asyncio
        from unittest.mock import Mock

        # Track active processing
        active_count = 0
        max_concurrent = 0
        processing_log = []

        async def mock_process_file(file_idx):
            nonlocal active_count, max_concurrent

            # Record entry
            active_count += 1
            max_concurrent = max(max_concurrent, active_count)
            processing_log.append(f"START file_{file_idx} (active: {active_count})")

            # Simulate processing time
            await asyncio.sleep(0.2)

            # Record exit
            active_count -= 1
            processing_log.append(f"END file_{file_idx} (active: {active_count})")

            return file_idx, {"status": "completed", "filename": f"file_{file_idx}"}

        # Create semaphore like in real code
        semaphore = asyncio.Semaphore(5)

        async def process_with_semaphore(file_idx):
            async with semaphore:  # This is the key line that limits concurrency
                return await mock_process_file(file_idx)

        # Launch 10 files to test the limit
        tasks = [process_with_semaphore(i) for i in range(10)]
        results = await asyncio.gather(*tasks)

        # Print processing log for verification
        print("\nProcessing Log:")
        for entry in processing_log:
            print(entry)

        # Assertions
        assert max_concurrent == 5, f"Expected max 5 concurrent, got {max_concurrent}"
        assert active_count == 0, "All files should have completed"
        assert len(results) == 10, "All files should have been processed"

        # Verify we never had more than 5 active at once
        print(f"\n✓ Max concurrent processing: {max_concurrent} (limit: 5)")
        print(f"✓ Total files processed: {len(results)}")

        # Additional verification: Check processing log
        active_at_any_time = []
        current_active = 0
        for entry in processing_log:
            if "START" in entry:
                current_active += 1
                active_at_any_time.append(current_active)
            elif "END" in entry:
                current_active -= 1

        assert max(active_at_any_time) == 5, "Log should confirm max 5 concurrent"

    @pytest.mark.asyncio
    async def test_failure_isolation(self, mock_db):
        """Test that one file failure doesn't stop others."""
        from main import process_single_file_in_batch

        # Mock one file to fail, others to succeed
        call_count = [0]

        async def mock_parse(*args, **kwargs):
            call_count[0] += 1
            if call_count[0] == 2:
                raise Exception("Simulated parse error")
            return {
                "content": "Test content",
                "title": "Test",
                "metadata": {},
                "structure": []
            }

        with patch("main.docling_parser.parse_document", side_effect=mock_parse):
            with patch("main.chunker.chunk_document", return_value=[]):
                with patch("main.content_hasher.generate_content_hash", return_value="hash123"):
                    mock_db.content.find_one = AsyncMock(return_value=None)
                    mock_db.content.insert_one = AsyncMock()

                    # Process 3 files - middle one should fail
                    files = []
                    for i in range(3):
                        file = Mock()
                        file.filename = f"test_{i}.pdf"
                        content = b"test content"

                        result = await process_single_file_in_batch(
                            file=file,
                            file_content=content,
                            user_id="test-user",
                            batch_id="batch-123",
                            file_index=i,
                            db=mock_db
                        )

                        files.append(result)

                    # First and third should succeed, second should fail
                    assert files[0]["status"] in ["completed", "processing"]
                    assert files[1]["status"] == "failed"
                    assert files[2]["status"] in ["completed", "processing"]

    @pytest.mark.asyncio
    async def test_timeout_handling(self, mock_db):
        """Test that file processing respects timeout limits."""
        from main import process_single_file_in_batch

        async def slow_parse(*args, **kwargs):
            await asyncio.sleep(35)  # Exceed 30s timeout
            return {"content": "Test", "title": "Test", "metadata": {}, "structure": []}

        with patch("main.docling_parser.parse_document", side_effect=slow_parse):
            file = Mock()
            file.filename = "slow.pdf"

            try:
                result = await asyncio.wait_for(
                    process_single_file_in_batch(
                        file=file,
                        file_content=b"content",
                        user_id="test-user",
                        batch_id="batch-123",
                        file_index=0,
                        db=mock_db
                    ),
                    timeout=30.0
                )
                assert False, "Should have timed out"
            except asyncio.TimeoutError:
                pass  # Expected


class TestBatchStatusTracking:
    """Test batch status tracking."""

    def test_get_batch_status_not_found(self, client):
        """Test getting status of non-existent batch."""
        response = client.get("/api/documents/batch/nonexistent-batch-id")
        assert response.status_code == 404

    @pytest.mark.asyncio
    async def test_batch_metadata_created(self, client, sample_files, mock_db):
        """Test that batch metadata is created correctly."""
        with patch("main.get_mongodb", return_value=mock_db):
            mock_db.batch_jobs.insert_one = AsyncMock()

            response = client.post(
                "/api/documents/bulk-upload",
                data={
                    "user_id": "test-user-123",
                    "subject": "Chemistry",
                    "tags": "test,sample"
                },
                files=sample_files
            )

            assert response.status_code == 200
            data = response.json()

            # Check batch metadata was created
            assert "batch_id" in data
            assert data["accepted_files"] == 5

            # Verify insert was called with correct structure
            mock_db.batch_jobs.insert_one.assert_called_once()
            batch_data = mock_db.batch_jobs.insert_one.call_args[0][0]

            assert batch_data["user_id"] == "test-user-123"
            assert batch_data["total_files"] == 5
            assert batch_data["status"] == "processing"
            assert len(batch_data["files"]) == 5

    @pytest.mark.asyncio
    async def test_batch_status_updates(self, mock_db):
        """Test that batch status is updated as files complete."""
        from main import process_batch_files

        # Mock tasks that return results
        tasks = [
            asyncio.create_task(asyncio.sleep(0.01, result=(0, {
                "filename": "test_0.pdf",
                "status": "completed",
                "content_id": "id-0"
            }))),
            asyncio.create_task(asyncio.sleep(0.01, result=(1, {
                "filename": "test_1.pdf",
                "status": "failed",
                "error_message": "Test error"
            }))),
            asyncio.create_task(asyncio.sleep(0.01, result=(2, {
                "filename": "test_2.pdf",
                "status": "completed",
                "content_id": "id-2"
            }))),
        ]

        mock_db.batch_jobs.update_one = AsyncMock()

        await process_batch_files("batch-123", tasks, mock_db)

        # Verify batch was updated
        assert mock_db.batch_jobs.update_one.call_count >= 4  # 3 file updates + 1 final

        # Check final update
        final_call = mock_db.batch_jobs.update_one.call_args
        assert final_call[0][0] == {"batch_id": "batch-123"}
        final_update = final_call[0][1]["$set"]

        assert final_update["completed_files"] == 2
        assert final_update["failed_files"] == 1
        assert final_update["status"] == "partial"


class TestBatchUploadIntegration:
    """Integration tests for full batch upload flow."""

    @pytest.mark.asyncio
    async def test_full_batch_upload_flow(self, client, mock_db):
        """Test complete batch upload from submission to completion."""
        with patch("main.get_mongodb", return_value=mock_db):
            with patch("main.docling_parser.parse_document") as mock_parse:
                with patch("main.chunker.chunk_document") as mock_chunk:
                    with patch("main.rabbitmq_publisher.publish_chunks") as mock_publish:
                        # Setup mocks
                        mock_parse.return_value = {
                            "content": "Test content",
                            "title": "Test Document",
                            "metadata": {"page_count": 1},
                            "structure": []
                        }

                        mock_chunk.return_value = [
                            {
                                "text": "Chunk 1",
                                "metadata": {},
                                "token_count": 10
                            }
                        ]

                        mock_publish.return_value = None
                        mock_db.content.find_one = AsyncMock(return_value=None)
                        mock_db.content.insert_one = AsyncMock()
                        mock_db.batch_jobs.insert_one = AsyncMock()
                        mock_db.batch_jobs.update_one = AsyncMock()

                        # Create test files
                        files = [
                            ("files", ("doc1.pdf", BytesIO(b"content 1"), "application/pdf")),
                            ("files", ("doc2.pdf", BytesIO(b"content 2"), "application/pdf")),
                        ]

                        # Submit batch
                        response = client.post(
                            "/api/documents/bulk-upload",
                            data={"user_id": "test-user-123"},
                            files=files
                        )

                        assert response.status_code == 200
                        data = response.json()

                        assert data["accepted_files"] == 2
                        assert len(data["rejected_files"]) == 0

                        # Wait for background processing
                        await asyncio.sleep(0.5)

                        # Verify all files were processed
                        assert mock_db.content.insert_one.call_count == 2
                        assert mock_publish.call_count == 2


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
