"""
Pydantic models for document processing service.
"""
from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import UUID, uuid4


class DocumentUploadResponse(BaseModel):
    """Response model for document upload."""
    content_id: str
    filename: str
    file_type: str
    status: str
    total_chunks: int
    message: str
    is_duplicate: bool = False  # Indicates if document was a duplicate
    duplicate_of: Optional[str] = None  # Original content_id if duplicate


class UploadHistoryEntry(BaseModel):
    """Single entry in document upload history."""
    user_id: str
    user_name: str
    upload_date: datetime
    filename: str
    content_hash: str


class ContentMetadata(BaseModel):
    """Content metadata stored in MongoDB with deduplication and traceability."""
    content_id: str = Field(default_factory=lambda: str(uuid4()))
    filename: str
    file_type: str
    upload_date: datetime = Field(default_factory=datetime.utcnow)
    user_id: str  # Current owner/uploader
    
    # Deduplication fields
    content_hash: Optional[str] = None  # SHA-256 hash of content
    is_duplicate: bool = False  # Flag if this is a duplicate upload
    
    # Traceability fields
    original_uploader_id: str = None  # First person who uploaded this content
    original_upload_date: datetime = Field(default_factory=datetime.utcnow)
    upload_history: List[Dict[str, Any]] = []  # Track all uploaders
    
    # Version tracking (for future content updates)
    version_number: int = 1
    parent_content_id: Optional[str] = None  # For version lineage
    
    # Processing status
    status: str = "processing"  # processing, completed, failed
    total_chunks: int = 0
    processed_chunks: int = 0
    
    # Tags for filtering and organization
    tags: List[str] = []
    
    # Additional metadata
    metadata: Dict[str, Any] = {}
    
    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class DocumentChunk(BaseModel):
    """Model for a document chunk."""
    content_id: str
    chunk_index: int
    text: str
    token_count: int
    metadata: Dict[str, Any]

    class Config:
        json_schema_extra = {
            "example": {
                "content_id": "123e4567-e89b-12d3-a456-426614174000",
                "chunk_index": 0,
                "text": "This is a sample chunk of text...",
                "token_count": 100,
                "metadata": {
                    "section_title": "Introduction",
                    "page_number": 1
                }
            }
        }


# ============================================================================
# Batch Upload Models
# ============================================================================

class BatchFileStatus(BaseModel):
    """Status of a single file within a batch upload."""
    filename: str
    file_index: int
    status: str = "pending"  # pending, processing, completed, failed
    content_id: Optional[str] = None
    error_message: Optional[str] = None
    is_duplicate: bool = False
    duplicate_of: Optional[str] = None
    total_chunks: int = 0
    processed_chunks: int = 0
    progress: int = 0  # 0-100
    started_at: Optional[datetime] = None
    completed_at: Optional[datetime] = None


class BatchJob(BaseModel):
    """Batch upload job tracking model stored in MongoDB."""
    batch_id: str = Field(default_factory=lambda: str(uuid4()))
    user_id: str
    total_files: int
    completed_files: int = 0
    failed_files: int = 0
    status: str = "pending"  # pending, processing, completed, failed, cancelled
    files: List[BatchFileStatus] = []
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = None

    # Metadata for the batch
    total_size_bytes: int = 0
    subject: Optional[str] = None
    tags: List[str] = []

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class BatchUploadRequest(BaseModel):
    """Request model for batch upload validation."""
    user_id: str
    title_prefix: Optional[str] = None
    subject: Optional[str] = None
    tags: Optional[str] = None  # Comma-separated


class BatchUploadResponse(BaseModel):
    """Response model for batch upload initiation."""
    batch_id: str
    total_files: int
    status: str
    message: str
    files: List[Dict[str, Any]]  # Preview of files to be processed


class BatchStatusResponse(BaseModel):
    """Response model for batch status query."""
    batch_id: str
    user_id: str
    total_files: int
    completed_files: int
    failed_files: int
    status: str
    files: List[BatchFileStatus]
    created_at: datetime
    updated_at: datetime
    completed_at: Optional[datetime] = None
    progress_percentage: float = 0.0

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

