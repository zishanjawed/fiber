/**
 * BatchResultsModal Component
 * Summary dialog shown when batch upload completes
 */

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../../../components/ui/dialog'
import { Button } from '../../../components/ui/Button'
import { Badge } from '../../../components/ui/Badge'
import { ScrollArea } from '../../../components/ui/scroll-area'
import { Alert, AlertDescription } from '../../../components/ui/alert'
import {
  CheckCircle,
  XCircle,
  Copy,
  RefreshCw,
  ExternalLink,
  PartyPopper,
} from 'lucide-react'
import type { BatchFileStatus } from '../../../api/types'
import { useNavigate } from 'react-router-dom'

interface BatchResultsModalProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  completedFiles: number
  failedFiles: number
  files: BatchFileStatus[]
  onRetryFailed?: (failedFiles: BatchFileStatus[]) => void
}

export function BatchResultsModal({
  open,
  onOpenChange,
  completedFiles,
  failedFiles,
  files,
  onRetryFailed,
}: BatchResultsModalProps) {
  const navigate = useNavigate()

  const successfulFiles = files.filter((f) => f.status === 'completed')
  const failedFilesList = files.filter((f) => f.status === 'failed')
  const duplicateFiles = files.filter((f) => f.is_duplicate)

  const handleViewLibrary = () => {
    onOpenChange(false)
    navigate('/documents')
  }

  const handleRetryFailed = () => {
    if (onRetryFailed && failedFilesList.length > 0) {
      onRetryFailed(failedFilesList)
    }
  }

  const getResultsMessage = () => {
    if (failedFiles === 0) {
      return 'All documents were uploaded successfully!'
    } else if (completedFiles === 0) {
      return 'All uploads failed. Please check the errors below.'
    } else {
      return `${completedFiles} document(s) uploaded successfully, ${failedFiles} failed.`
    }
  }

  const getResultsVariant = () => {
    if (failedFiles === 0) return 'success'
    if (completedFiles === 0) return 'error'
    return 'warning'
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {failedFiles === 0 ? (
              <>
                <PartyPopper className="h-5 w-5 text-green-500" />
                Batch Upload Complete!
              </>
            ) : completedFiles === 0 ? (
              <>
                <XCircle className="h-5 w-5 text-red-500" />
                Upload Failed
              </>
            ) : (
              <>
                <CheckCircle className="h-5 w-5 text-yellow-500" />
                Upload Completed with Issues
              </>
            )}
          </DialogTitle>
          <DialogDescription>{getResultsMessage()}</DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          {/* Summary Stats */}
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-3 bg-green-50 rounded-lg border border-green-200">
              <div className="text-2xl font-bold text-green-600">{completedFiles}</div>
              <div className="text-xs text-green-700">Successful</div>
            </div>
            <div className="text-center p-3 bg-red-50 rounded-lg border border-red-200">
              <div className="text-2xl font-bold text-red-600">{failedFiles}</div>
              <div className="text-xs text-red-700">Failed</div>
            </div>
            <div className="text-center p-3 bg-blue-50 rounded-lg border border-blue-200">
              <div className="text-2xl font-bold text-blue-600">{duplicateFiles.length}</div>
              <div className="text-xs text-blue-700">Duplicates</div>
            </div>
          </div>

          {/* Successful Files */}
          {successfulFiles.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium flex items-center gap-2">
                <CheckCircle className="h-4 w-4 text-green-500" />
                Successfully Uploaded ({successfulFiles.length})
              </h4>
              <ScrollArea className="h-32 border rounded-md">
                <div className="p-2 space-y-1">
                  {successfulFiles.map((file, idx) => (
                    <div
                      key={idx}
                      className="flex items-center justify-between text-sm p-2 hover:bg-muted/50 rounded"
                    >
                      <span className="truncate flex-1">{file.filename}</span>
                      <div className="flex items-center gap-2">
                        {file.is_duplicate && (
                          <Badge variant="secondary" className="text-xs">
                            <Copy className="h-3 w-3 mr-1" />
                            Linked
                          </Badge>
                        )}
                        {file.content_id && (
                          <Button
                            variant="ghost"
                            size="sm"
                            className="h-6 px-2"
                            onClick={() => navigate(`/chat/${file.content_id}`)}
                          >
                            <ExternalLink className="h-3 w-3" />
                          </Button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}

          {/* Failed Files */}
          {failedFilesList.length > 0 && (
            <div className="space-y-2">
              <h4 className="text-sm font-medium flex items-center gap-2">
                <XCircle className="h-4 w-4 text-red-500" />
                Failed ({failedFilesList.length})
              </h4>
              <ScrollArea className="h-32 border border-red-200 rounded-md bg-red-50/50">
                <div className="p-2 space-y-1">
                  {failedFilesList.map((file, idx) => (
                    <div key={idx} className="text-sm p-2">
                      <div className="font-medium truncate">{file.filename}</div>
                      {file.error_message && (
                        <div className="text-xs text-red-600 mt-1">{file.error_message}</div>
                      )}
                    </div>
                  ))}
                </div>
              </ScrollArea>
            </div>
          )}

          {/* Info about duplicates */}
          {duplicateFiles.length > 0 && (
            <Alert className="border-blue-200 bg-blue-50">
              <Copy className="h-4 w-4 text-blue-600" />
              <AlertDescription className="text-blue-800">
                {duplicateFiles.length} file(s) were detected as duplicates and have been linked to
                your account without reprocessing.
              </AlertDescription>
            </Alert>
          )}
        </div>

        <DialogFooter className="flex gap-2">
          {failedFilesList.length > 0 && onRetryFailed && (
            <Button variant="outline" onClick={handleRetryFailed}>
              <RefreshCw className="mr-2 h-4 w-4" />
              Retry Failed ({failedFilesList.length})
            </Button>
          )}
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Close
          </Button>
          <Button onClick={handleViewLibrary}>
            <ExternalLink className="mr-2 h-4 w-4" />
            View Library
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
