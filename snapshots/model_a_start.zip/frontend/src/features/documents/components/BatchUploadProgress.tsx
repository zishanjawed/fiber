/**
 * BatchUploadProgress Component
 * Displays real-time progress for batch document uploads
 */

import { useEffect, useState, useRef } from 'react'
import { Progress } from '../../../components/ui/progress'
import { Badge } from '../../../components/ui/Badge'
import { ScrollArea } from '../../../components/ui/scroll-area'
import { Alert, AlertDescription } from '../../../components/ui/alert'
import {
  CheckCircle,
  XCircle,
  Loader2,
  Clock,
  FileText,
  Copy,
  AlertTriangle,
} from 'lucide-react'
import type { BatchFileStatus, BatchWebSocketEvent } from '../../../api/types'
import { documentsService } from '../../../api/documents.service'

interface BatchUploadProgressProps {
  batchId: string
  totalFiles: number
  initialFiles: Array<{
    filename: string
    size_mb: number
    status: string
  }>
  onComplete?: (results: {
    completedFiles: number
    failedFiles: number
    files: BatchFileStatus[]
  }) => void
}

export function BatchUploadProgress({
  batchId,
  totalFiles,
  initialFiles,
  onComplete,
}: BatchUploadProgressProps) {
  const [files, setFiles] = useState<BatchFileStatus[]>(
    initialFiles.map((f, idx) => ({
      filename: f.filename,
      file_index: idx,
      status: f.status as 'pending' | 'processing' | 'completed' | 'failed',
      is_duplicate: false,
      total_chunks: 0,
      processed_chunks: 0,
      progress: 0,
    }))
  )
  const [completedFiles, setCompletedFiles] = useState(0)
  const [failedFiles, setFailedFiles] = useState(0)
  const [overallProgress, setOverallProgress] = useState(0)
  const [status, setStatus] = useState<string>('processing')
  const [message, setMessage] = useState(`Processing ${totalFiles} files...`)

  const wsRef = useRef<WebSocket | null>(null)
  const pollIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const heartbeatIntervalRef = useRef<NodeJS.Timeout | null>(null)
  const hasCompletedRef = useRef(false)

  useEffect(() => {
    connectWebSocket()

    return () => {
      // CRITICAL: Clean up ALL intervals and connections
      if (wsRef.current) {
        wsRef.current.close()
        wsRef.current = null
      }
      if (pollIntervalRef.current) {
        clearInterval(pollIntervalRef.current)
        pollIntervalRef.current = null
      }
      if (heartbeatIntervalRef.current) {
        clearInterval(heartbeatIntervalRef.current)
        heartbeatIntervalRef.current = null
      }
    }
  }, [batchId])

  const connectWebSocket = () => {
    const wsBaseUrl = import.meta.env.VITE_WS_BASE_URL || 'ws://localhost:8000'
    const ws = new WebSocket(`${wsBaseUrl}/ws/batch/${batchId}/status`)
    wsRef.current = ws

    ws.onopen = () => {
      console.log('Batch WebSocket connected')
      // Send periodic pings to keep connection alive
      // Store in ref so cleanup can clear it
      heartbeatIntervalRef.current = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'ping' }))
        } else {
          // WebSocket closed, clear heartbeat
          if (heartbeatIntervalRef.current) {
            clearInterval(heartbeatIntervalRef.current)
            heartbeatIntervalRef.current = null
          }
        }
      }, 25000)
    }

    ws.onmessage = (event) => {
      const data: BatchWebSocketEvent = JSON.parse(event.data)
      handleWebSocketEvent(data)
    }

    ws.onerror = (error) => {
      console.error('Batch WebSocket error:', error)
      // Clear heartbeat on error
      if (heartbeatIntervalRef.current) {
        clearInterval(heartbeatIntervalRef.current)
        heartbeatIntervalRef.current = null
      }
      // Start polling fallback
      startPolling()
    }

    ws.onclose = () => {
      // Clear heartbeat on close
      if (heartbeatIntervalRef.current) {
        clearInterval(heartbeatIntervalRef.current)
        heartbeatIntervalRef.current = null
      }
      console.log('Batch WebSocket closed')

      // If not yet completed, start polling
      if (!hasCompletedRef.current) {
        startPolling()
      }
    }
  }

  const handleWebSocketEvent = (event: BatchWebSocketEvent) => {
    if (event.type === 'heartbeat' || event.type === 'pong') {
      return
    }

    if (event.type === 'batch_status' || event.type === 'batch_started') {
      // Initial status or batch started
      if (event.total_files) {
        setOverallProgress(event.progress || 0)
      }
      if (event.message) {
        setMessage(event.message)
      }
      if (event.files) {
        // Update file statuses
        setFiles((prev) =>
          prev.map((file) => {
            const update = event.files?.find((f) => f.filename === file.filename)
            if (update) {
              return {
                ...file,
                status: update.status as 'pending' | 'processing' | 'completed' | 'failed',
                content_id: update.content_id,
                error_message: update.error_message,
              }
            }
            return file
          })
        )
      }
    } else if (event.type === 'file_progress') {
      // Update specific file status
      if (event.file_index !== undefined) {
        setFiles((prev) =>
          prev.map((file, idx) => {
            if (idx === event.file_index) {
              return {
                ...file,
                status: event.file_status as 'pending' | 'processing' | 'completed' | 'failed',
                content_id: event.content_id || file.content_id,
                is_duplicate: event.is_duplicate || false,
                error_message: event.error || file.error_message,
              }
            }
            return file
          })
        )
      }

      // Update counters
      if (event.completed_files !== undefined) {
        setCompletedFiles(event.completed_files)
      }
      if (event.failed_files !== undefined) {
        setFailedFiles(event.failed_files)
      }
      if (event.progress !== undefined) {
        setOverallProgress(event.progress)
      }
      if (event.message) {
        setMessage(event.message)
      }
    } else if (event.type === 'batch_completed') {
      // Batch processing complete
      hasCompletedRef.current = true
      setStatus(event.status || 'completed')
      setCompletedFiles(event.completed_files || 0)
      setFailedFiles(event.failed_files || 0)
      setOverallProgress(100)
      setMessage(event.message || 'Batch processing complete')

      // Close WebSocket
      if (wsRef.current) {
        wsRef.current.close()
      }

      // Notify parent
      if (onComplete) {
        onComplete({
          completedFiles: event.completed_files || 0,
          failedFiles: event.failed_files || 0,
          files: files,
        })
      }
    }
  }

  const startPolling = () => {
    if (pollIntervalRef.current) {
      return // Already polling
    }

    let attempts = 0
    const maxAttempts = 300 // 10 minutes (300 * 2s)

    pollIntervalRef.current = setInterval(async () => {
      attempts++

      if (attempts > maxAttempts || hasCompletedRef.current) {
        if (pollIntervalRef.current) {
          clearInterval(pollIntervalRef.current)
        }
        return
      }

      try {
        const batchStatus = await documentsService.getBatchStatus(batchId)

        setCompletedFiles(batchStatus.completed_files)
        setFailedFiles(batchStatus.failed_files)
        setOverallProgress(batchStatus.progress_percentage)
        setStatus(batchStatus.status)

        // Update file statuses
        setFiles(batchStatus.files)

        // Check if completed
        if (
          batchStatus.status === 'completed' ||
          batchStatus.status === 'completed_with_errors'
        ) {
          hasCompletedRef.current = true
          if (pollIntervalRef.current) {
            clearInterval(pollIntervalRef.current)
          }

          setMessage(
            `Batch complete: ${batchStatus.completed_files} succeeded, ${batchStatus.failed_files} failed`
          )

          if (onComplete) {
            onComplete({
              completedFiles: batchStatus.completed_files,
              failedFiles: batchStatus.failed_files,
              files: batchStatus.files,
            })
          }
        } else {
          setMessage(
            `Processing ${batchStatus.completed_files + batchStatus.failed_files}/${batchStatus.total_files} files...`
          )
        }
      } catch (error) {
        console.error('Failed to poll batch status:', error)
      }
    }, 2000)
  }

  const getStatusIcon = (fileStatus: string) => {
    switch (fileStatus) {
      case 'completed':
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case 'failed':
        return <XCircle className="h-4 w-4 text-red-500" />
      case 'processing':
        return <Loader2 className="h-4 w-4 text-blue-500 animate-spin" />
      default:
        return <Clock className="h-4 w-4 text-gray-400" />
    }
  }

  const getStatusBadge = (fileStatus: string, isDuplicate: boolean) => {
    if (isDuplicate) {
      return (
        <Badge variant="secondary" className="text-xs">
          <Copy className="h-3 w-3 mr-1" />
          Duplicate
        </Badge>
      )
    }

    switch (fileStatus) {
      case 'completed':
        return (
          <Badge variant="default" className="bg-green-100 text-green-800 text-xs">
            Completed
          </Badge>
        )
      case 'failed':
        return (
          <Badge variant="destructive" className="text-xs">
            Failed
          </Badge>
        )
      case 'processing':
        return (
          <Badge variant="secondary" className="text-xs">
            Processing
          </Badge>
        )
      default:
        return (
          <Badge variant="outline" className="text-xs">
            Pending
          </Badge>
        )
    }
  }

  return (
    <div className="space-y-4">
      {/* Overall Progress */}
      <div className="space-y-2">
        <div className="flex justify-between text-sm">
          <span className="font-medium">{message}</span>
          <span className="text-muted-foreground">{Math.round(overallProgress)}%</span>
        </div>
        <Progress value={overallProgress} className="h-3" />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>
            {completedFiles} completed, {failedFiles} failed of {totalFiles} total
          </span>
          {status.includes('completed') && (
            <span className="text-green-600 font-medium">Done!</span>
          )}
        </div>
      </div>

      {/* Warning for failures */}
      {failedFiles > 0 && status.includes('completed') && (
        <Alert className="border-yellow-200 bg-yellow-50">
          <AlertTriangle className="h-4 w-4 text-yellow-600" />
          <AlertDescription className="text-yellow-800">
            {failedFiles} file(s) failed to process. You can retry these files individually.
          </AlertDescription>
        </Alert>
      )}

      {/* File List */}
      <div className="border rounded-lg">
        <div className="p-3 bg-muted/50 border-b flex items-center gap-2">
          <FileText className="h-4 w-4" />
          <span className="font-medium text-sm">Files</span>
        </div>
        <ScrollArea className="h-64">
          <div className="divide-y">
            {files.map((file, index) => (
              <div
                key={index}
                className="p-3 flex items-center justify-between hover:bg-muted/30 transition-colors"
              >
                <div className="flex items-center gap-3 flex-1 min-w-0">
                  {getStatusIcon(file.status)}
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-medium truncate">{file.filename}</p>
                    {file.error_message && (
                      <p className="text-xs text-red-600 truncate">{file.error_message}</p>
                    )}
                    {file.content_id && file.status === 'completed' && (
                      <p className="text-xs text-muted-foreground">
                        ID: {file.content_id.slice(0, 8)}...
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex-shrink-0">
                  {getStatusBadge(file.status, file.is_duplicate)}
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </div>
    </div>
  )
}
