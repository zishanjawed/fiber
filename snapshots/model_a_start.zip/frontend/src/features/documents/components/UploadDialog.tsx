/**
 * UploadDialog Component
 * Modal dialog for uploading documents (single or bulk)
 */

import { useState, useRef, useEffect } from 'react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '../../../components/ui/dialog'
import { Button } from '../../../components/ui/Button'
import { Input } from '../../../components/ui/Input'
import { Label } from '../../../components/ui/label'
import { FileUploader } from '../../../components/ui/FileUploader'
import { Badge } from '../../../components/ui/Badge'
import { Alert, AlertDescription } from '../../../components/ui/alert'
import { Progress } from '../../../components/ui/progress'
import { ScrollArea } from '../../../components/ui/scroll-area'
import {
  Info,
  Upload,
  CheckCircle,
  Loader2,
  FileText,
  X,
  AlertTriangle,
  RefreshCw,
} from 'lucide-react'
import { Document, BatchFileStatus } from '../../../api/types'
import { useAuth } from '../../auth/hooks/useAuth'
import { documentsService } from '../../../api/documents.service'
import { BatchUploadProgress } from './BatchUploadProgress'
import { BatchResultsModal } from './BatchResultsModal'

interface UploadDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  onUploadComplete?: (document: Document) => void
  onBatchComplete?: () => void
}

// Constants matching backend
const MAX_BATCH_FILES = 50
const MAX_FILE_SIZE_MB = 50
const MAX_BATCH_SIZE_MB = 500
const ALLOWED_EXTENSIONS = ['pdf', 'md', 'txt', 'docx', 'doc']

interface PendingBatch {
  batch_id: string
  total_files: number
  completed_files: number
  failed_files: number
  status: string
  progress_percentage: number
  created_at: string
  files_preview: Array<{ filename: string; status: string }>
}

export function UploadDialog({
  open,
  onOpenChange,
  onUploadComplete,
  onBatchComplete,
}: UploadDialogProps) {
  const { user } = useAuth()
  const [files, setFiles] = useState<File[]>([])
  const [title, setTitle] = useState('')
  const [subject, setSubject] = useState('')
  const [tags, setTags] = useState('')
  const [isUploading, setIsUploading] = useState(false)
  const [uploadSuccess, setUploadSuccess] = useState(false)
  const [uploadedDoc, setUploadedDoc] = useState<Document | null>(null)
  const [processingStatus, setProcessingStatus] = useState('')
  const [processingProgress, setProcessingProgress] = useState(0)

  // Batch upload state
  const [isBatchMode, setIsBatchMode] = useState(false)
  const [batchId, setBatchId] = useState<string | null>(null)
  const [batchFiles, setBatchFiles] = useState<
    Array<{ filename: string; size_mb: number; status: string }>
  >([])
  const [showResultsModal, setShowResultsModal] = useState(false)
  const [batchResults, setBatchResults] = useState<{
    completedFiles: number
    failedFiles: number
    files: BatchFileStatus[]
  } | null>(null)
  const [validationError, setValidationError] = useState<string | null>(null)

  // Batch recovery state
  const [pendingBatch, setPendingBatch] = useState<PendingBatch | null>(null)
  const [showRecoveryPrompt, setShowRecoveryPrompt] = useState(false)
  const [checkingPending, setCheckingPending] = useState(false)

  const uploadButtonRef = useRef<HTMLButtonElement>(null)

  // Check for pending batches when dialog opens
  useEffect(() => {
    if (open && user) {
      checkForPendingBatches()
    }
  }, [open, user])

  const checkForPendingBatches = async () => {
    setCheckingPending(true)
    try {
      const response = await documentsService.getPendingBatches()
      if (response.count > 0) {
        // Show the most recent pending batch
        setPendingBatch(response.pending_batches[0])
        setShowRecoveryPrompt(true)
      }
    } catch (error) {
      console.error('Failed to check for pending batches:', error)
      // Don't block user from uploading
    } finally {
      setCheckingPending(false)
    }
  }

  const handleResumeBatch = () => {
    if (pendingBatch) {
      // Resume tracking the pending batch
      setBatchId(pendingBatch.batch_id)
      setBatchFiles(
        pendingBatch.files_preview.map((f, idx) => ({
          filename: f.filename,
          size_mb: 0, // Unknown for resumed batches
          status: f.status,
        }))
      )
      setIsBatchMode(true)
      setIsUploading(true)
      setShowRecoveryPrompt(false)
      setProcessingStatus(`Resuming batch upload (${pendingBatch.progress_percentage}% complete)...`)
    }
  }

  const handleStartNewBatch = () => {
    // Dismiss recovery prompt, allow new upload
    setShowRecoveryPrompt(false)
    setPendingBatch(null)
  }

  const handleFilesChange = (newFiles: File[]) => {
    setValidationError(null)

    // Validate files
    if (newFiles.length > MAX_BATCH_FILES) {
      setValidationError(
        `Too many files. Maximum ${MAX_BATCH_FILES} files per batch.`
      )
      return
    }

    // Check file types and sizes
    let totalSize = 0
    for (const file of newFiles) {
      const ext = file.name.split('.').pop()?.toLowerCase() || ''
      if (!ALLOWED_EXTENSIONS.includes(ext)) {
        setValidationError(
          `Invalid file type: ${file.name}. Allowed: ${ALLOWED_EXTENSIONS.join(', ').toUpperCase()}`
        )
        return
      }

      const sizeMB = file.size / (1024 * 1024)
      if (sizeMB > MAX_FILE_SIZE_MB) {
        setValidationError(
          `File too large: ${file.name} (${sizeMB.toFixed(2)}MB). Max: ${MAX_FILE_SIZE_MB}MB`
        )
        return
      }
      totalSize += file.size
    }

    const totalSizeMB = totalSize / (1024 * 1024)
    if (totalSizeMB > MAX_BATCH_SIZE_MB) {
      setValidationError(
        `Total batch size (${totalSizeMB.toFixed(2)}MB) exceeds maximum (${MAX_BATCH_SIZE_MB}MB)`
      )
      return
    }

    setFiles(newFiles)

    // Auto-detect batch mode
    setIsBatchMode(newFiles.length > 1)

    // Auto-fill title from filename if single file and empty
    if (newFiles.length === 1 && !title) {
      const filename = newFiles[0].name.replace(/\.[^/.]+$/, '')
      setTitle(filename)
    } else if (newFiles.length > 1) {
      // Clear single-file title for batch mode
      setTitle('')
    }
  }

  const removeFile = (index: number) => {
    const newFiles = files.filter((_, i) => i !== index)
    setFiles(newFiles)
    setIsBatchMode(newFiles.length > 1)
    setValidationError(null)
  }

  const handleUpload = async () => {
    if (files.length === 0 || !user) return

    // Prevent double-click
    if (uploadButtonRef.current) {
      uploadButtonRef.current.disabled = true
    }

    setIsUploading(true)
    setUploadSuccess(false)
    setValidationError(null)

    if (isBatchMode) {
      await handleBatchUpload()
    } else {
      await handleSingleUpload()
    }
  }

  const handleSingleUpload = async () => {
    setProcessingStatus('Uploading file...')
    setProcessingProgress(0)

    try {
      const file = files[0]
      const apiBaseUrl = import.meta.env.VITE_API_BASE_URL || 'http://localhost:8000'

      if (!user) {
        throw new Error('User not authenticated')
      }

      const formData = new FormData()
      formData.append('file', file)
      formData.append('user_id', user.id)
      formData.append('title', title || file.name)
      if (subject) formData.append('subject', subject)
      if (tags) formData.append('tags', tags)

      const response = await fetch(`${apiBaseUrl}/api/content/upload`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${localStorage.getItem('access_token')}`,
        },
        body: formData,
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}))
        throw new Error(errorData.detail || errorData.message || 'Upload failed')
      }

      const document = await response.json()
      setUploadedDoc(document)

      setProcessingStatus('Upload complete - processing document...')
      setProcessingProgress(10)

      if (!document.is_duplicate) {
        connectWebSocket(document.content_id)
      } else {
        setUploadSuccess(true)
        setProcessingStatus('Duplicate detected - linked to your account')
        setProcessingProgress(100)

        if (onUploadComplete) {
          onUploadComplete(document)
        }

        setTimeout(() => {
          handleClose()
        }, 2000)
      }
    } catch (error: any) {
      console.error('Upload error:', error)
      const errorMessage = error.message || 'Unknown error occurred'
      setProcessingStatus(`Upload failed: ${errorMessage}`)
      setUploadSuccess(false)
      setProcessingProgress(0)
    } finally {
      setIsUploading(false)
      if (uploadButtonRef.current) {
        uploadButtonRef.current.disabled = false
      }
    }
  }

  const handleBatchUpload = async () => {
    setProcessingStatus(`Uploading ${files.length} files...`)
    setProcessingProgress(0)

    try {
      const response = await documentsService.bulkUpload({
        files: files,
        title_prefix: title || undefined,
        subject: subject || undefined,
        tags: tags || undefined,
      })

      setBatchId(response.batch_id)
      setBatchFiles(response.files)
      setProcessingStatus(`Batch started. Processing ${response.total_files} files...`)
      setProcessingProgress(5)

      // The BatchUploadProgress component will handle WebSocket connection
    } catch (error: any) {
      console.error('Batch upload error:', error)
      const errorMessage =
        error.response?.data?.detail || error.message || 'Batch upload failed'
      setProcessingStatus(`Batch upload failed: ${errorMessage}`)
      setIsUploading(false)
      if (uploadButtonRef.current) {
        uploadButtonRef.current.disabled = false
      }
    }
  }

  const handleBatchComplete = (results: {
    completedFiles: number
    failedFiles: number
    files: BatchFileStatus[]
  }) => {
    setBatchResults(results)
    setIsUploading(false)
    setUploadSuccess(true)
    setShowResultsModal(true)

    if (onBatchComplete) {
      onBatchComplete()
    }

    if (uploadButtonRef.current) {
      uploadButtonRef.current.disabled = false
    }
  }

  const connectWebSocket = (contentId: string) => {
    const wsBaseUrl = import.meta.env.VITE_WS_BASE_URL || 'ws://localhost:8000'
    const ws = new WebSocket(`${wsBaseUrl}/ws/document/${contentId}/status`)
    let wsConnected = false
    let pollInterval: NodeJS.Timeout | null = null
    let heartbeatInterval: NodeJS.Timeout | null = null

    ws.onopen = () => {
      wsConnected = true
      heartbeatInterval = setInterval(() => {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ type: 'ping' }))
        } else {
          if (heartbeatInterval) clearInterval(heartbeatInterval)
        }
      }, 25000)
    }

    ws.onmessage = (event) => {
      const data = JSON.parse(event.data)

      if (data.type === 'heartbeat' || data.type === 'pong') {
        return
      }

      setProcessingStatus(data.message || `Status: ${data.status}`)
      setProcessingProgress(data.progress || 0)

      if (data.status === 'completed') {
        setUploadSuccess(true)
        ws.close()
        if (heartbeatInterval) clearInterval(heartbeatInterval)
        if (pollInterval) clearInterval(pollInterval)

        if (uploadedDoc && onUploadComplete) {
          const completedDoc = { ...uploadedDoc, status: 'completed' as const }
          onUploadComplete(completedDoc)
        }

        setTimeout(() => {
          handleClose()
        }, 2000)
      } else if (data.status === 'failed') {
        setProcessingStatus('Processing failed')
        ws.close()
        if (heartbeatInterval) clearInterval(heartbeatInterval)
        if (pollInterval) clearInterval(pollInterval)
      }
    }

    ws.onerror = (error) => {
      console.error('WebSocket error:', error)
      setProcessingStatus('Connection issue - checking status...')

      if (!pollInterval) {
        startPolling(contentId)
      }
    }

    ws.onclose = () => {
      if (heartbeatInterval) clearInterval(heartbeatInterval)

      if (wsConnected && !uploadSuccess) {
        console.log('WebSocket closed unexpectedly, starting polling')
        if (!pollInterval) {
          startPolling(contentId)
        }
      }
    }

    const startPolling = (contentId: string) => {
      let attempts = 0
      const maxAttempts = 150

      pollInterval = setInterval(async () => {
        attempts++

        if (attempts > maxAttempts) {
          if (pollInterval) clearInterval(pollInterval)
          setProcessingStatus('Processing timeout - please refresh')
          return
        }

        try {
          const doc = await documentsService.getDocument(contentId)

          if (doc.status === 'completed') {
            setUploadSuccess(true)
            setProcessingStatus('Document ready for chat!')
            setProcessingProgress(100)
            if (pollInterval) clearInterval(pollInterval)

            if (uploadedDoc && onUploadComplete) {
              const completedDoc = { ...uploadedDoc, status: 'completed' as const }
              onUploadComplete(completedDoc)
            }

            setTimeout(() => {
              handleClose()
            }, 2000)
          } else if (doc.status === 'failed') {
            setProcessingStatus('Processing failed')
            if (pollInterval) clearInterval(pollInterval)
          } else {
            const progress =
              doc.total_chunks && doc.total_chunks > 0
                ? Math.floor(((doc.processed_chunks || 0) / doc.total_chunks) * 100)
                : 0
            setProcessingProgress(progress)
            setProcessingStatus(
              `Processing... ${doc.processed_chunks || 0}/${doc.total_chunks || 0} chunks`
            )
          }
        } catch (error) {
          console.error('Failed to poll status:', error)
        }
      }, 2000)
    }
  }

  const handleClose = () => {
    if (!isUploading) {
      setFiles([])
      setTitle('')
      setSubject('')
      setTags('')
      setUploadSuccess(false)
      setUploadedDoc(null)
      setProcessingStatus('')
      setProcessingProgress(0)
      setBatchId(null)
      setBatchFiles([])
      setIsBatchMode(false)
      setValidationError(null)
      setPendingBatch(null)
      setShowRecoveryPrompt(false)
      onOpenChange(false)
    }
  }

  const handleResultsModalClose = () => {
    setShowResultsModal(false)
    handleClose()
  }

  const isFormValid = files.length > 0 && (isBatchMode || title.trim() !== '')
  const totalFileSize = files.reduce((sum, f) => sum + f.size, 0) / (1024 * 1024)

  return (
    <>
      <Dialog open={open} onOpenChange={handleClose}>
        <DialogContent className="sm:max-w-[700px]">
          <DialogHeader>
            <DialogTitle>
              {isBatchMode ? `Bulk Upload (${files.length} files)` : 'Upload Document'}
            </DialogTitle>
            <DialogDescription>
              {isBatchMode
                ? `Upload multiple documents at once. Max ${MAX_BATCH_FILES} files, ${MAX_BATCH_SIZE_MB}MB total.`
                : 'Add a new document to your knowledge base. Supported formats: PDF, TXT, MD, DOCX'}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            {/* Batch Recovery Prompt */}
            {showRecoveryPrompt && pendingBatch && (
              <Alert className="border-blue-200 bg-blue-50">
                <RefreshCw className="h-4 w-4 text-blue-600" />
                <AlertDescription className="text-blue-800">
                  <div className="space-y-3">
                    <div className="font-medium">
                      You have an in-progress batch upload ({pendingBatch.progress_percentage}% complete)
                    </div>
                    <div className="text-sm">
                      {pendingBatch.completed_files}/{pendingBatch.total_files} files processed
                      {pendingBatch.failed_files > 0 && (
                        <span className="text-red-600">
                          , {pendingBatch.failed_files} failed
                        </span>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      Started: {new Date(pendingBatch.created_at).toLocaleString()}
                    </div>
                    <div className="flex gap-2 mt-2">
                      <Button
                        size="sm"
                        onClick={handleResumeBatch}
                        className="bg-blue-600 hover:bg-blue-700"
                      >
                        <RefreshCw className="mr-2 h-3 w-3" />
                        Resume Tracking
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={handleStartNewBatch}
                      >
                        Start New Upload
                      </Button>
                    </div>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {/* Checking for pending batches */}
            {checkingPending && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Checking for pending uploads...
              </div>
            )}

            {/* File uploader - always show unless batch processing started or recovery prompt shown */}
            {!batchId && !showRecoveryPrompt && (
              <FileUploader
                onFilesChange={handleFilesChange}
                accept=".pdf,.txt,.md,.docx,.doc"
                maxSize={MAX_FILE_SIZE_MB * 1024 * 1024}
                maxFiles={MAX_BATCH_FILES}
                multiple={true}
                disabled={isUploading || uploadSuccess || checkingPending}
              />
            )}

            {/* Validation error */}
            {validationError && (
              <Alert className="border-red-200 bg-red-50">
                <AlertTriangle className="h-4 w-4 text-red-600" />
                <AlertDescription className="text-red-800">
                  {validationError}
                </AlertDescription>
              </Alert>
            )}

            {/* File list for batch mode */}
            {isBatchMode && files.length > 0 && !batchId && (
              <div className="border rounded-lg">
                <div className="p-3 bg-muted/50 border-b flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <FileText className="h-4 w-4" />
                    <span className="font-medium text-sm">
                      Selected Files ({files.length})
                    </span>
                  </div>
                  <Badge variant="outline">{totalFileSize.toFixed(2)} MB total</Badge>
                </div>
                <ScrollArea className="h-40">
                  <div className="divide-y">
                    {files.map((file, index) => (
                      <div
                        key={index}
                        className="p-2 flex items-center justify-between hover:bg-muted/30"
                      >
                        <div className="flex items-center gap-2 min-w-0 flex-1">
                          <FileText className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                          <span className="text-sm truncate">{file.name}</span>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <span className="text-xs text-muted-foreground">
                            {(file.size / (1024 * 1024)).toFixed(2)} MB
                          </span>
                          {!isUploading && (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="h-6 w-6 p-0"
                              onClick={() => removeFile(index)}
                            >
                              <X className="h-3 w-3" />
                            </Button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            )}

            {/* Batch Upload Progress */}
            {batchId && batchFiles.length > 0 && (
              <BatchUploadProgress
                batchId={batchId}
                totalFiles={files.length}
                initialFiles={batchFiles}
                onComplete={handleBatchComplete}
              />
            )}

            {/* Single file processing status */}
            {!isBatchMode && isUploading && processingStatus && (
              <Alert className="border-blue-200 bg-blue-50">
                <Loader2 className="h-4 w-4 text-blue-600 animate-spin" />
                <AlertDescription className="text-blue-800">
                  <div className="space-y-2">
                    <div>{processingStatus}</div>
                    {processingProgress > 0 && (
                      <Progress value={processingProgress} className="h-2" />
                    )}
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {/* Single file success message */}
            {!isBatchMode && uploadSuccess && uploadedDoc && (
              <Alert className="border-green-200 bg-green-50">
                <CheckCircle className="h-4 w-4 text-green-600" />
                <AlertDescription className="text-green-800">
                  {uploadedDoc.is_duplicate ? (
                    <>
                      Document already exists in knowledge base! Linked to your account.
                      <Badge variant="secondary" className="ml-2">
                        Duplicate Detected
                      </Badge>
                    </>
                  ) : (
                    `Document processed successfully! ${processingProgress}% complete`
                  )}
                </AlertDescription>
              </Alert>
            )}

            {/* Metadata form - show for single file or batch with optional prefix */}
            {!batchId && (
              <div className="grid gap-4">
                {!isBatchMode && (
                  <div className="space-y-2">
                    <Label htmlFor="title">Title *</Label>
                    <Input
                      id="title"
                      placeholder="Document title"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      disabled={isUploading || uploadSuccess}
                    />
                  </div>
                )}

                {isBatchMode && (
                  <div className="space-y-2">
                    <Label htmlFor="title_prefix">Title Prefix (Optional)</Label>
                    <Input
                      id="title_prefix"
                      placeholder="e.g., Chemistry Unit 3 -"
                      value={title}
                      onChange={(e) => setTitle(e.target.value)}
                      disabled={isUploading || uploadSuccess}
                    />
                    <p className="text-xs text-muted-foreground">
                      If provided, this will be prepended to each filename
                    </p>
                  </div>
                )}

                <div className="space-y-2">
                  <Label htmlFor="subject">Subject</Label>
                  <Input
                    id="subject"
                    placeholder="e.g., Chemistry, Physics, Biology, Mathematics"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    disabled={isUploading || uploadSuccess}
                  />
                  <p className="text-xs text-muted-foreground">
                    {isBatchMode
                      ? 'This subject will be applied to all files'
                      : 'Enter the subject area for this document'}
                  </p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="tags">Tags (comma-separated)</Label>
                  <Input
                    id="tags"
                    placeholder="e.g., stoichiometry, moles, calculations"
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    disabled={isUploading || uploadSuccess}
                  />
                  <p className="text-xs text-muted-foreground">
                    {isBatchMode
                      ? 'These tags will be applied to all files'
                      : 'Add tags to help organize and find your documents'}
                  </p>
                </div>
              </div>
            )}

            {/* Info message */}
            {!uploadSuccess && !isUploading && !batchId && (
              <Alert>
                <Info className="h-4 w-4" />
                <AlertDescription>
                  {isBatchMode ? (
                    <>
                      Documents will be processed concurrently (max 5 at a time) with real-time
                      progress updates. Processing continues even if you navigate away.
                    </>
                  ) : (
                    <>
                      Your document will be processed automatically with real-time status updates.
                      You'll be able to chat with it once processing is complete (usually 1-2
                      minutes).
                    </>
                  )}
                </AlertDescription>
              </Alert>
            )}
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={handleClose}
              disabled={isUploading && !uploadSuccess}
            >
              {uploadSuccess || batchId ? 'Close' : 'Cancel'}
            </Button>
            {!uploadSuccess && !batchId && (
              <Button
                ref={uploadButtonRef}
                onClick={handleUpload}
                disabled={!isFormValid || isUploading || !!validationError}
              >
                {isUploading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    {isBatchMode ? 'Starting Upload...' : 'Uploading...'}
                  </>
                ) : (
                  <>
                    <Upload className="mr-2 h-4 w-4" />
                    {isBatchMode
                      ? `Upload All (${files.length} files)`
                      : 'Upload'}
                  </>
                )}
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Batch Results Modal */}
      {batchResults && (
        <BatchResultsModal
          open={showResultsModal}
          onOpenChange={handleResultsModalClose}
          completedFiles={batchResults.completedFiles}
          failedFiles={batchResults.failedFiles}
          files={batchResults.files}
        />
      )}
    </>
  )
}
